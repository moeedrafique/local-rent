from channels.generic.websocket import WebsocketConsumer
import firebase_admin
from firebase_admin import credentials, firestore
import threading
import pytz
import pymongo
from pymongo import MongoClient
from datetime import datetime, timedelta
import json
from google.api_core.datetime_helpers import DatetimeWithNanoseconds
from django.conf import settings

#####################################
##### Firebase initial System Setup

def fb_config(request):
    firebase_config = settings.CONFIG
    return firebase_config

#####################################
##### MongoDB initial System Setup

def md_config():
    mongodb_config = settings.MD_CONFIG
    return mongodb_config

cluster = MongoClient(md_config()['client'])
m_db = cluster[md_config()['cluster']]
m_vehicles = m_db[md_config()['vehicles']]

if not firebase_admin._apps:
    cred = credentials.Certificate(settings.FB_CONFIG)
    firebase_admin.initialize_app(cred, {
        'storageBucket': 'tryme-taxi.appspot.com'
    })

# Create an Event for notifying main thread.
callback_done = threading.Event()

# bookings_d = f_db.collection_group(u'bookings')
# docs = bookings_d.stream()

class GraphConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()

    def disconnect(self, close_code):
        if close_code == 1000:
            print("Normal closure.")
        elif close_code == 1001:
            print("Going away.")
        elif close_code == 1002:
            print("Protocol error.")
        elif close_code == 1003:
            print("Unsupported data.")
        elif close_code == 1006:
            print("Abnormal closure.")
        else:
            print(f"WebSocket closed for unknown reason: {close_code}")



    def vehicle_details(self, vehicle_id):
        print(vehicle_id)
        self.vehicle = m_vehicles.find_one({'vehicle_id': vehicle_id})
        if self.vehicle is not None:
            ref = self.vehicle['reference'] # {'vehicle_id': 'lbveqyXN3zfmv7X9OCF8XlZ2u1g2AA11AAA'}
        else:
            ref = ''
        return ref

    def receive(self, text_data):
        text_data_json = json.loads(text_data)
        print(f"Received JSON: {text_data_json}")
        button_pressed = text_data_json['selectedTab']
        self.dispatch_booking_ids = text_data_json['bookingIds']

        if button_pressed == '#dispatch':
            print('dispatch button is pressed')
            self.watch_dispatch_data()

        elif button_pressed == '#pre-booked':
            print('pre-booked button is pressed')
            # self.watch_pre_booked_data()

    def watch_dispatch_data(self):
        
        twenty_four_hours_ago = datetime.utcnow() - timedelta(hours=1)
        firestore_timestamp = DatetimeWithNanoseconds(twenty_four_hours_ago.year,
                                                    twenty_four_hours_ago.month,
                                                    twenty_four_hours_ago.day,
                                                    twenty_four_hours_ago.hour,
                                                    twenty_four_hours_ago.minute,
                                                    twenty_four_hours_ago.second,
                                                    twenty_four_hours_ago.microsecond)
        
        f_db = firestore.client()
        dispatch_ref = f_db.collection_group(u'bookings') \
            .where(u'booking_time', u'>=', firestore_timestamp) \
            .where(u'status', u'in', ['bidding', 'pending', 'cancel'])
            
        dispatch_watch = dispatch_ref.on_snapshot(self.on_snapshot_dispatch)
        
        
    def on_snapshot_dispatch(self, doc_snapshot, changes, read_time):
        # Your code to handle dispatch data
        print('Dispatch doc_watch is running')
        
        for change in changes:
            if change.type.name == 'ADDED':
                print('New dispatch document added')

                # THIS IS FOR NEW JOB OR PRE-BOOKING
                if change.document.get('status') not in ['cancel', 'complete']:
                    print('New Job for dispatching')

                    if change.document.get('status') == 'pending':
                        update = 'bidding'
                    elif change.document.get('status') == 'job_given':
                        update = 'dispatched'
                    else:
                        update = change.document.get('status')

                    lead_time = change.document.get('pickup_time')
                    if lead_time is not None:
                        lead_time = lead_time.astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                    else:
                        lead_time = ''

                    print(f"vehicle_id: {change.document.get('sent_to.vehicle_id')}")
                    booking_id = change.document.id
                    document = {
                        'booking_id': booking_id,
                        'added_datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
                        'lead_time': lead_time,
                        'consumer_rating': change.document.get('customer.average_rating'),
                        'new': True,
                        'priority': '',
                        'update': update,
                        'drv': self.vehicle_details(change.document.to_dict().get('sent_to', {}).get('vehicle_id')),
                        'address': change.document.get('pickup_location').get('address'),
                        'info': '',
                        'account': '',
                        'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
                        'via': '',
                        'phone': change.document.get('customer').get('contact'),
                        'consumer_name': change.document.to_dict().get('customer', {}).get('full_name'),
                        'zone': ''
                        }
                    

                    print(document)
                    if document['booking_id'] in self.dispatch_booking_ids:
                        print(f'booking_id {booking_id} is already in dispatch')
                    else:
                        self.send(text_data=json.dumps(document))
                    
                        self.dispatch_booking_ids.append(booking_id)
                        
                        print(f'self.dispatch_booking_ids: {self.dispatch_booking_ids}')

                    # bookings_for_django.insert_one(document)

                else:
                    pass
                
            if change.type.name == 'MODIFIED':
                booking_id = change.document.id
                print(f'booking Id: {booking_id} is now modified from dispatch')
                document = {
                        'booking_id': booking_id,
                        'action': 'remove'
                }
                
                self.send(text_data=json.dumps(document))
                
                if booking_id in self.dispatch_booking_ids:
                    self.dispatch_booking_ids.remove(booking_id)
                else:
                    print(f'booking Id: {booking_id} is not in dispatch bookings list')
                
                
                
                
        callback_done.set()

    
        
    

    # def on_snapshot(doc_snapshot, changes, read_time):

    #     print('doc_watch is running')
    #     print(read_time)

    #     for change in changes:


    #         #########################################################
    #         ####### IF BOOKING DOCUMENT IS ADDED
    #         #########################################################

    #         if change.type.name == 'ADDED':

    #             # THIS IS FOR NEW JOB OR PRE-BOOKING
    #             if change.document.get('status') not in ['cancel', 'complete']:

    #                 if change.document.get('status') == 'pending':
    #                     update = 'bidding'
    #                 elif change.document.get('status') == 'job_given':
    #                     update = 'dispatched'
    #                 else:
    #                     update = change.document.get('status')

    #                 lead_time = change.document.get('pickup_time')
    #                 if lead_time is not None:
    #                     lead_time = lead_time.astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                 else:
    #                     lead_time = ''

    #                 print(f"vehicle_id: {change.document.get('sent_to.vehicle_id')}")
    #                 booking_id = change.document.id
    #                 document = {
    #                     'booking_id': booking_id,
    #                     'added_datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    #                     'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
    #                     'lead_time': lead_time,
    #                     'consumer_rating': change.document.get('customer.average_rating'),
    #                     'new': True,
    #                     'priority': '',
    #                     'update': update,
    #                     'drv': vehicle_details(change.document.to_dict().get('sent_to', {}).get('vehicle_id')),
    #                     'address': change.document.get('pickup_location').get('address'),
    #                     'info': '',
    #                     'account': '',
    #                     'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
    #                     'via': '',
    #                     'phone': change.document.get('customer').get('contact'),
    #                     'consumer_name': change.document.to_dict().get('customer', {}).get('full_name'),
    #                     'zone': ''
    #                     }

    #                 print(document)
    #                 self.send(text_data=json.dumps(document))

    #                 # bookings_for_django.insert_one(document)

    #             else:
    #                 pass

    #         elif change.type.name == 'MODIFIED':
    #             # if change.document.get('status') not in ['cancel', 'completed']:

    #             if change.document.get('status') == 'pending':
    #                 update = 'bidding'
    #             elif change.document.get('status') == 'job_given':
    #                     update = 'dispatched'
    #             else:
    #                 update = change.document.get('status')

    #             booking_id = change.document.id
    #             booking_filter = {
    #                     'booking_id': booking_id
    #                 }
    #             # bookings_d
    #             # print(bookings_d.where(firestore.document.ID, '==', booking_id).get())
    #             # last_booking = bookings_d.where(firestore.document.ID, '==', booking_id).get()[0]
    #             # last_booking = bookings_for_django.find_one(booking_filter, sort = [('_id', pymongo.DESCENDING)])
    #             # print(f'last_booking: {last_booking}')

    #             lead_time = change.document.get('pickup_time')
    #             if lead_time is not None:
    #                 lead_time = lead_time.astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #             else:
    #                 lead_time = ''

    #             # THIS IS FOR DISPATCHING
    #             if change.document.to_dict().get('sent_to').get('driver_id') != '' and change.document.get('status') == 'pending':
    #                 # if last_booking.get('status') == 'bidding' and last_booking['destination'] == change.document.get('dropOff_address') and last_booking['drv'] == '':
                
    #                 # print(last_booking['update'])
    #                 print(change.document.get('status'))

    #                 print(f"vehicle_id: {change.document.to_dict().get('sent_to', {}).get('vehicle_id')}")
    #                 print(f"modified_dispatched")
    #                 booking_id = change.document.id
    #                 document = {
    #                     'booking_id': booking_id,
    #                     'added_datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    #                     'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
    #                     'lead_time': lead_time,
    #                     'consumer_rating': change.document.get('customer.average_rating'),
    #                     'new': False,
    #                     'priority': '',
    #                     'update': update,
    #                     'drv': vehicle_details(change.document.to_dict().get('sent_to', {}).get('vehicle_id')),
    #                     'address': change.document.get('pickup_location').get('address'),
    #                     'info': '',
    #                     'account': '',
    #                     'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
    #                     'via': '',
    #                     'phone': change.document.get('customer.contact'),
    #                     'consumer_name': change.document.to_dict().get('customer', {}).get('full_name'),
    #                     'zone': ''
    #                     }

    #                 print(document)
    #                 self.send(text_data=json.dumps(document))
    #                 # bookings_for_django.insert_one(document)

    #             # THIS IS FOR BOOKED
    #             elif change.document.get('status') in ['job_given', 'arrived', 'pob'] and change.document.to_dict().get('accepted_by', {}).get('driver_id') != '':
    #                 # if last_booking['update'] in ['bidding', 'dispatched', 'arrived', 'pob'] and last_booking['destination'] == change.document.get('dropOff_address'):
    #                 # print(last_booking['update'])
    #                 print(change.document.get('status'))

    #                 print(f"vehicle_id: {change.document.get('sent_to.vehicle_id')}")


    #                 status_logs = change.document.get('status_logs')
    #                 accepted_driver_id = change.document.get('accepted_by.driver_id')

    #                 accepted_time = None
    #                 arrival_time = None
    #                 pob_time = None
    #                 for status_log in status_logs:
    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'job_given':
    #                         accepted_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'arrived': 
    #                         arrival_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'pob': 
    #                         pob_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                 booking_id = change.document.id
    #                 document = {
    #                     'booking_id': booking_id,
    #                     'added_datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    #                     'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
    #                     'consumer_rating': change.document.get('customer.average_rating'),
    #                     'new': False,
    #                     'priority': '',
    #                     'update': update,
    #                     'accepted_time': accepted_time,
    #                     'arrival_time': arrival_time,
    #                     'pob_time': pob_time,
    #                     'drv': vehicle_details(change.document.to_dict().get('accepted_by', {}).get('vehicle_id')),
    #                     'address': change.document.get('pickup_location').get('address'),
    #                     'info': '',
    #                     'account': '',
    #                     'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
    #                     'via': '',
    #                     'phone': change.document.get('customer.contact'),
    #                     'consumer_name': change.document.to_dict().get('customer', {}).get('full_name'),
    #                     'zone': ''
    #                     }

    #                 print(document)
    #                 self.send(text_data=json.dumps(document))
    #                 # bookings_for_django.insert_one(document)

    #             # THIS IS FOR COMPLETED
    #             elif change.document.get('status') == 'complete' and change.document.to_dict().get('accepted_by', {}).get('driver_id') != '':
    #                 # if last_booking['update'] == 'pob' and last_booking['destination'] == change.document.get('dropOff_address'):
    #                 # print(last_booking['update'])
    #                 print(change.document.get('status'))

    #                 print(f"vehicle_id: {change.document.get('sent_to.vehicle_id')}")


    #                 status_logs = change.document.get('status_logs')
    #                 accepted_driver_id = change.document.get('accepted_by.driver_id')

    #                 accepted_time = None
    #                 arrival_time = None
    #                 pob_time = None
    #                 end_time = None
    #                 for status_log in status_logs:
    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'job_given':
    #                         accepted_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'arrived': 
    #                         arrival_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'pob': 
    #                         pob_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'complete': 
    #                         end_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                 booking_id = change.document.id
    #                 document = {
    #                     'booking_id': booking_id,
    #                     'added_datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    #                     'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
    #                     'consumer_rating': change.document.get('customer.average_rating'),
    #                     'new': False,
    #                     'priority': '',
    #                     'update': update,
    #                     'accepted_time': accepted_time,
    #                     'arrival_time': arrival_time,
    #                     'pob_time': pob_time,
    #                     'end_time': end_time,
    #                     'drv': vehicle_details(change.document.to_dict().get('accepted_by', {}).get('vehicle_id')),
    #                     'address': change.document.get('pickup_location').get('address'),
    #                     'info': '',
    #                     'account': '',
    #                     'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
    #                     'via': '',
    #                     'phone': change.document.get('customer.contact'),
    #                     'consumer_name': change.document.get('customer.full_name'),
    #                     'zone': ''
    #                     }

    #                 print(document)
    #                 self.send(text_data=json.dumps(document))
                    
    #                 # bookings_for_django.insert_one(document)


    #             # THIS IS FOR CANCELLED
    #             elif change.document.get('status') == 'cancel':
    #                 # if last_booking['update'] in ['bidding', 'dispatched', 'arrived', 'pob'] and last_booking['destination'] == change.document.get('dropOff_address'):
    #                 # print(last_booking['update'])
    #                 print(change.document.get('status'))

    #                 print(f"vehicle_id: {change.document.get('sent_to.vehicle_id')}")


    #                 status_logs = change.document.get('status_logs')
    #                 accepted_driver_id = change.document.get('accepted_by.driver_id')

    #                 accepted_time = None
    #                 arrival_time = None
    #                 pob_time = None
    #                 end_time = None
    #                 for status_log in status_logs:
    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'job_given':
    #                         accepted_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'arrived': 
    #                         arrival_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'pob': 
    #                         pob_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                     if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'complete': 
    #                         end_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
    #                     else:
    #                         pass

    #                 booking_id = change.document.id
    #                 document = {
    #                     'booking_id': booking_id,
    #                     'added_datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    #                     'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
    #                     'consumer_rating': change.document.get('customer.average_rating'),
    #                     'new': False,
    #                     'priority': '',
    #                     'update': update,
    #                     'accepted_time': accepted_time,
    #                     'arrival_time': arrival_time,
    #                     'pob_time': pob_time,
    #                     'end_time': end_time,
    #                     'drv': vehicle_details(change.document.to_dict().get('accepted_by', {}).get('vehicle_id')),
    #                     'address': change.document.get('pickup_location').get('address'),
    #                     'info': '',
    #                     'account': '',
    #                     'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
    #                     'via': '',
    #                     'phone': change.document.get('customer.contact'),
    #                     'consumer_name': change.document.get('customer.full_name'),
    #                     'zone': ''
    #                     }

    #                 print(document)
    #                 self.send(text_data=json.dumps(document))
    #                 # bookings_for_django.insert_one(document)

    #         elif change.type.name == 'REMOVED':
    #             booking_id = change.document.id
    #             booking_filter = {
    #                     'booking_id': booking_id
    #                 }
    #             # bookings_for_django.delete_many(booking_filter)
    #             print(f"all data of {booking_id} is removed from MongoDB")


    #     callback_done.set()



        # # Watch the document from Firebase in Realtime
        # doc_watch = bookings_d.on_snapshot(on_snapshot)

# if __name__ == '__main__':
#     #app.run()
#     socketio.run(app, port=7500)


'''

import json
from urllib.parse import parse_qs
# from channels.generic.websocket import AsyncWebsocketConsumer
from urllib.parse import parse_qs
from asgiref.sync import sync_to_async, async_to_sync

import motor.motor_asyncio
from channels.exceptions import StopConsumer
from pymongo import MongoClient
import gridfs
from django_celery_beat.models import PeriodicTask, IntervalSchedule
import copy

from channels.generic.websocket import WebsocketConsumer
import pymongo
from threading import Thread
import base64


myclient = pymongo.MongoClient("mongodb+srv://twidy_dashboard:9TInnovations@cluster0.8obys.mongodb.net/?retryWrites=true&w=majority")
mydb = myclient["twin_dynamics"]
mycol = mydb["fs.files"]
mycol_occu = mydb["occupants"]
mycol_sim = mydb["simulation_sensor_locations"]


class GraphConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()

        def read_stream():
            for change in mycol.watch([{
                '$match': {
                    'operationType': {'$in': ['replace', 'insert']},
                    'fullDocument.filename.business': 'Digital Media Centre',
                    'fullDocument.filename.type': 'floorplan'
                }
            }
            ]
            ):
                x = change["fullDocument"]
                fs = gridfs.GridFS(mydb)

                floor_filename_obj = x
                floor_filename_id = floor_filename_obj['_id']
                floor_output_data = fs.get(floor_filename_id).read()
                # floor_output = floor_output_data.decode()
                
                encoded_data = base64.b64encode(floor_output_data).decode()
                self.send(json.dumps({'floor_output': encoded_data}))

                # self.send(json.dumps({'floor_output': floor_output}))

        st = Thread(target=read_stream, args=())
        st.start()
        st.is_alive()

'''

'''

class GraphConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()

    def read_stream():
        for change in mycol_occu.watch([{
            '$match': {
                'operationType': {'$in': ['replace', 'insert']},
            }}]):

            O1T0 = change["fullDocument"]["data"]["o1t0"]
            O1T1 = change["fullDocument"]["data"]["o1t1"]
            O2T1 = change["fullDocument"]["data"]["o2t1"]
            O3T1 = change["fullDocument"]["data"]["o3t1"]
            O4T1 = change["fullDocument"]["data"]["o4t1"]
            O5T1 = change["fullDocument"]["data"]["o5t1"]
            O6T1 = change["fullDocument"]["data"]["o6t1"]
            O7T1 = change["fullDocument"]["data"]["o7t1"]
            O8T1 = change["fullDocument"]["data"]["o8t1"]
            O1T2 = change["fullDocument"]["data"]["o1t2"]
            O2T2 = change["fullDocument"]["data"]["o2t2"]
            O3T2 = change["fullDocument"]["data"]["o3t2"]
            O4T2 = change["fullDocument"]["data"]["o4t2"]
            O5T2 = change["fullDocument"]["data"]["o5t2"]
            O6T2 = change["fullDocument"]["data"]["o6t2"]
            O7T2 = change["fullDocument"]["data"]["o7t2"]
            O8T2 = change["fullDocument"]["data"]["o8t2"]
            O1T3 = change["fullDocument"]["data"]["o1t3"]
            O2T3 = change["fullDocument"]["data"]["o2t3"]
            O3T3 = change["fullDocument"]["data"]["o3t3"]
            O4T3 = change["fullDocument"]["data"]["o4t3"]
            O5T3 = change["fullDocument"]["data"]["o5t3"]
            O6T3 = change["fullDocument"]["data"]["o6t3"]
            O7T3 = change["fullDocument"]["data"]["o7t3"]
            O8T3 = change["fullDocument"]["data"]["o8t3"]
            O1T4 = change["fullDocument"]["data"]["o1t4"]
            O2T4 = change["fullDocument"]["data"]["o2t4"]
            O3T4 = change["fullDocument"]["data"]["o3t4"]
            O4T4 = change["fullDocument"]["data"]["o4t4"]
            O5T4 = change["fullDocument"]["data"]["o5t4"]
            O6T4 = change["fullDocument"]["data"]["o6t4"]
            O7T4 = change["fullDocument"]["data"]["o7t4"]
            O8T4 = change["fullDocument"]["data"]["o8t4"]



            data = [O1T0, O1T1, O2T1, O3T1, O4T1, O5T1, O6T1, O7T1, O8T1, O1T2, O2T2, O3T2, O4T2, O5T2, O6T2, O7T2, O8T2,
                O1T3, O2T3, O3T3, O4T3, O5T3, O6T3, O7T3, O8T3, O1T4, O2T4, O3T4, O4T4, O5T4, O6T4, O7T4, O8T4]


'''












# from django_celery_beat.models import PeriodicTask, IntervalSchedule

# class StockConsumer(AsyncWebsocketConsumer):

#     @sync_to_async
#     def addToCeleryBeat(self):
#         task = PeriodicTask.objects.filter(name = "every-1-seconds")
#         if len(task)>0:
#             print("hello")  # testing that task.first() will work or not
#             task = task.first()
#             args = json.loads(task.args)
#             args = args[0]
#             # for x in stockpicker:
#             #     if x not in args:
#             #         args.append(x)
#             # task.args = json.dumps([args])
#             # task.save()
#         else:
#             schedule, created = IntervalSchedule.objects.get_or_create(every=1, period = IntervalSchedule.SECONDS)
#             task = PeriodicTask.objects.create(interval = schedule, name='every-1-seconds', task="mainapp.tasks.update_stock") # , args = json.dumps([stockpicker]))


#     async def connect(self):
#         self.room_name = self.scope["url_route"]["kwargs"]["room_name"]
#         print(self.room_name)
#         self.room_group_name = "stock_%s" % self.room_name

#         # Join room group
#         await self.channel_layer.group_add(self.room_group_name, self.channel_name)

#         # # Parse query_string
#         # query_params = parse_qs(self.scope["query_string"].decode())

#         # print(query_params)
#         # stockpicker = query_params['stockpicker']

#         # add to celery beat
#         await self.addToCeleryBeat()

#         await self.accept()

#     async def disconnect(self, close_code):
#         # Leave room group
#         await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

#     # Receive message from WebSocket
#     async def receive(self, text_data):
#         text_data_json = json.loads(text_data)
#         message = text_data_json["message"]

#         # Send message to room group
#         await self.channel_layer.group_send(
#             self.room_group_name, {"type": "stock_update", "message": message}
#         )

#     # Receive message from room group
#     async def send_stock_update(self, event):
#         message = event["message"]
#         print(message)

#         # Send message to WebSocket
#         await self.send(text_data=json.dumps(message))





# # class MongoConsumer(AsyncWebsocketConsumer):
# #     async def connect(self):
# #         self.accept()

# #         # Set up MongoDB change stream
# #         self.client = MongoClient("mongodb+srv://shahid_123:iRRHpdYoWApzFkWw@trymedriver.nmfto.mongodb.net/?retryWrites=true&w=majority")
# #         self.db = self.client['trymeTaxiDatabase']
# #         self.drivers_collection = self.db['drivers']
# #         self.vehicles_collection = self.db['vehicles']
# #         self.change_stream = self.drivers_collection.watch()

# #         # Start listening for changes
# #         async_to_sync(self.listen_for_changes)()

# #     async def disconnect(self, close_code):
# #         # Close change stream
# #         self.change_stream.close()

# #         # Raise StopConsumer to halt the connection
# #         raise StopConsumer

# #     async def listen_for_changes(self):

# #         pipeline = [
# #             {"$match": {
# #                 "$and": [
# #                     {"fullDocument.isLive": True},
# #                     {"fullDocument.company_info.company_name": "Taxi Base A (Birmingham)"},
# #                     {"operationType": {"$in": ["insert", "delete", "update", "replace"]}}
# #                 ]
# #             }}
# #         ]

        
# #         with self.drivers_collection.watch(pipeline) as stream:

# #             # Loop over the change stream and send changes to the client
# #             for change in stream:

# #                 # Get the change event type
# #                 event_type = change['operationType']

# #                 if event_type == 'update':
# #                     await (self.send_json)({'message': 'Document updated', 'document_key': change['documentKey']})


# #                 # Send change to client
# #                 await self.send(text_data=str(change))



# # import motor.motor_asyncio

# # class MongoConsumer(AsyncWebsocketConsumer):
# #     async def connect(self):
# #         self.accept()

# #         # Set up MongoDB change stream
# #         self.client = motor.motor_asyncio.AsyncIOMotorClient("mongodb+srv://shahid_123:iRRHpdYoWApzFkWw@trymedriver.nmfto.mongodb.net/?retryWrites=true&w=majority")
# #         self.db = self.client['trymeTaxiDatabase']
# #         self.drivers_collection = self.db['drivers']
# #         self.vehicles_collection = self.db['vehicles']

# #         # Start listening for changes
# #         await self.listen_for_changes()

# #     async def disconnect(self, close_code):
# #         # Close the connection
# #         self.client.close()

# #         # Raise StopConsumer to halt the connection
# #         raise StopConsumer

# #     async def listen_for_changes(self):

# #         pipeline = [
# #             {"$match": {
# #                 "$and": [
# #                     {"fullDocument.isLive": True},
# #                     {"fullDocument.company_info.company_name": "Taxi Base A (Birmingham)"},
# #                     {"operationType": {"$in": ["insert", "delete", "update", "replace"]}}
# #                 ]
# #             }}
# #         ]

# #         # Create the change stream
# #         change_stream = self.drivers_collection.watch(pipeline)

# #         async for change in change_stream:
# #             # Get the change event type
# #             event_type = change['operationType']

# #             if event_type == 'update':
# #                 await self.send_json({'message': 'Document updated', 'document_key': change['documentKey']})

# #             # Send change to client
# #             await self.send(text_data=str(change))