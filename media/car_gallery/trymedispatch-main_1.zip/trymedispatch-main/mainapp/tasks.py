# from celery import shared_task
# from yahoo_fin.stock_info import *
# import queue
# from threading import Thread
# from channels.layers import channel_layers
# from pymongo import MongoClient
# from channels.layers import get_channel_layer

# import asyncio
# import simplejson as json

# def process_driver(q, driver):

#     cluster = MongoClient("mongodb+srv://shahid_123:iRRHpdYoWApzFkWw@trymedriver.nmfto.mongodb.net/?retryWrites=true&w=majority")  # Replace with your MongoDB connection URL
#     m_db = cluster['trymeTaxiDatabase']
#     m_vehicles = m_db['vehicles']

#     vehicle_filter = {
#             'driver_id': driver['driver_id']
#         }
#     result = {
#         driver['driver_id']: {
#             'vehicle_id': m_vehicles.find_one(vehicle_filter, sort = [('_id', pymongo.DESCENDING)])['ref'],
#             'job_status': driver,
#             'driver_coords': {
#                 'lat': driver['current_location']['coordinates'][1],
#                 'lng': driver['current_location']['coordinates'][0]
#             }
#         }
#     }
#     q.put(result)

# @shared_task(bind = True)
# def update_stock(self):

#     cluster = MongoClient("mongodb+srv://shahid_123:iRRHpdYoWApzFkWw@trymedriver.nmfto.mongodb.net/?retryWrites=true&w=majority")  # Replace with your MongoDB connection URL
#     m_db = cluster['trymeTaxiDatabase']
#     m_drivers = m_db['drivers']

#     pipeline = [
#         {"$match": {
#             "$and": [
#                 {"isLive": True},
#                 {"company_info.company_name": "Taxi Base A (Birmingham)"}
#             ]
#         }}
#     ]

#     drivers = m_drivers.aggregate(pipeline)

#     data = {}

#     thread_list = []
#     que = queue.Queue()

#     for driver in drivers:
#         thread = Thread(target = lambda q, arg1: process_driver, args=(que, driver))
#         thread.start()
#         thread_list.append(thread)

#     for thread in thread_list:
#         thread.join()

#     while not que.empty():
#         result = que.get()
#         data.update(result)

#     # send data to group
#     channel_layer = get_channel_layer()
#     loop = asyncio.new_event_loop()

#     asyncio.set_event_loop(loop)

#     loop.run_until_complete(channel_layer.group_send("stock_track", {
#         'type': 'send_stock_update',
#         'message': data,
#     }))

#     return 'Done'   





# @shared_task(bind = True)
# def update_stock(self):

#     cluster = MongoClient("mongodb+srv://shahid_123:iRRHpdYoWApzFkWw@trymedriver.nmfto.mongodb.net/?retryWrites=true&w=majority")  # Replace with your MongoDB connection URL
#     m_db = cluster['trymeTaxiDatabase']
#     m_drivers = m_db['drivers']

#     pipeline = [
#         {"$match": {
#             "$and": [
#                 {"fullDocument.isLive": True},
#                 {"fullDocument.company_info.company_name": "Taxi Base A (Birmingham)"},
#                 {"operationType": {"$in": ["insert", "delete", "update", "replace"]}}
#             ]
#         }}
#     ]

    
#     with m_drivers.watch(pipeline) as stream:
#         for change in stream:
#             data = change

#     # send data to group
#     channel_layer = get_channel_layer()
#     loop = asyncio.new_event_loop()

#     asyncio.set_event_loop(loop)

#     loop.run_until_complete(channel_layer.group_send("stock_track", {
#         'type': 'send_stock_update',
#         'message': data,
#     }))

#     return 'Done'















# @shared_task(bind = True)
# def update_stock(self, stockpicker):
#     data = {}
#     available_stocks = tickers_nifty50()
#     print(available_stocks)
#     for i in stockpicker:
#         if i in available_stocks:
#             details = get_quote_data
#             print(details)
#             pass
#         else:
#             stockpicker.remove(i)

#     n_threads = len(stockpicker)
#     data = {}

#     thread_list = []
#     que = queue.Queue()

#     for i in range(n_threads):
#         thread = Thread(target=lambda q, arg1: q.put({stockpicker[i]: get_quote_table(arg1)}), args = (que, stockpicker[i]))
#         thread_list.append(thread)
#         thread_list[i].start()

#     for thread in thread_list:
#         thread.join()

#     while not que.empty():
#         result = que.get()
#         data.update(result)

#      # send data to group
#     channel_layer = get_channel_layer()
#     loop = asyncio.new_event_loop()

#     asyncio.set_event_loop(loop)

#     loop.run_until_complete(channel_layer.group_send("stock_track", {
#         'type': 'send_stock_update',
#         'message': data,
#     }))

#     return 'Done'