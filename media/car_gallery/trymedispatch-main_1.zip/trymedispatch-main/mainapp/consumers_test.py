from channels.generic.websocket import WebsocketConsumer
import firebase_admin
from firebase_admin import credentials, firestore
import threading
import pytz
import pymongo
from datetime import datetime

cluster = pymongo.MongoClient("mongodb+srv://shahid_123:iRRHpdYoWApzFkWw@trymedriver.nmfto.mongodb.net/?retryWrites=true&w=majority")
m_db = cluster['trymeTaxiDatabase']
bookings_for_django = m_db['bookings_for_django']
m_vehicles = m_db['vehicles']

#####################################
##### Firebase initial System Setup
cred = credentials.Certificate("/mnt/app_data/TryMe.Taxi/OneDrive-2023-10-21/job_allocation/service_account_key.json")
firebase_admin.initialize_app(cred)

f_db = firestore.client()

# Create an Event for notifying main thread.
callback_done = threading.Event()

bookings_d = f_db.collection_group(u'bookings')
docs = bookings_d.stream()

class GraphConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()

        def vehicle_details(vehicle_id):
            print(vehicle_id)
            vehicle = m_vehicles.find_one({'vehicle_id': vehicle_id})
            if vehicle is not None:
                ref = vehicle['ref'] # {'vehicle_id': 'lbveqyXN3zfmv7X9OCF8XlZ2u1g2AA11AAA'}
            else:
                ref = ''
            return ref

        def on_snapshot(doc_snapshot, changes, read_time):

            print('doc_watch is running')
            print(read_time)

            for change in changes:


                #########################################################
                ####### IF BOOKING DOCUMENT IS ADDED
                #########################################################

                if change.type.name == 'ADDED':

                    # THIS IS FOR NEW JOB OR PRE-BOOKING
                    if change.document.get('status') not in ['cancel', 'complete']:

                        if change.document.get('status') == 'pending':
                            update = 'bidding'
                        elif change.document.get('status') == 'job_given':
                            update = 'dispatched'
                        else:
                            update = change.document.get('status')

                        lead_time = change.document.get('pickup_time')
                        if lead_time is not None:
                            lead_time = lead_time.astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            lead_time = ''

                        print(f"vehicle_id: {change.document.get('sent_to.vehicle_id')}")
                        booking_id = change.document.id
                        document = {
                            'booking_id': booking_id,
                            'added_datetime': datetime.now(),
                            'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
                            'lead_time': lead_time,
                            'consumer_rating': change.document.get('customer.average_rating'),
                            'new': True,
                            'priority': '',
                            'update': update,
                            'drv': vehicle_details(change.document.to_dict().get('sent_to', {}).get('vehicle_id')),
                            'address': change.document.get('pickup_location', {}).get('address'),
                            'info': '',
                            'account': '',
                            'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
                            'via': '',
                            'phone': change.document.get('customer', {}).get('contact'),
                            'consumer_name': change.document.to_dict().get('customer', {}).get('full_name'),
                            'zone': ''
                            }

                        print(document)
                        # bookings_for_django.insert_one(document)

                    else:
                        pass

                elif change.type.name == 'MODIFIED':
                    # if change.document.get('status') not in ['cancel', 'completed']:

                    if change.document.get('status') == 'pending':
                        update = 'bidding'
                    elif change.document.get('status') == 'job_given':
                            update = 'dispatched'
                    else:
                        update = change.document.get('status')

                    booking_id = change.document.id
                    booking_filter = {
                            'booking_id': booking_id
                        }
                    last_booking = bookings_for_django.find_one(booking_filter, sort = [('_id', pymongo.DESCENDING)])

                    lead_time = change.document.get('pickup_time')
                    if lead_time is not None:
                        lead_time = lead_time.astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                    else:
                        lead_time = ''

                    # THIS IS FOR DISPATCHING
                    if change.document.to_dict().get('sent_to', {}).get('driver_id') != '' and change.document.get('status') == 'pending':
                        if last_booking['update'] == 'bidding' and last_booking['destination'] == change.document.get('dropOff_address') and last_booking['drv'] == '':
                        
                            print(last_booking['update'])
                            print(change.document.get('status'))

                            print(f"vehicle_id: {change.document.to_dict().get('sent_to', {}).get('vehicle_id')}")
                            print(f"modified_dispatched")
                            booking_id = change.document.id
                            document = {
                                'booking_id': booking_id,
                                'added_datetime': datetime.now(),
                                'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
                                'lead_time': lead_time,
                                'consumer_rating': change.document.get('customer.average_rating'),
                                'new': False,
                                'priority': '',
                                'update': update,
                                'drv': vehicle_details(change.document.to_dict().get('sent_to', {}).get('vehicle_id')),
                                'address': change.document.get('pickup_location', {}).get('address'),
                                'info': '',
                                'account': '',
                                'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
                                'via': '',
                                'phone': change.document.get('customer.contact'),
                                'consumer_name': change.document.to_dict().get('customer', {}).get('full_name'),
                                'zone': ''
                                }

                            print(document)
                            # bookings_for_django.insert_one(document)

                    # THIS IS FOR BOOKED
                    elif change.document.get('status') in ['job_given', 'arrived', 'pob'] and change.document.to_dict().get('accepted_by', {}).get('driver_id') != '':
                        if last_booking['update'] in ['bidding', 'dispatched', 'arrived', 'pob'] and last_booking['destination'] == change.document.get('dropOff_address'):
                            print(last_booking['update'])
                            print(change.document.get('status'))

                            print(f"vehicle_id: {change.document.get('sent_to.vehicle_id')}")


                            status_logs = change.document.get('status_logs')
                            accepted_driver_id = change.document.get('accepted_by.driver_id')

                            accepted_time = None
                            arrival_time = None
                            pob_time = None
                            for status_log in status_logs:
                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'job_given':
                                    accepted_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'arrived': 
                                    arrival_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'pob': 
                                    pob_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                            booking_id = change.document.id
                            document = {
                                'booking_id': booking_id,
                                'added_datetime': datetime.now(),
                                'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
                                'consumer_rating': change.document.get('customer.average_rating'),
                                'new': False,
                                'priority': '',
                                'update': update,
                                'accepted_time': accepted_time,
                                'arrival_time': arrival_time,
                                'pob_time': pob_time,
                                'drv': vehicle_details(change.document.to_dict().get('accepted_by', {}).get('vehicle_id')),
                                'address': change.document.get('pickup_location', {}).get('address'),
                                'info': '',
                                'account': '',
                                'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
                                'via': '',
                                'phone': change.document.get('customer.contact'),
                                'consumer_name': change.document.to_dict().get('customer', {}).get('full_name'),
                                'zone': ''
                                }

                            print(document)
                            # bookings_for_django.insert_one(document)

                    # THIS IS FOR COMPLETED
                    elif change.document.get('status') == 'complete' and change.document.to_dict().get('accepted_by', {}).get('driver_id') != '':
                        if last_booking['update'] == 'pob' and last_booking['destination'] == change.document.get('dropOff_address'):
                            print(last_booking['update'])
                            print(change.document.get('status'))

                            print(f"vehicle_id: {change.document.get('sent_to.vehicle_id')}")


                            status_logs = change.document.get('status_logs')
                            accepted_driver_id = change.document.get('accepted_by.driver_id')

                            accepted_time = None
                            arrival_time = None
                            pob_time = None
                            end_time = None
                            for status_log in status_logs:
                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'job_given':
                                    accepted_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'arrived': 
                                    arrival_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'pob': 
                                    pob_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'complete': 
                                    end_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                            booking_id = change.document.id
                            document = {
                                'booking_id': booking_id,
                                'added_datetime': datetime.now(),
                                'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
                                'consumer_rating': change.document.get('customer.average_rating'),
                                'new': False,
                                'priority': '',
                                'update': update,
                                'accepted_time': accepted_time,
                                'arrival_time': arrival_time,
                                'pob_time': pob_time,
                                'end_time': end_time,
                                'drv': vehicle_details(change.document.to_dict().get('accepted_by', {}).get('vehicle_id')),
                                'address': change.document.get('pickup_location', {}).get('address'),
                                'info': '',
                                'account': '',
                                'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
                                'via': '',
                                'phone': change.document.get('customer.contact'),
                                'consumer_name': change.document.get('customer.full_name'),
                                'zone': ''
                                }

                            print(document)
                            # bookings_for_django.insert_one(document)


                    # THIS IS FOR CANCELLED
                    elif change.document.get('status') == 'cancel':
                        if last_booking['update'] in ['bidding', 'dispatched', 'arrived', 'pob'] and last_booking['destination'] == change.document.get('dropOff_address'):
                            print(last_booking['update'])
                            print(change.document.get('status'))

                            print(f"vehicle_id: {change.document.get('sent_to.vehicle_id')}")


                            status_logs = change.document.get('status_logs')
                            accepted_driver_id = change.document.get('accepted_by.driver_id')

                            accepted_time = None
                            arrival_time = None
                            pob_time = None
                            end_time = None
                            for status_log in status_logs:
                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'job_given':
                                    accepted_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'arrived': 
                                    arrival_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'pob': 
                                    pob_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                                if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'complete': 
                                    end_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    pass

                            booking_id = change.document.id
                            document = {
                                'booking_id': booking_id,
                                'added_datetime': datetime.now(),
                                'datetime': change.document.get('booking_time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S'),
                                'consumer_rating': change.document.get('customer.average_rating'),
                                'new': False,
                                'priority': '',
                                'update': update,
                                'accepted_time': accepted_time,
                                'arrival_time': arrival_time,
                                'pob_time': pob_time,
                                'end_time': end_time,
                                'drv': vehicle_details(change.document.to_dict().get('accepted_by', {}).get('vehicle_id')),
                                'address': change.document.get('pickup_location', {}).get('address'),
                                'info': '',
                                'account': '',
                                'destination': change.document.get('dropOff_location')[-1].get('address') if change.document.get('dropOff_location') else None,
                                'via': '',
                                'phone': change.document.get('customer.contact'),
                                'consumer_name': change.document.get('customer.full_name'),
                                'zone': ''
                                }

                            print(document)
                            # bookings_for_django.insert_one(document)

                elif change.type.name == 'REMOVED':
                    booking_id = change.document.id
                    booking_filter = {
                            'booking_id': booking_id
                        }
                    # bookings_for_django.delete_many(booking_filter)
                    print(f"all data of {booking_id} is removed from MongoDB")


            callback_done.set()



        # Watch the document from Firebase in Realtime
        doc_watch = bookings_d.on_snapshot(on_snapshot)

# if __name__ == '__main__':
#     #app.run()
#     socketio.run(app, port=7500)