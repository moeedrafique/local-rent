from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.signin, name='signin'),
    path('operator/', views.operator_page, name='operator_page'),
    path('operator/get_taxi_base_details/', views.get_taxi_base_details, name='get_taxi_base_details'),
    path('operator/drivers_available/', views.drivers_available, name='drivers_available'),
    path('operator/realtime_drivers_movement/', views.realtime_drivers_movement, name='realtime_drivers_movement'),
    path("stocktracker/", views.stockTracker, name = 'stocktracker'),
    path("stockpicker/", views.stockPicker, name = 'stockpicker'),
    path("operator/live_bookings/", views.live_bookings, name='live_bookings'),
    path('logout/', views.logout, name='logout'),
    path('operator/get_firebase_config/', views.get_firebase_config, name='get_firebase_config'),
    path('operator/allbookings/', views.allBookings, name='allBookings'),
    # path('operator/render-table/', views.render_page_with_table, name='render-table'),
    path('operator/get-booking-details/', views.get_booking_details, name='get-booking-details'),
    path('operator/get-chat-details/', views.get_chat_details, name='get-chat-details'),
    path('operator/get-driver-details/', views.get_driver_details, name='get-driver-details'),
    path('operator/search-bookings/', views.search_bookings, name='search-bookings'),
    path('operator/render-booking-with-table/', views.render_booking_with_table, name='render-booking-with-table'),
    path('operator/render-driver-with-table/', views.render_drivers_with_table, name='render-driver-with-table'),
    path('operator/render-customers-with-table/', views.render_customers_with_table, name='render-customers-with-table'),
    path('operator/get-log-details/', views.get_log_details, name='get-log-details'),
    path('operator/geojson-view/', views.geojson_view, name='geojson-view'),


    #MANAGE_SECTION PAGES 
    path('accounts/', views.accounts, name='accounts'),
    path('new-account/', views.new_account, name='new-account'),
    path('areas/', views.areas, name='areas'),

    path('customers/', views.customers, name='customers'),
    path('customers/consumer-detail/', views.consumer_detail, name='consumer-detail'),
    path('customers/update-consumer-details/', views.update_consumer_details, name='update-consumer-details'),
    path('customers/customer-addresses/', views.customer_addresses, name='customer-addresses'),
    path('customer-detail/', views.customer_detail, name='customer-detail'), ### WEB PAGE REDIRECTION
    

    path('drivers/', views.drivers, name='drivers'),
    path('vehicles/get-vehicle-status/', views.get_vehicle_status, name='get-vehicle-status'),

    path('staff/', views.staff, name='staff'),

    path('vehicles/', views.vehicles, name='vehicles'),
    path('vehicles/render-vehicles-with-table/', views.render_vehicles_with_tables, name='render-vehicles-with-table'),
    path('vehicle-detail/', views.vehicle_detail, name='vehicle-detail'), ### WEB PAGE REDIRECTION
    path('vehicles/vehicle-detail-request/', views.vehicle_detail_request, name='vehicle-detail-request'),
    path('vehicles/update-vehicle-details/', views.update_vehicle_details, name='update-vehicle-details'),
    path('vehicles/vehicle-document-request/', views.vehicle_document_request, name='vehicle-document-request'),
    path('vehicles/update-vehicle-document/', views.update_vehicle_document, name='update-vehicle-document'),
    path('vehicles/admin-vehicle-status/', views.admin_vehicle_status, name='admin-vehicle-status'),
    path('vehicles/new-vehicle/', views.new_vehicle, name='new-vehicle'),

    path('import/', views.imports, name='import'),
    path('restore/', views.restore, name='restore'),
    path('draw/', views.draw, name='draw'),
    path('new-driver/', views.new_driver, name='new-driver'),
    path('new-staff/', views.new_staff, name='new-staff'),



    ### GENERIC ADDRESSES --> CAN BE USED IN ANY PAGE
    path('google-maps/', views.google_maps, name='google-maps'),
    path('get_attributes/', views.get_attributes, name='get_attributes'),



    ### BACKEND PYTHON CODE RELATED UI
    path('backend-ui/', views.backend_ui, name='backend-ui'),
    path('backend-ui/bookings-allocation-python/', views.bookings_allocation_python, name='bookings-allocation-python'),
    path('backend-ui/flask-project-logs/', views.flask_project_logs, name='flask-project-logs'),

    path('backend-ui/service-logs/', views.get_service_logs, name='get_service_logs'),


]