# from django.core.asgi import get_asgi_application
from django.urls import path, re_path
from .consumers import GraphConsumer

websocket_urlpatterns = [
    path('ws/graph/', GraphConsumer.as_asgi()),
]