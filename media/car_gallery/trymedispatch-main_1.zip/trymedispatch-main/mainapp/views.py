import pyrebase
from django.shortcuts import render, redirect
from django.contrib import messages
from django.conf import settings
import firebase_admin
from firebase_admin import credentials, auth, firestore
from google.cloud.firestore_v1.base_query import FieldFilter
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from pymongo import MongoClient
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.template.loader import render_to_string
import os
from django.shortcuts import render
import pymongo
import googlemaps
from django.http import HttpResponseRedirect
from django.http import JsonResponse, QueryDict
import json
from bson.json_util import dumps
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
import magic
import queue
from threading import Thread
from .routing import websocket_urlpatterns
from yahoo_fin.stock_info import *
import uuid
from firebase_admin import storage
import subprocess
from datetime import datetime, timedelta
import time
import pytz
from django.conf import settings
from django.core.files.storage import default_storage
import geopandas as gpd
from django.contrib.staticfiles import finders
from django.shortcuts import get_object_or_404
from urllib.parse import quote
from google.api_core.datetime_helpers import DatetimeWithNanoseconds

# Google Maps API
f = open('api_key.txt', 'r')
API_KEY = f.read()

def fb_config(request):
    firebase_config = settings.CONFIG
    return firebase_config

def md_config():
    mongodb_config = settings.MD_CONFIG
    return mongodb_config

def gm_config():
    googlemaps_config = settings.GM_CONFIG
    return googlemaps_config

def file_paths():
    file_path_config = settings.FILE_PATHS
    return file_path_config

def file_names():
    file_name_config = settings.FILE_NAMES
    return file_name_config

# Initialize Firebase
# cred = credentials.Certificate('firebase_cred.json')
# cred = credentials.Certificate(settings.FB_CONFIG)
# firebase_admin.initialize_app(cred)

if not firebase_admin._apps:
    cred = credentials.Certificate(settings.FB_CONFIG)
    firebase_admin.initialize_app(cred, {
        'storageBucket': 'tryme-taxi.appspot.com'
    })

def get_firebase_config(request):
    firebase_config = fb_config(request)

    return JsonResponse({'firebaseConfig': firebase_config})

@csrf_exempt
def signin(request):
    print(request.META)
    if request.method == 'POST':
        firebase = pyrebase.initialize_app(fb_config(request))
        auth = firebase.auth()
        email = request.POST.get('email')
        password = request.POST.get('password')


        # if email is not None:
        #     # A backend authenticated the credentials
        #     # login(request, user)
        #     user = auth.sign_in_with_email_and_password(email, password)
        #     # Then redirect to your desired page in the other app
        #     HttpResponse('authenticated')
        #     # return redirect('operator_page')
        # else:
        #     # No backend authenticated the credentials
        #     return render(request, 'signn/signin.html', {'error': 'Invalid login credentials'})



        try:
            user = auth.sign_in_with_email_and_password(email, password)


            context = {
                'message': "You have been successfully logged in!",
                'email': email,
                'company_name': 'Hir3d Birmingham'
            }


            # request.session['uid'] = str(user['idToken'])
            print('authenticated')
            # HttpResponse('authenticated')
            request.session['additional_data'] = context

            # print(request.session['additional_data'])

            return redirect('operator_page')
        except:
            message = "Invalid credentials"
            print('not authenticated')
            return render(request, 'mainapp/signin.html', {"message": message})
            # return HttpResponse('not authenticated')  # render(request, "login.html", {"message": message})

    # If request.method is not POST, render the sign in page.
    return render(request, 'mainapp/signin.html')

def get_user_details(request):
    cluster = MongoClient(md_config()['client'])
    m_db = cluster[md_config()['cluster']]
    m_users = m_db[md_config()['users']]

    logged_in_user_email = request.session.get('additional_data', {}).get('email', None)

    my_filter = {
        'email': logged_in_user_email
    }

    driver_fields = {"first_name": 1}
    document = m_users.find_one(my_filter, driver_fields)

    return document


def logout(request):
    try:
        del request.session['additional_data']  # or whatever key you have used
    except KeyError:
        pass
    return redirect('signin')



        # message = "You have been successfully logged in!"
        # print(user)
        # return render(request, "operator_page/operator_page.html", context) # HttpResponse('next_page') # render(request, "login.html", {"message": message})

    # return render(request, "mainapp/signin.html")



def get_formatted_address_gmaps(address, api_key):
    gmaps = googlemaps.Client(key=api_key)
    geocode_result = gmaps.geocode(address)
    
    if geocode_result:
        return geocode_result[0]['formatted_address']
    
    return None

def geocode(address):
    gmaps = googlemaps.Client(API_KEY);
    geocode_result = gmaps.geocode(address)


    if geocode_result and len(geocode_result) > 0:
            location = geocode_result[0]['geometry']['location']
            return location['lat'], location['lng']
    else:
        return None

def taxibases_list(request):

    cluster = MongoClient(md_config()['client'])
    m_db = cluster[md_config()['cluster']]
    taxi_bases_col = m_db[md_config()['taxibases']]



    filter_data = {

        }


    taxi_bases = taxi_bases_col.find(filter_data, sort = [('_id', pymongo.DESCENDING)])

    taxi_base_name = []
    for taxi_base in taxi_bases:
        # taxi_base_name.append(taxi_base['taxibase_council'])
        taxi_base_name.append(taxi_base['company_name'])

    return taxi_base_name



def user_list(request, user_role, userfields):
    if request == 'GET':

        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_users = m_db[md_config()['users']]

        filter_data = {
            "user_roles": {
                "$in": [user_role]
            }
        }


        users = m_users.find(filter_data, userfields, sort = [('_id', pymongo.DESCENDING)])

        user_details = []
        for user in users:
            user_details.append(
                user
            )

        return user_details

    return JsonResponse({'error': 'Invalid request method'})  


def operator_page(request):

    user = get_user_details(request)
    username = user['first_name']

    print(request.META)

    additional_data = request.session.get('additional_data')
    print(f'additional_data: {additional_data}')
    if additional_data is not None:
        print(additional_data['email'])
    else:
        print('additional_data is None')

    tb_list = taxibases_list(request)
    default_tb = default_taxi_base(additional_data['email'])

    print(f'Taxi Base: {tb_list}')


    cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
    m_db = cluster[md_config()['cluster']]
    m_drivers = m_db[md_config()['drivers']]

    pipeline = [
        {"$match": {
            "$and": [
                {"isLive": True},
                {"company_info.company_name": additional_data['company_name']}
            ]
        }}
    ]

    drivers = m_drivers.aggregate(pipeline)

    start_time = time.time()
    data = {}

    thread_list = []
    que = queue.Queue()

    for driver in drivers:
        thread = Thread(target = lambda q, arg1: process_driver, args=(que, driver))
        thread.start()
        thread_list.append(thread)

    for thread in thread_list:
        thread.join()

    while not que.empty():
        result = que.get()
        data.update(result)

    end_time = time.time()
    delta_t = end_time - start_time

    print(delta_t)
    print(data)

    # booking_table = render_booking_with_table()
    # driver_table = render_drivers_with_table()

    context = {
            'taxi_bases': tb_list,
            'taxi_base_details': default_tb,
            'data': data,
            'room_name': 'track',
            'username': username,
            # 'booking_table': booking_table,
            # 'driver_table': driver_table
        }
    
   

    # print(booking_table)


    # return HttpResponse('next_page')
    return render(request, "mainapp/operator_page.html", context)


@csrf_exempt
def get_taxi_base_details(request):
    if request.method == 'POST':
        select_different_tb = request.POST.get('taxi_base')
        # You now have the selected option in the variable 'selected_option'
        # Do something with this option, then redirect or render a template
        # For example, redirect back to the same page:

        different_tb = different_taxi_base(select_different_tb)

        context = {
            'taxi_base_details': different_tb
        }

        return JsonResponse(context)



def different_taxi_base(select_different_tb):
    cluster = MongoClient(md_config()['client'])
    m_db = cluster[md_config()['cluster']]
    taxi_bases = m_db[md_config()['taxibases']]

    print(f'select_different_tb: {select_different_tb}')

    filter_data = {
        'company_name': select_different_tb
        }


    taxi_base_address = geocode(taxi_bases.find_one(filter_data, sort = [('_id', pymongo.DESCENDING)])['business_address'])
    
    print(f'taxi_base_address: {taxi_base_address}')

    taxi_base_details = {
            'taxi_base': select_different_tb,
            'coordinates': {
                    'lat': taxi_base_address[0],
                    'lng': taxi_base_address[1]
                }
        }

    return taxi_base_details


def default_taxi_base(email):
    cluster = MongoClient(md_config()['client'])
    m_db = cluster[md_config()['cluster']]
    users = m_db[md_config()['users']]
    drivers = m_db[md_config()['drivers']]
    taxi_bases = m_db[md_config()['taxibases']]

    # email = 'noukhezahmed@gmail.com'

    filter_data = {
            'email': email
        }


    user_id = users.find_one(filter_data, sort = [('_id', pymongo.DESCENDING)])['_id']

    filter_data = {
            '_id': user_id
        }

    company_id = drivers.find_one(filter_data, sort = [('_id', pymongo.DESCENDING)])['company_info']['company_id']

    filter_data = {
            'taxi_base_id': company_id
        }

    company_name = taxi_bases.find_one(filter_data, sort = [('_id', pymongo.DESCENDING)])['company_name']

    filter_data = {
        'company_name': company_name
        }


    taxi_base_address = geocode(taxi_bases.find_one(filter_data, sort = [('_id', pymongo.DESCENDING)])['business_address'])

    taxi_base_details = {
            'taxi_base': company_name,
            'coordinates': {
                    'lat': taxi_base_address[0],
                    'lng': taxi_base_address[1]
                }
        }

    return taxi_base_details


def get_user_business_address(email):
    cluster = MongoClient(md_config()['client'])
    m_db = cluster[md_config()['cluster']]
    users = m_db[md_config()['users']]
    drivers = m_db[md_config()['drivers']]
    taxi_bases = m_db[md_config()['taxibases']]

    # email = 'noukhezahmed@gmail.com'

    filter_data = {
            'email': email
        }


    user_id = users.find_one(filter_data, sort = [('_id', pymongo.DESCENDING)])['_id']

    filter_data = {
            '_id': user_id
        }

    company_id = drivers.find_one(filter_data, sort = [('_id', pymongo.DESCENDING)])['company_info']['company_id']

    filter_data = {
            'taxi_base_id': company_id
        }

    business_address = taxi_bases.find_one(filter_data, sort = [('_id', pymongo.DESCENDING)])['business_address']


    return business_address


@csrf_exempt
def realtime_drivers_movement(request):
    if request.method == 'POST':
        taxibase_council = request.POST.get('taxi_base')
        cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
        # db = client.mydatabase  # Replace "mydatabase" with your database name
        # collection = db.mycollection  # Replace "mycollection" with your collection name
        m_db = cluster[md_config()['cluster']]
        drivers = m_db[md_config()['drivers']]
        vehicles = m_db[md_config()['vehicles']]

        # taxibase_council = 'Taxi Base A (Birmingham)'

        # change_stream = drivers.watch([{
        #         '$'
        #     }])

        with drivers.watch() as stream:
            for change in stream:
                if 'updateDescription' in change:
                    # updated_fields = change['updateDescription']['updatedFields']

                    document_key = change['documentKey']
                    document_id = document_key['_id']
                    # print(document_id)

                    # print(updated_fields)

                    # print(updated_fields.id)

                    filter_data = {
                            'isLive': True,
                            'company_info.company_name': taxibase_council,
                            '_id': document_id
                        }

                    driver = drivers.find_one(filter_data, sort = [('_id', pymongo.DESCENDING)])

                    vehicle_filter = {
                            'driver_id': document_id
                        }


                    drivers_data = {
                            'vehicle_id': vehicles.find_one(vehicle_filter, sort = [('_id', pymongo.DESCENDING)])['reference'],
                            'driver_coords': {
                                    'lat': driver['current_location']['coordinates'][1],
                                    'lng': driver['current_location']['coordinates'][0]
                                }
                            }

                    print(drivers_data)

                    context = drivers_data


                    channel_layer = get_channel_layer()
                    async_to_sync(channel_layer.group_send)(
                        'realtime_drivers_movement',
                        {
                            'type': 'drivers_movement',
                            'text': drivers_data
                        }
                    )


                    return HttpResponse() # JsonResponse(context, safe=False)

'''
def realtime_drivers_movement(request):
    # ... your existing code ...

    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        'realtime_drivers_movement',
        {
            'type': 'drivers_movement',
            'text': drivers_data
        }
    )

    return HttpResponse()
'''

@csrf_exempt
def drivers_available(request):
    if request.method == 'POST':
        taxibase_council = request.POST.get('taxi_base')
        cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
        m_db = cluster[md_config()['cluster']]
        m_drivers = m_db[md_config()['drivers']]
        m_vehicles = m_db[md_config()['vehicles']]
        m_users = m_db[md_config()['users']]

        print(taxibase_council)

        drivers_data = []
            
        pipeline = [
            {
                "$match": {
                    "$and": [
                        {"isLive": True},
                        {"company_info.company_name": taxibase_council}
                    ]
                }    
            },
            {
                "$project": {
                    "_id": 1, 
                    "driver_id": 1, 
                    "job_status": 1, 
                    "current_location": 1
                }
            }
        ]

        drivers = m_drivers.aggregate(pipeline)

        # results = []

        for driver in drivers:

            driver_filter = {'_id': driver.get('driver_id', '')}
            vehicle_filter = {'driver_id': driver.get('driver_id', '')}
            
            job_status = driver.get('job_status', '')
            # latitude = {'driver_id': driver.get('current_location', {}).get('coordinates', '')}
            latitude = driver.get('current_location', {}).get('coordinates', [])[1] if driver.get('current_location', {}).get('coordinates') else None
            longitude = driver.get('current_location', {}).get('coordinates', [])[0] if driver.get('current_location', {}).get('coordinates') else None
            
            m_users_find = m_users.find_one(driver_filter, sort=[('_id', pymongo.DESCENDING)])
            m_vehicles_find = m_vehicles.find_one(vehicle_filter, sort = [('_id', pymongo.DESCENDING)])

            if not m_users_find['device_info']:
                device_details = ''
            else:
                device_details = m_users_find['device_info']['device_model'] + ' ' + m_users_find['device_info']['device_os']

            driver_first_name = m_users_find.get('first_name', '')
            driver_last_name = m_users_find.get('last_name', '')

            driver_contact_number = m_users_find.get('contact_number', '')
            driver_type = m_users_find.get('driver_type', '')
            device_site = m_users_find.get('company_info', {}).get('company_name', '')
            last_active_time = m_users_find.get('last_active_time', '')
            license_number = m_users_find.get('uk_driver_license_number', '')
            plate = m_users_find.get('private_hire_license_number', '')
            badge_type = m_users_find.get('badge_type', '')
            last_worked_time = m_users_find.get('last_worked_time', '')
            current_zone = m_users_find.get('current_zone', '')
            
            print(f"driver: {driver}")
            
            reference = m_vehicles_find.get('reference', '')
            registration_year = m_vehicles_find.get('registration_year', '')
            vehicle_make = m_vehicles_find.get('vehicle_make', '')
            vehicle_model = m_vehicles_find.get('vehicle_model', '')
            body_colour = m_vehicles_find.get('body_colour', '')
            registration_plate = m_vehicles_find.get('registration_plate', '')
            vehicle_types = m_vehicles_find.get('vehicle_types', '')
            
            print(f"reference = {reference}")
            
            drivers_data.append({
                'driver_name': driver_first_name + ' ' + driver_last_name,
                'device': driver_contact_number,
                'device_details': device_details,

                'driver_type': driver_type,
                'sites': device_site,
                'last_active':last_active_time,
                'license_number': license_number,
                'plate': plate,
                'badge_type': badge_type,
                'last_worked_time': last_worked_time,
                'current_zone': current_zone,

                'vehicle_id': reference,
                'year': registration_year,
                'make':vehicle_make + ' ' + vehicle_model,
                'colour': body_colour,
                'reg': registration_plate,
                'vehicle_types': ', '.join(vehicle_types),

                'job_status': job_status,
                'driver_coords': {
                    'lat': latitude,
                    'lng': longitude
                }
            })

        # json_data = json.dumps(drivers_data)

        context = drivers_data

        return JsonResponse(context, safe=False)
        # return render(request, 'mainapp/operator_page.html', {'data': context, 'room_name': 'track'})



def vehicle_details(vehicle_id):
    cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
    # db = client.mydatabase  # Replace "mydatabase" with your database name
    # collection = db.mycollection  # Replace "mycollection" with your collection name
    m_db = cluster[md_config()['cluster']]
    vehicles = m_db[md_config()['vehicles']]
    vehicle = vehicles.find_one({'vehicle_id': vehicle_id})
    if vehicle is not None:
        ref = vehicle['reference'] # {'vehicle_id': 'lbveqyXN3zfmv7X9OCF8XlZ2u1g2AA11AAA'}
    else:
        ref = ''
    return ref


@csrf_exempt
def live_bookings(request):
    print('I am in views live bookings')
    
    if request.method == 'POST':

        # booking_id = int(request.POST.get('booking_id'))
        query_dict_keys = list(request.POST.keys())
        if query_dict_keys:
            json_data = json.loads(query_dict_keys[0])
            
            booking_type = json_data.get('booking_type', '')
            print(booking_type)
            if booking_type == '#dispatch':
                f_db = firestore.client()
                # Calculate the time 24 hours ago from now
                twenty_four_hours_ago = datetime.utcnow() - timedelta(hours=1)
                firestore_timestamp = DatetimeWithNanoseconds(twenty_four_hours_ago.year,
                                                            twenty_four_hours_ago.month,
                                                            twenty_four_hours_ago.day,
                                                            twenty_four_hours_ago.hour,
                                                            twenty_four_hours_ago.minute,
                                                            twenty_four_hours_ago.second,
                                                            twenty_four_hours_ago.microsecond)

                print(twenty_four_hours_ago)

                # db = firebase.database()
                # Fetch data from Firestore
                # data = db.child('your_collection').get()
                query = f_db.collection_group(u'bookings') \
                    .where(u'booking_time', u'>=', firestore_timestamp) \
                    .where(u'status', u'in', ['bidding', 'pending']) \
                    .get()
                    
                data = [] 
                # Iterate through the data and print it
                for doc in query:
                    document = doc.to_dict()
                    # Extract the relevant fields from the document
                    booking_id = doc.id
                    print(f"booking time --> {document.get('booking_time', '')}")
                    book_time = document.get('booking_time', '').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                    print(book_time)
                    code = ''
                    job = ''
                    priority = ''

                    if document.get('status') == 'pending':
                        update = 'bidding'
                    elif document.get('status') == 'job_given':
                        update = 'dispatched'
                    else:
                        update = document.get('status')
                    
                    reference = vehicle_details(document.get('sent_to', {}).get('vehicle_id'))
                    pickup_address = document.get('pickup_location', {}).get('address')
                    pickup_notes = document.get('customer', {}).get('pickup_notes', '')
                    account = ''
                    destination =  document.get('dropOff_location')[-1].get('address') if document.get('dropOff_location') else None
                    via = [location.get('address') for location in (document.get('dropOff_location')[:-1] if document.get('dropOff_location') else [])]
                    phone = document.get('customer').get('contact', '')
                    consumer_name = document.get('customer', {}).get('full_name')
                    zone = ''
                                   
                    row_data = {
                        'booking_id': booking_id,
                        'time': book_time,
                        'code': code,
                        'job': job,
                        'priority': priority,
                        'update': update,
                        'reference': reference,
                        'pickup_address': pickup_address,
                        'pickup_notes': pickup_notes,
                        'account': account,
                        'destination': destination,
                        'via': via,
                        'phone': phone,
                        'consumer_name': consumer_name,
                        'zone': zone
                    }
                    data.append(row_data)
                    
                    print(f'row_data: {data}')
                    
            if booking_type == '#pre-booked':
                f_db = firestore.client()
                # Calculate the time 24 hours ago from now
                twenty_four_hours_ago = datetime.utcnow() - timedelta(hours=24)
                firestore_timestamp = DatetimeWithNanoseconds(twenty_four_hours_ago.year,
                                                            twenty_four_hours_ago.month,
                                                            twenty_four_hours_ago.day,
                                                            twenty_four_hours_ago.hour,
                                                            twenty_four_hours_ago.minute,
                                                            twenty_four_hours_ago.second,
                                                            twenty_four_hours_ago.microsecond)

                print(twenty_four_hours_ago)

                # db = firebase.database()
                # Fetch data from Firestore
                # data = db.child('your_collection').get()
                
                # .where(u'pickup_time', u'==', True) --> This needs to have some conditions 
                # When you set pickup_time, you would also set is_pickup_time_set to True
                
                query = f_db.collection_group(u'bookings') \
                    .where(u'booking_time', u'>=', firestore_timestamp) \
                    .where(u'pickup_time', u'==', True) \
                    .where(u'status', u'in', ['bidding', 'pending']) \
                    .get()
                    
                data = [] 
                # Iterate through the data and print it
                for doc in query:
                    document = doc.to_dict()
                    # Extract the relevant fields from the document
                    booking_id = doc.id
                    print(f"booking time --> {document.get('booking_time', '')}")
                    book_time = document.get('booking_time', '').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                    print(book_time)
                    lead_time = document.get('pickup_time', '').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                    code = ''
                    job = ''
                    priority = ''

                    if document.get('status') == 'pending':
                        update = 'bidding'
                    elif document.get('status') == 'job_given':
                        update = 'dispatched'
                    else:
                        update = document.get('status')
                    
                    reference = vehicle_details(document.get('sent_to', {}).get('vehicle_id'))
                    pickup_address = document.get('pickup_location', {}).get('address')
                    pickup_notes = document.get('customer', {}).get('pickup_notes', '')
                    account = ''
                    destination =  document.get('dropOff_location')[-1].get('address') if document.get('dropOff_location') else None
                    via = [location.get('address') for location in (document.get('dropOff_location')[:-1] if document.get('dropOff_location') else [])]
                    phone = document.get('customer').get('contact', '')
                    consumer_name = document.get('customer', {}).get('full_name')
                    zone = ''
                                
                    row_data = {
                        'booking_id': booking_id,
                        'time': book_time,
                        'lead_time': lead_time,
                        'code': code,
                        'job': job,
                        'priority': priority,
                        'update': update,
                        'reference': reference,
                        'pickup_address': pickup_address,
                        'pickup_notes': pickup_notes,
                        'account': account,
                        'destination': destination,
                        'via': via,
                        'phone': phone,
                        'consumer_name': consumer_name,
                        'zone': zone
                    }
                    data.append(row_data)
                    
            if booking_type == '#booked':
                f_db = firestore.client()
                # Calculate the time 24 hours ago from now
                twenty_four_hours_ago = datetime.utcnow() - timedelta(hours=24)
                firestore_timestamp = DatetimeWithNanoseconds(twenty_four_hours_ago.year,
                                                            twenty_four_hours_ago.month,
                                                            twenty_four_hours_ago.day,
                                                            twenty_four_hours_ago.hour,
                                                            twenty_four_hours_ago.minute,
                                                            twenty_four_hours_ago.second,
                                                            twenty_four_hours_ago.microsecond)

                print(twenty_four_hours_ago)

                # db = firebase.database()
                # Fetch data from Firestore
                # data = db.child('your_collection').get()
                query = f_db.collection_group(u'bookings') \
                    .where(u'booking_time', u'>=', firestore_timestamp) \
                    .where(u'status', u'in', ['job_given', 'arrived', 'pob']) \
                    .get()
                    
                data = [] 
                # Iterate through the data and print it
                for doc in query:
                    document = doc.to_dict()
                    # Extract the relevant fields from the document
                    booking_id = doc.id
                    print(f"booking time --> {document.get('booking_time', '')}")
                    book_time = document.get('booking_time', '').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                    print(book_time)
                    code = ''
                    job = ''
                    priority = ''

                    booking_status = document.get('status', '')
                    
                    status_logs = document.get('status_logs', [])
                    accepted_driver_id = document.get('accepted_by', {}).get('driver_id', '')
                    accepted_time = None
                    arrival_time = None
                    pob_time = None
                    for status_log in status_logs:
                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'job_given':
                            accepted_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'arrived': 
                            arrival_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'pob': 
                            pob_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                    
                    reference = vehicle_details(document.get('sent_to', {}).get('vehicle_id'))
                    pickup_address = document.get('pickup_location', {}).get('address')
                    pickup_notes = document.get('customer', {}).get('pickup_notes', '')
                    account = ''
                    destination =  document.get('dropOff_location')[-1].get('address') if document.get('dropOff_location') else None
                    via = [location.get('address') for location in (document.get('dropOff_location')[:-1] if document.get('dropOff_location') else [])]
                    phone = document.get('customer').get('contact', '')
                    consumer_name = document.get('customer', {}).get('full_name')
                    zone = ''
                                   
                    row_data = {
                        'booking_id': booking_id,
                        'time': book_time,
                        'code': code,
                        'job': job,
                        'priority': priority,
                        'booking_status': booking_status,
                        'accepted_time': accepted_time,
                        'arrival_time': arrival_time,
                        'pob_time': pob_time,
                        'reference': reference,
                        'pickup_address': pickup_address,
                        'pickup_notes': pickup_notes,
                        'account': account,
                        'destination': destination,
                        'via': via,
                        'phone': phone,
                        'consumer_name': consumer_name,
                        'zone': zone
                    }
                    data.append(row_data)
                    
            if booking_type == '#completed':
                f_db = firestore.client()
                # Calculate the time 24 hours ago from now
                twenty_four_hours_ago = datetime.utcnow() - timedelta(hours=24)
                firestore_timestamp = DatetimeWithNanoseconds(twenty_four_hours_ago.year,
                                                            twenty_four_hours_ago.month,
                                                            twenty_four_hours_ago.day,
                                                            twenty_four_hours_ago.hour,
                                                            twenty_four_hours_ago.minute,
                                                            twenty_four_hours_ago.second,
                                                            twenty_four_hours_ago.microsecond)

                print(twenty_four_hours_ago)

                # db = firebase.database()
                # Fetch data from Firestore
                # data = db.child('your_collection').get()
                query = f_db.collection_group(u'bookings') \
                    .where(u'booking_time', u'>=', firestore_timestamp) \
                    .where(u'status', u'in', ['complete']) \
                    .get()
                    
                data = [] 
                # Iterate through the data and print it
                for doc in query:
                    document = doc.to_dict()
                    # Extract the relevant fields from the document
                    booking_id = doc.id
                    print(f"booking time --> {document.get('booking_time', '')}")
                    book_time = document.get('booking_time', '').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                    print(book_time)
                    code = ''
                    job = ''
                    priority = ''

                    booking_status = document.get('status', '')
                    
                    status_logs = document.get('status_logs', [])
                    accepted_driver_id = document.get('accepted_by', {}).get('driver_id', '')
                    accepted_time = None
                    arrival_time = None
                    pob_time = None
                    end_time = None
                    for status_log in status_logs:
                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'job_given':
                            accepted_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'arrived': 
                            arrival_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'pob': 
                            pob_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'complete': 
                            end_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                    
                    reference = vehicle_details(document.get('sent_to', {}).get('vehicle_id'))
                    pickup_address = document.get('pickup_location', {}).get('address')
                    pickup_notes = document.get('customer', {}).get('pickup_notes', '')
                    account = ''
                    destination =  document.get('dropOff_location')[-1].get('address') if document.get('dropOff_location') else None
                    via = [location.get('address') for location in (document.get('dropOff_location')[:-1] if document.get('dropOff_location') else [])]
                    phone = document.get('customer').get('contact', '')
                    consumer_name = document.get('customer', {}).get('full_name')
                    zone = ''
                                   
                    row_data = {
                        'booking_id': booking_id,
                        'time': book_time,
                        'code': code,
                        'job': job,
                        'priority': priority,
                        'booking_status': booking_status,
                        'accepted_time': accepted_time,
                        'arrival_time': arrival_time,
                        'pob_time': pob_time,
                        'end_time': end_time,
                        'reference': reference,
                        'pickup_address': pickup_address,
                        'pickup_notes': pickup_notes,
                        'account': account,
                        'destination': destination,
                        'via': via,
                        'phone': phone,
                        'consumer_name': consumer_name,
                        'zone': zone
                    }
                    data.append(row_data)
                    
            if booking_type == '#cancelled':
                f_db = firestore.client()
                # Calculate the time 24 hours ago from now
                twenty_four_hours_ago = datetime.utcnow() - timedelta(hours=24)
                firestore_timestamp = DatetimeWithNanoseconds(twenty_four_hours_ago.year,
                                                            twenty_four_hours_ago.month,
                                                            twenty_four_hours_ago.day,
                                                            twenty_four_hours_ago.hour,
                                                            twenty_four_hours_ago.minute,
                                                            twenty_four_hours_ago.second,
                                                            twenty_four_hours_ago.microsecond)

                print(twenty_four_hours_ago)

                # db = firebase.database()
                # Fetch data from Firestore
                # data = db.child('your_collection').get()
                query = f_db.collection_group(u'bookings') \
                    .where(u'booking_time', u'>=', firestore_timestamp) \
                    .where(u'status', u'in', ['cancel']) \
                    .get()
                    
                data = [] 
                # Iterate through the data and print it
                for doc in query:
                    document = doc.to_dict()
                    # Extract the relevant fields from the document
                    booking_id = doc.id
                    print(f"booking time --> {document.get('booking_time', '')}")
                    book_time = document.get('booking_time', '').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                    print(book_time)
                    code = ''
                    job = ''
                    priority = ''

                    booking_status = document.get('status', '')
                    
                    status_logs = document.get('status_logs', [])
                    accepted_driver_id = document.get('accepted_by', {}).get('driver_id', '')
                    accepted_time = None
                    arrival_time = None
                    pob_time = None
                    end_time = None
                    for status_log in status_logs:
                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'job_given':
                            accepted_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'arrived': 
                            arrival_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'pob': 
                            pob_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                        if status_log.get('driver_id') == accepted_driver_id and status_log.get('status') == 'complete': 
                            end_time = status_log.get('time').astimezone(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            pass

                    
                    reference = vehicle_details(document.get('sent_to', {}).get('vehicle_id'))
                    pickup_address = document.get('pickup_location', {}).get('address')
                    pickup_notes = document.get('customer', {}).get('pickup_notes', '')
                    account = ''
                    destination =  document.get('dropOff_location')[-1].get('address') if document.get('dropOff_location') else None
                    via = [location.get('address') for location in (document.get('dropOff_location')[:-1] if document.get('dropOff_location') else [])]
                    phone = document.get('customer').get('contact', '')
                    consumer_name = document.get('customer', {}).get('full_name')
                    zone = ''
                                   
                    row_data = {
                        'booking_id': booking_id,
                        'time': book_time,
                        'code': code,
                        'job': job,
                        'priority': priority,
                        'booking_status': booking_status,
                        'accepted_time': accepted_time,
                        'arrival_time': arrival_time,
                        'pob_time': pob_time,
                        'end_time': end_time,
                        'reference': reference,
                        'pickup_address': pickup_address,
                        'pickup_notes': pickup_notes,
                        'account': account,
                        'destination': destination,
                        'via': via,
                        'phone': phone,
                        'consumer_name': consumer_name,
                        'zone': zone
                    }
                    data.append(row_data)

            print(data)
            # Prepare the data to be sent back as a JSON response
            response_data = {
                'data': data
            }
            # print(response_data)
            # Return the data as a JSON response
            return JsonResponse(response_data, safe=False)

        else:
            print('POST method has empty data')        

    return JsonResponse({'error': 'Invalid request method'})  



def process_driver(q, driver):

    cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
    m_db = cluster[md_config()['cluster']]
    m_vehicles = m_db[md_config()['vehicles']]

    vehicle_filter = {
            'driver_id': driver['driver_id']
        }
    result = {
        driver['driver_id']: {
            'vehicle_id': m_vehicles.find_one(vehicle_filter, sort = [('_id', pymongo.DESCENDING)])['reference'],
            'job_status': driver,
            'driver_coords': {
                'lat': driver['current_location']['coordinates'][1],
                'lng': driver['current_location']['coordinates'][0]
            }
        }
    }
    q.put(result)

@csrf_exempt
def search_bookings(request):
    if request.method == 'POST':
        type = request.POST.get('type')

        cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
        m_db = cluster[md_config()['cluster']]
        m_drivers = m_db[md_config()['drivers']]

        if type == 'sites':
            sites = taxibases_list(request)
            return JsonResponse({'sites': sites})
        
        elif type == 'operator':
            
            staff_fields = {"first_name": 1, "last_name": 1}
            staffs = user_list(request='GET', user_role='staff', userfields=staff_fields)
        
            staff_names = []
            for staff in staffs:
                staff_names.append(staff['first_name'] + ' ' + staff['last_name'])

            return JsonResponse({'operator': staff_names})
        else:
            print(f'not avialable site')

        

    return JsonResponse({'error': 'Invalid request method'})  

def allBookings(request):
    if request.method == 'POST':
        results_per_page = int(request.POST.get('results_per_page'))
        f_db = firestore.client()
        # db = firebase.database()
        # Fetch data from Firestore
        # data = db.child('your_collection').get()
        query = f_db.collection_group(u'bookings').limit(results_per_page).get()

        data = [] 
        # Iterate through the data and print it
        for doc in query:
            document = doc.to_dict()
            
            

            # Extract the relevant fields from the document
            booking_id = doc.id
            book_time = document.get('booking_time', '')
            status = document.get('status', '')
            pickup = document.get('pickup_location', {}).get('address', '') # document.get('pickup_address', '') # document.get('pickup_location', {}).get('address', '')
            # destination = document.get('dropOff_address', '')
            destination =  document.get('dropOff_location')[-1].get('address') if document.get('dropOff_location') else None

            if document.get('sent_to').get('vehicle_id') != '':
                vehicle_id = document.get('sent_to').get('vehicle_id', '')
            elif document.get('accepted_by').get('vehicle_id') != '':
                vehicle_id = document.get('accepted_by').get('vehicle_id', '')
            else:
                vehicle_id = ''
            
            customer_name = document.get('customer').get('full_name', '')
            phone = document.get('customer').get('contact', '')

            drv = booking_veh_details(vehicle_id)['vehicle_ref']
            vehicle_reg = booking_veh_details(vehicle_id)['vehicle_reg']
            driver_declines = len(document.get('cancel_by_driver'))
            account = ''
            pay = ''
            fare = ''
            receipt = ''
        
            row_data = {
                'booking_id': booking_id,
                'book_time': book_time,
                'status': status,
                'pickup': pickup,
                'destination': destination,
                'drv': drv,
                'vehicle_reg': vehicle_reg,
                'customer_name': customer_name,
                'phone': phone,
                'driver_declines': driver_declines,
                'account': account,
                'pay': pay,
                'fare': fare,
                'receipt': receipt
            }
            data.append(row_data)

        # Prepare the data to be sent back as a JSON response
        response_data = {
            'data': data
        }
        # print(response_data)
        # Return the data as a JSON response
        return JsonResponse(response_data)

    return JsonResponse({'error': 'Invalid request method'})    

def format_words(s):
    words = s.split(' ')
    for i in range(len(words)):
        if not words[i][0].isdigit():
            words[i] = words[i].capitalize()
        else:
            words[i] = words[i][0] + words[i][1:].lower()
    return ' '.join(words) 

def split_string(input_str):
    # words = input_str.split(' ')  # Split based on spaces to get words
    print(f"input_str: {input_str}")
    chars = list(input_str.replace(' ', ''))  # Remove spaces and get individual characters
    
    print(f"input_str: {input_str}")
    target_array = set(chars)
    print(f"target_array: {target_array}")
    # Combine both lists
    # combined = words + chars
    
    return target_array

@csrf_exempt
def render_booking_with_table(request):
    # Fetch initial data from Firestore with the default number of entries per page (e.g., 10)
    results_per_page = 10

    if request.method == 'POST':
        f_db = firestore.client()
        print(request.POST)
        
        fromDate = request.POST.get('fromDate')
        fromTime = request.POST.get('fromTime')
        toDate = request.POST.get('toDate')
        toTime = request.POST.get('toTime')
        job = request.POST.get('job')
        jobSites = request.POST.get('jobSites')
        source = request.POST.get('source')
        sourceSites = request.POST.get('sourceSites')
        drvRef = request.POST.get('drvRef')
        drvReg = request.POST.get('drvReg')
        addr = request.POST.get('addr')
        dest = request.POST.get('dest')
        zoneRef = request.POST.get('zoneRef')
        acc = request.POST.get('acc')
        operator = request.POST.get('operator')
        custName = request.POST.get('custName')
        custPh = request.POST.get('custPh')
        creditCardAcc = request.POST.get('creditCardAcc')
        status = request.POST.get('status')

        print(f'custName: {custName}')
    
        if fromDate and fromTime:
            fromDateTime = fromDate + ' ' + fromTime
            from_dt = datetime.strptime(fromDateTime, '%d/%m/%Y %H:%M')
            from_utc_dt = from_dt.replace(tzinfo=pytz.utc)
        else:
            fromDateTime = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            from_utc_dt = fromDateTime.replace(tzinfo=pytz.utc)

        if toDate and toTime:
            toDateTime = toDate + ' ' + toTime
            to_dt = datetime.strptime(toDateTime, '%d/%m/%Y %H:%M')
            to_utc_dt = to_dt.replace(tzinfo=pytz.utc)
        else:
            toDateTime = datetime.now()
            to_utc_dt = toDateTime.replace(tzinfo=pytz.utc)
            
        
        vehicle_id = ''
        vehicle_reg = ''
        vehicle_ref = ''

        if drvRef:
            vehicle_det = get_vehicle_details_from_mdb(vehicle_detail={'vehicle_reference':drvRef})
            print(f'vehicle_det: {vehicle_det}')
            if vehicle_det:
                vehicle_id = vehicle_det.get('vehicle_id', '')
                vehicle_reg = vehicle_det.get('vehicle_reg', '')

        elif drvReg:
            vehicle_det = get_vehicle_details_from_mdb(vehicle_detail={'vehicle_registration':drvReg})
            print(f'vehicle_det: {vehicle_det}')
            if vehicle_det:
                vehicle_id = vehicle_det.get('vehicle_id', '')
                vehicle_ref = vehicle_det.get('vehicle_ref', '')
                
        if job:
            print(f'job: {job}')
            data = []
            query_ref = f_db.collection('bookings').document(job)
            document = query_ref.get().to_dict()
            if document:
                print(f'document = {document}')
                # Extract the relevant fields from the document
                booking_id = job
                book_time = document.get('booking_time', '')
                status = document.get('status', '')
                pickup = document.get('pickup_location', {}).get('address', '') # document.get('pickup_address', '')
                destination = document.get('dropOff_address', '')

                if document.get('sent_to').get('vehicle_id') != '':
                    vehicle_id = document.get('sent_to').get('vehicle_id', '')
                elif document.get('accepted_by').get('vehicle_id') != '':
                    vehicle_id = document.get('accepted_by').get('vehicle_id', '')
                else:
                    vehicle_id = ''


                customer_name =document.get('customer').get('full_name', '')
                phone = document.get('customer').get('contact', '')

                drv = booking_veh_details(vehicle_id)['vehicle_ref']
                vehicle_reg = booking_veh_details(vehicle_id)['vehicle_reg']
                driver_declines = len(document.get('cancel_by_driver'))
                account = ''
                pay = ''
                fare = ''
                receipt = ''
                row_data = {
                        'booking_id': booking_id,
                        'book_time': book_time,
                        'status': status,
                        'pickup': pickup,
                        'destination': destination,
                        'drv': drv,
                        'vehicle_reg': vehicle_reg,
                        'customer_name': customer_name,
                        'phone': phone,
                        'driver_declines': driver_declines,
                        'account': account,
                        'pay': pay,
                        'fare': fare,
                        'receipt': receipt
                    }
                data.append(row_data)

        else:
            query_ref = f_db.collection_group('bookings')
            
            query_ref = query_ref.where(
                    u'booking_time', u'>=', from_utc_dt
                ).where(
                        u'booking_time', u'<=', to_utc_dt)
            print(f'from_date/time: {from_utc_dt}')
            print(f'to_date/time: {to_utc_dt}')

            if jobSites:
                print(f'jobSites: {jobSites}')
                query_ref = query_ref.where('jobSites', '==', jobSites)
            if source:
                print(f'source: {source}')
                query_ref = query_ref.where('source', '==', source)
            if vehicle_id:
                print(f'vehicle_id: {vehicle_id}')
                query_ref = query_ref.where('accepted_by.vehicle_id', '==', vehicle_id)
            if addr:
                # api_key = API_KEY
                # addr = get_formatted_address_gmaps(addr, api_key)  
                print(f'addr: {addr}')              
                dest = split_string(addr)
                print(f'addr: {addr}')
                
                
                query_ref = query_ref.where(
                    filter=FieldFilter(
                        "pickup_location.address_array", "array_contains", addr# f"address.{dest}"
                    )
                )
                
                # query_ref = query_ref.where('pickup_address', '==', addr)
            # if dest:
            #     # api_key = API_KEY
            #     # dest = get_formatted_address_gmaps(dest, api_key)
            #     # print(f'Formatted address: {dest}')

            #     # If you want to search for partial matches in Firestore
            #     # query_ref = query_ref.where('address_array', 'array_contains', dest)
                
            #     # dest = split_string(dest)
            #     print(f'dest: {dest}')
                
            #     # query_ref = query_ref.where(
            #     #      "address_array", "array_contains", dest
            #     # )
                
                
            #     query_ref = query_ref.where(
            #         filter=FieldFilter(
            #             "dropOff_location", "array_contains", "address"# f"address.{dest}"
            #         )
            #     )
                
            #     # query_ref = query_ref.where('dropOff_location.[-1].address', '==', dest)
                
            #     # api_key = API_KEY
            #     # dest = get_formatted_address_gmaps(dest, api_key)
            #     # print(f'dest: {dest}')
            #     # query_ref = query_ref.where('dropOff_address', '==', dest)
            #     # last_element = document.get('dropOff_address', [])[-1]
            #     # query_ref = query_ref.where('address_array', 'array-contains', addr)
            if zoneRef:
                print(f'zoneRef: {zoneRef}')
                query_ref = query_ref.where('zoneRef', '==', zoneRef)
            if acc:
                print(f'acc: {acc}')
                query_ref = query_ref.where('acc', '==', acc)
            if operator:
                print(f'operator: {operator}')
                query_ref = query_ref.where('operator', '==', operator)
            if custName:
                custName = format_words(s=custName)
                print(f'custName: {custName}')
                query_ref = query_ref.where('customer.full_name', '==', custName)
            if custPh:
                print(f'custPh: {custPh}')
                query_ref = query_ref.where('customer.contact', '==', custPh)
            if creditCardAcc:
                print(f'creditCardAcc: {creditCardAcc}')
                query_ref = query_ref.where('creditCardAcc', '==', creditCardAcc)
            if status:
                print(f'status: {status}')
                query_ref = query_ref.where('status', '==', status)

            # Execute the query.
            # docs = query_ref.stream()
            print(f'query_ref: {query_ref}')
            
            # batch_size = 10
            # # Variable to keep track of the last document in the previous batch
            # last_doc = None
            # # Array to keep track of filtered documents
            # filtered_docs = []
            # docs = query_ref.limit(batch_size).get()
            # for doc in docs:
            #     doc_data = doc.to_dict()
            #     print(f'doc_data: {doc_data}')
            #     if 'dropOff_location' in doc_data:
            #         destination = split_string(dest)
            #         print(f"dest: {dest}")
            #         last_dropOff_location = doc_data['dropOff_location'][-1]
            #         if 'address_array' in last_dropOff_location:
            #             if destination.issubset(set(last_dropOff_location['address_array'])):
            #                 print(f'doc_data: {doc_data}')
            #                 filtered_docs.append(doc)

            # Remember the last document for the next batch
            # last_doc = docs[-1]
            
            
            # print(f'filtered_docs: {filtered_docs}')
            
            docs = query_ref.limit(results_per_page).get()
            # docs = query_ref.get()

            data = [] 
            # Iterate through the data and print it
            for doc in docs:
                document = doc.to_dict()
                # Extract the relevant fields from the document
                booking_id = doc.id
                book_time = document.get('booking_time', '')
                status = document.get('status', '')
                pickup = document.get('pickup_location', {}).get('address', '') # document.get('pickup_address', '')
                # destination = document.get('dropOff_address', '')
                destination = document.get('dropOff_location', [])[-1].get('address', '')

                if document.get('sent_to').get('vehicle_id') != '':
                    vehicle_id = document.get('sent_to').get('vehicle_id', '')
                elif document.get('accepted_by').get('vehicle_id') != '':
                    vehicle_id = document.get('accepted_by').get('vehicle_id', '')
                else:
                    vehicle_id = ''


                customer_name = document.get('customer', {}).get('full_name', '')
                phone = document.get('customer').get('contact', '')

                drv = booking_veh_details(vehicle_id)['vehicle_ref']
                vehicle_reg = booking_veh_details(vehicle_id)['vehicle_reg']
                driver_declines = len(document.get('cancel_by_driver'))
                account = ''
                pay = ''
                fare = '£' + str(document.get('estimated_fare', '-'))
                receipt = ''
            
                row_data = {
                    'booking_id': booking_id,
                    'book_time': book_time,
                    'status': status,
                    'pickup': pickup,
                    'destination': destination,
                    'drv': drv,
                    'vehicle_reg': vehicle_reg,
                    'customer_name': customer_name,
                    'phone': phone,
                    'driver_declines': driver_declines,
                    'account': account,
                    'pay': pay,
                    'fare': fare,
                    'receipt': receipt
                }
                data.append(row_data)

        context = {
            'booking_data': data
            # 'booking_data': 5
        }
        
        print(f"context: {context}")

        return JsonResponse(context) #render(request, "mainapp/operator_page.html", context)

    return JsonResponse({'error': 'Invalid request method'})

@csrf_exempt
def render_drivers_with_table(request):
    # Fetch initial data from Firestore with the default number of entries per page (e.g., 10)

    results_per_page = 10

    if request.method == 'POST':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_drivers = m_db[md_config()['drivers']]
        m_vehicles = m_db[md_config()['vehicles']]
        m_users = m_db[md_config()['users']]

        print(request.POST)
        
        vehicle_id = request.POST.get('drivers-ref-id')
        vehicle_reference = request.POST.get('driver-vehicle-reference')
        vehicle_plate = request.POST.get('driver-vehicle-plate')
        imei = request.POST.get('driver-imei')
        job_sites = request.POST.get('driver-job-sites')
        vehicle_types = request.POST.get('driver-vehicle-type')
        driver_name = request.POST.get('driver-name')
        badge_psv = request.POST.get('driver-badge-psv')
        vehicle_plate = request.POST.get('driver-vehicle-plate')
        driver_phone = request.POST.get('driver-phone')
        driver_active = request.POST.get('driver-active')
        driver_status = request.POST.get('driver-status')

        print(f"request: {request}")

        ## drivers collection filteration

        drivers_filter = {}

        if badge_psv:
            drivers_filter['badge_psv'] = {'$regex': badge_psv, '$options': 'i'}  ### The $options: 'i' makes it case-insensitive. 

        if driver_active:
            drivers_filter['driver_status'] = driver_active

        if driver_status:
            drivers_filter['job_status'] = driver_status     
            
        if job_sites:
            if job_sites == 'all_sites':
                print(f"all sites drivers are shown")
            else:
                drivers_filter['company_info.company_name'] = job_sites   

        driver_fields = {"driver_id": 1, "last_logged_time": 1, "last_worked_time": 1, "driver_status": 1, "primary_vehicle": 1, "isLive": 1}

        query = m_drivers.find(drivers_filter, driver_fields).limit(results_per_page)

        ## users collection filteration

        users_filter = {}

        if imei:
            users_filter['device_info.unique_id'] = {'$regex': imei, '$options': 'i'}
                

        ####### working at here!!!!



        if driver_name:
            users_filter['first_name'] = {'$regex': imei, '$driver_name': 'i'}
            users_filter['last_name'] = {'$regex': imei, '$options': 'i'}
            
        if driver_phone:
            pass
            

        user_fields = {"first_name": 1, "last_name": 1, "contact_number": 1, "device_info": 1}
        vehicle_fields = {"reference": 1}

        if vehicle_id or vehicle_reference:
            print(f"vehicle_id: {vehicle_id}")
            print(f"vehicle_reference: {vehicle_reference}")

        data = [] 
        for document in query:
            status_map = {
                'pending': 'p',
                'verified': 'v'
            }

            user_info = m_users.find_one({'_id': document['_id']}, user_fields)
            vehicle_info = m_vehicles.find_one({'vehicle_id': document.get('primary_vehicle', {}).get('vehicle_id', '')}, vehicle_fields)

            if document['last_logged_time'] != "":
                login_date_object = datetime.strptime(document['last_logged_time'], '%Y-%m-%dT%H:%M:%S.%f')
                last_login = login_date_object.strftime('%d/%m/%Y %H:%M')
            else:
                last_login = ''

            if document['last_worked_time'] != '':
                booking_date_object = datetime.strptime(document['last_worked_time'], '%Y-%m-%dT%H:%M:%S.%f')
                last_worked = booking_date_object.strftime('%d/%m/%Y %H:%M')
            else:
                last_worked = ''

            driver_id = document.get('driver_id', '')
            if vehicle_info:
                reference = vehicle_info.get('reference', '')
            
            status = status_map.get(document.get('driver_status', ''), '')

            if user_info:
                name = user_info.get('first_name', '') + ' ' + user_info.get('last_name', '')
                phone = user_info.get('contact_number', '')
            else:
                name = ''
                phone = ''

            vehicle = document.get('primary_vehicle', {}).get('vehicle_make', '') + ' ' + document.get('primary_vehicle', {}).get('vehicle_model', '')
            plate = ''
            booking_psv = ''
            registration = document.get('primary_vehicle', {}).get('registration_plate', '')
            active = document.get('isLive', '')

            if user_info and 'device_info' in user_info and user_info['device_info']:
                device_os = user_info['device_info'].get('device_os', '')
            else:
                device_os = ''

            row_data = {
                'driver_id': driver_id,
                'reference': reference,
                'status': status,
                'name': name,
                'phone': phone,
                'last_login': last_login,
                'last_worked': last_worked,
                'vehicle': vehicle,
                'plate': plate,
                'booking_psv': booking_psv,
                'registration': registration,
                'active': active,
                'device_os': device_os
            }
            data.append(row_data)

        context = {
            'driver_data': data
        }

        # print(f"context: {context}")

        return JsonResponse(context)

    return JsonResponse({'error': 'Invalid request method'})


@csrf_exempt
def render_customers_with_table(request):
    # Fetch initial data from Firestore with the default number of entries per page (e.g., 10)

    results_per_page = 10

    if request.method == 'POST':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_users = m_db[md_config()['users']]
        m_consumers = m_db[md_config()['consumers']]

        print(request.POST)

        customerName = request.POST.get('customerName')
        customerPhone = request.POST.get('customerPhone')

        escaped_customerPhone = re.escape(customerPhone)

        customerEmail = request.POST.get('customerEmail')
        customerCardRef = request.POST.get('customerCardRef')
        customerStatus = request.POST.get('customerStatus')

        if customerStatus == 'barred':
            barred = 'yes'
        elif customerStatus == 'non-barred':
            barred = 'no'
        else:
            barred = customerStatus

        customerOrder = request.POST.get('customerOrder')

        print(f"request: {request}")

        form_data_1 = {
            "contact_number": escaped_customerPhone,
            "email": customerEmail
        }

        my_filter = {
            "user_roles": {
                "$in": ["consumer"]
            }
        }

        for key, value in form_data_1.items():
            if value:  # This checks if the value is non-empty
                my_filter[key] = {"$regex": value, "$options": "i"}

        print(f"my_filter: {my_filter}")


        user_fields= {
            "_id": 1, "first_name": 1, "last_name": 1, "email": 1, "contact_number": 1
        }
        query = m_users.find(my_filter, user_fields).limit(results_per_page)

        context = {
            'customer_data': []
        }

        data = [] 
        print(f"query: {query}")
        for document in query:
            print(f"inside_document")
            if document:
                form_data_2 = {
                    "name": customerName,
                    "card_reference": customerCardRef,
                    "barred": barred
                }

                consumers_fields  = {"bookings": 1, "vip_customer": 1, "rating": 1}

                consumer_info_filter = {
                    '_id': document['_id']
                }

                for key, value in form_data_2.items():
                    if value:  # This checks if the value is non-empty
                        consumer_info_filter[key] = {"$regex": value, "$options": "i"}

                consumers_info = m_consumers.find_one(consumer_info_filter, consumers_fields)
                # vehicle_info = m_vehicles.find_one({'vehicle_id': document.get('primary_vehicle', {}).get('vehicle_id', '')}, vehicle_fields)
                print(f"document: {document}")
                print(f"consumers_info: {consumers_info}")
                if consumers_info:
                    consumer_id = document['_id']
                    phone = document['contact_number']
                    name = document['first_name'] + ' ' + document['last_name']
                    email = document['email']

                    if consumers_info:

                        score = consumers_info['rating']
                        bookings = consumers_info['bookings']
                        vip = consumers_info['vip_customer']

                    else:

                        score = ''
                        bookings = ''
                        vip = ''

                    complete = ''
                    noshow = ''
                    spent = ''
                    accounts = ''
                    cards = ''
                    banned = False
                    card_disabled = False
                    trusted = True
                    
                    notes = ''

                    row_data = {
                        'consumer_id': consumer_id,
                        'score': score,
                        'phone': phone,
                        'name': name,
                        'email': email,
                        'bookings': bookings,
                        'complete': complete,
                        'noshow': noshow,
                        'spent': spent,
                        'accounts': accounts,
                        'cards': cards,
                        'banned': banned,
                        'card_disabled': card_disabled,
                        'trusted': trusted,
                        'vip': vip,
                        'notes': notes
                    }

                    data.append(row_data)

                    
                    context['customer_data'] = data

                else:
                    print(f"no further data available inside consumers doc")

            else:
                print(f"consumer documents are empty")
                

        # print(f"context: {context}")

        return JsonResponse(context)

    return JsonResponse({'error': 'Invalid request method'})


@csrf_exempt
def consumer_detail(request):
    # Fetch initial data from Firestore with the default number of entries per page (e.g., 10)


    if request.method == 'GET':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_users = m_db[md_config()['users']]
        m_consumers = m_db[md_config()['consumers']]

        print(request.GET)

        customerId = request.GET.get('customerId')

        print(f"customerId: {customerId}")


        my_filter = {
            "_id": customerId
        }

        user_fields= {
            "_id": 1, "first_name": 1, "last_name": 1, "email": 1, "contact_number": 1, "password": 1,
            "email_verified": 1, "contact_verified": 1
        }
        user_data = m_users.find_one(my_filter, user_fields)
        
        consumer_id = user_data['_id']
        first_name = user_data['first_name']
        last_name = user_data['last_name']
        phone = user_data['contact_number']
        email = user_data['email']
        password = user_data['password']
        email_verified = user_data['email_verified']
        contact_verified = user_data['contact_verified']
        

        consumers_fields  = {
            "bookings": 1, "vip_customer": 1, "average_rating": 1, "barred": 1, "excl_duplicate_check": 1, "priority": 1,
            "discount": 1, "rating_color": 1, "last_login_date": 1, "date_of_registration": 1, "average_spendings": 1
        }

        consumers_info = m_consumers.find_one(my_filter, consumers_fields)

        if consumers_info:
            priority_data = consumers_info['priority']
            if not priority_data or priority_data == 5:
                priority = 'PRIORITY 5 (REGULAR PRIORITY)'
            elif priority_data == 4:
                priority = 'PRIORITY 4'
            elif priority_data == 3:
                priority = 'PRIORITY 3'
            elif priority_data == 2:
                priority = 'PRIORITY 2'
            elif priority_data == 1:
                priority = 'PRIORITY 1 (TOP PRIORITY)'
            else:
                priority = 'PRIORITY 5 (REGULAR PRIORITY)'

            bookings = consumers_info['bookings']
            discount = consumers_info['discount']
            barred = consumers_info['barred']
            vip_customer = consumers_info['vip_customer']
            excel_duplicate_check = consumers_info['excl_duplicate_check']
            ratings = consumers_info['average_rating']
            rating_color = consumers_info['rating_color']
            last_login_seconds = consumers_info["last_login_date"] / 1000  # Convert from milliseconds to seconds
            last_login_object = datetime.fromtimestamp(last_login_seconds)
            last_login = last_login_object.strftime('%Y-%m-%d')
            date_of_reg_seconds = consumers_info["date_of_registration"] / 1000  # Convert from milliseconds to seconds
            date_of_reg_object = datetime.fromtimestamp(date_of_reg_seconds)
            date_of_reg = date_of_reg_object.strftime('%Y-%m-%d')
            average_spendings = consumers_info['average_spendings']


        else:
            priority = 'PRIORITY 5 (REGULAR PRIORITY)'
            bookings = 0
            discount = 0
            barred = 'No'
            vip_customer = 'No'
            excel_duplicate_check = 'No'
            ratings = 5
            rating_color = ''
            last_login = ''
            date_of_reg = ''
            average_spendings = 0

        ### CONSUMER STATS DB - require to wrok on
        logins = ''

        row_data = {
            'consumer_id': consumer_id,
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'contact_verified': contact_verified,
            'email': email,
            'email_verified': email_verified,
            'priority': priority,
            'password': password,
            'discount': discount,
            'barred': barred,
            'vip_customer': vip_customer,
            'excel_duplicate_check': excel_duplicate_check,
            'logins': logins,
            'date_of_reg': date_of_reg,
            'last_login': last_login,
            'bookings': bookings,
            'ratings': ratings,
            'rating_color': rating_color,
            'average_spendings': average_spendings
        }

        ###] NEED SOME UPDATING
        context = {
            'customer_data': row_data
        }

        # print(f"context: {context}")

        return JsonResponse(context)

    return JsonResponse({'error': 'Invalid request method'})

@csrf_exempt
def update_consumer_details(request):
    if request.method == 'POST':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_consumers = m_db[md_config()['consumers']]

        print(request.POST)

        customerId = request.POST.get('customerId')
        priority = request.POST.get('priority')

        if priority == 'PRIORITY 5 (REGULAR PRIORITY)':
            priority_data = 5
        elif priority == 'PRIORITY 4':
            priority_data = 4
        elif priority == 'PRIORITY 3':
            priority_data = 3
        elif priority == 'PRIORITY 2':
            priority_data = 2
        elif priority == 'PRIORITY 1 (TOP PRIORITY)':
            priority_data = 1
        else:
            priority_data = 5

        discount = request.POST.get('discount')
        barred = request.POST.get('barred')
        vip_customer = request.POST.get('vip_customer')
        excel_duplicate_check = request.POST.get('excel_duplicate_check')
        rating_color = request.POST.get('rating_color')

        current_datetime = datetime.now()
        document_update = int(current_datetime.timestamp() * 1000)


        ## Additional data for full new document
        first_name = request.POST.get('fname')
        last_name = request.POST.get('lname')
        full_name = first_name + ' ' + last_name
        phone = request.POST.get('phone')

        date_of_reg = request.POST.get('date_of_reg')
        last_login = request.POST.get('last_login')

        bookings = request.POST.get('bookings')
        rating = request.POST.get('rating')
        average_spendings = request.POST.get('average_spendings')
        average_rating = request.POST.get('average_rating')

        criteria = {
            "_id": customerId
        }

        document = m_consumers.find_one(criteria)

        if document:
            # If the document exists, update some fields
            update_data = {
                "$set": {
                    "priority": priority_data,
                    "discount": discount,
                    "barred": barred,
                    "vip_customer": vip_customer,
                    "excl_duplicate_check": excel_duplicate_check,
                    "rating_color": rating_color,
                    "document_update": document_update
                }
            }
            m_consumers.update_one(criteria, update_data)
            print("Document updated.")
        else:
            # If the document does not exist, insert a new one with full fields
            new_document = {
                "_id": customerId,
                "priority": priority_data,
                "discount": discount,
                "barred": barred,
                "vip_customer": vip_customer,
                "excl_duplicate_check": excel_duplicate_check,
                "date_of_registration": date_of_reg,
                "last_login_date": last_login,
                "bookings": bookings,
                "rating": rating,
                "rating_color": rating_color,
                "average_spendings": average_spendings,
                "address_by_customer": [],
                "attributes": [],
                "block_sms": False,
                "current_location": [],
                "name": full_name,
                "phone_number": phone,
                "average_rating": average_rating,
                "document_update": document_update
            }

            m_consumers.insert_one(new_document)
            print("New document inserted.")
    

        return JsonResponse({"success": True})
       
    return JsonResponse({"success": False})

@csrf_exempt
def google_maps(request):
    query = request.GET.get('query')
    API_ENDPOINT = 'https://maps.googleapis.com/maps/api/place/autocomplete/json'
    params = {
        'input': query,
        'types': 'geocode',
        'key': gm_config()['api_key']
    }

    response = requests.get(API_ENDPOINT, params=params)
    data = response.json()

    return JsonResponse(data)


@csrf_exempt
def customer_addresses(request):
    print(request.method)
    if request.method == 'POST':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_consumers = m_db[md_config()['consumers']]

        print(request.POST)
        
        customerId = request.POST.get('customerId')
        address = request.POST.get('address')
        instructions = request.POST.get('instructions')
        
        if request.POST.get('publicIVR'):
            public_IVR = request.POST.get('publicIVR')
        else:
            public_IVR = 'off'

        discount = request.POST.get('discount')
        
        used = 0
        last_used = datetime.utcfromtimestamp(0)

        criteria = {
            "_id": customerId
        }

        document = m_consumers.find_one(criteria)

        if document:
            row_number = len(document['address_by_customer'])
            # If the document exists, update some fields
            update_addresses = {
                "$push": {
                    "address_by_customer": {
                        "row_number": row_number,
                        "address": address,
                        "instructions": instructions,
                        "public_IVR": public_IVR,
                        "discount": discount,
                        "used": used,
                        "last_used": last_used
                    }
                }
            }
            m_consumers.update_one(criteria, update_addresses)
            print("Document updated.")

            return JsonResponse({"success": True})

        else:
            print("Document not found.")

            return JsonResponse({"success": False, "message": "Document not found."})

    if request.method == 'GET':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_consumers = m_db[md_config()['consumers']]

        print(request.GET)

        customerId = request.GET.get('customerId')
        print(f"customerId: {customerId}")


        my_filter = {
            "_id": customerId
        }

        user_fields= {
            "_id": 1, "address_by_customer": 1
        }
        address_data = m_consumers.find_one(my_filter, user_fields)

        # print(f"address_data: {address_data}")

        if address_data:
            addresses = []
            for addr in address_data['address_by_customer']:
                row_number = addr['row_number']
                address = addr['address']
                descriptor = addr['public_IVR']
                instructions = addr['instructions']
                discount = addr['discount']

                used = addr['used']
                last_used = addr['last_used']

                row_data = {
                    'row_number': row_number,
                    'address': address,
                    'descriptor': descriptor,
                    'instructions': instructions,
                    'discount': discount,   
                    'used': used,
                    'last_used': last_used
                }

                addresses.append(row_data)

            context = {
                'address_data': addresses
            }

        else:
            context = {
                'address_data': {}
            }

        # print(f"context: {context}")

        return JsonResponse(context)
    
    if request.method == 'DELETE':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_consumers = m_db[md_config()['consumers']]
        print('request.body: {request.body}')
        if request.body:
            try:
                data = json.loads(request.body.decode('utf-8'))
            except json.JSONDecodeError:
                return JsonResponse({"success": False, "message": "Invalid JSON data received."}, status=400)
        else:
            # Handle cases where the body is empty or handle it as per your use case
            pass

        print(data)

        customerId = data['customerId']
        address = data['address']
        instructions = data['instructions']
        print(f"customerId: {customerId}")

        criteria = {
            "_id": customerId
        }

        document = m_consumers.find_one(criteria)
        print(f"document: {document['address_by_customer']}")

        filtered_addresses = []

        for addr in document['address_by_customer']:
            if addr['address'] != address or addr['instructions'] != instructions:
                filtered_addresses.append(addr)
        print(f"filtered_addresses: {filtered_addresses}")
        document['address_by_customer'] = filtered_addresses
        
        if document:
            # If the document exists, update some fields
            update_addresses = {
                "$set": {
                    "address_by_customer": filtered_addresses
                    
                }
            }
            m_consumers.update_one(criteria, update_addresses)

        return JsonResponse({})
    
    if request.method == 'PUT':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_consumers = m_db[md_config()['consumers']]
        data = QueryDict(request.body.decode('utf-8'))

        # if request.body:
        #     try:
        #         data = json.loads(request.body.decode('utf-8'))
        #     except json.JSONDecodeError:
        #         return JsonResponse({"success": False, "message": "Invalid JSON data received."}, status=400)
        # else:
        #     # Handle cases where the body is empty or handle it as per your use case
        #     pass

        print(data)

        customerId = data['customerId']
        row_number = data['row_number']
        print(f"row number: {row_number}")
        address = data['address']
        instructions = data['instructions']

        if 'public_IVR' in data:
            public_IVR = data['public_IVR']
        else:
            public_IVR = 'off'

        discount = data['discount']
        print(f"customerId: {customerId}")

        criteria = {
            "_id": customerId
        }

        document = m_consumers.find_one(criteria)
        if not document:
            print(f"No document found with ID {customerId}")
            return JsonResponse({"success": False})
        
        print(f"document: {document['address_by_customer']}")

        address_entry = document['address_by_customer'][int(row_number)]

        # Updating the values only if they are different
        if 'address' in address_entry and address_entry['address'] != address:
            address_entry['address'] = address
        if 'instructions' in address_entry and address_entry['instructions'] != instructions:
            address_entry['instructions'] = instructions
        if 'public_IVR' in address_entry and address_entry['public_IVR'] != public_IVR:
            address_entry['public_IVR'] = public_IVR
        if 'discount' in address_entry and address_entry['discount'] != discount:
            address_entry['discount'] = discount

        # Update the specific entry in MongoDB using positional operator
        update_criteria = {
            "_id": customerId,
            f"address_by_customer.row_number": int(row_number)  # Ensure row_number is an integer for matching
        }
        update_data = {
            "$set": {
                f"address_by_customer.$": address_entry
            }
        }

        result = m_consumers.update_one(update_criteria, update_data)
        print(f"Matched {result.matched_count} documents and updated {result.modified_count} documents.")


        # for addr in document['address_by_customer'][row_number]:
        #     if address in addr and addr['address'] != address:
        #         addr['address'] = address
        #     if instructions in addr and addr['instructions'] != instructions:
        #         addr['instructions'] = instructions
        #     if public_IVR in addr and addr['public_IVR'] != public_IVR:
        #         addr['public_IVR'] = public_IVR
        #     if discount in addr and addr['discount'] != discount:
        #         addr['discount'] = discount

                # filtered_addresses.append(addr)

        # print(f"filtered_addresses: {filtered_addresses}")
        # document['address_by_customer'] = filtered_addresses
        
        # if document:
        #     # If the document exists, update some fields
        #     update_addresses = {
        #         "$set": {
        #             "address_by_customer": filtered_addresses
                    
        #         }
        #     }

        # print(f"update_addresses: {update_addresses}")
        #     m_consumers.update_one(criteria, update_addresses)

        return JsonResponse({"success": True})

    return JsonResponse({'error': 'Invalid request method'})


@csrf_exempt
def render_vehicles_with_tables(request):
    # Fetch initial data from Firestore with the default number of entries per page (e.g., 10)

    results_per_page = 10

    if request.method == 'POST':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_drivers = m_db[md_config()['drivers']]
        m_vehicles = m_db[md_config()['vehicles']]

        print(request.POST)

        vehicleRef = request.POST.get('vehicleRef')
        vehicleSortF = request.POST.get('vehicleSort')

        if vehicleSortF:
            vehicleSort = vehicleSortF[5:]
        
            print(f"vehicleSort: {vehicleSort}")

        vehicleSite = request.POST.get('vehicleSite')
        vehicleReg = request.POST.get('vehicleReg')
        vehicleMake = request.POST.get('vehicleMake')
        vehiclePlate = request.POST.get('vehiclePlate')

        form_data_1 = {
            "reference": vehicleRef,
            "registration_plate": vehicleReg,
            "vehicle_make": vehicleMake
        }

        vehicle_filter = {}

        for key, value in form_data_1.items():
            if value:  # This checks if the value is non-empty
                vehicle_filter[key] = {"$regex": value, "$options": "i"}

        vehicle_fields= {
            "driver_id": 1, "vehicle_id": 1, "reference": 1, "registration_year": 1, "vehicle_make": 1,
            "vehicle_model": 1, "body_colour": 1, "registration_plate": 1, "plate": 1, "plate_expiry": 1, "insurance_expiry": 1, "vehicle_status": 1
        }

        if vehicleSortF:
            vehicle_query = m_vehicles.find(vehicle_filter, vehicle_fields).sort(vehicleSort, 1).limit(results_per_page)
        else:
            vehicle_query = m_vehicles.find(vehicle_filter, vehicle_fields).limit(results_per_page)

        context = {
            'vehicle_data': []
        }

        data = [] 
        print(f"query: {vehicle_query}")
        for document in vehicle_query:
            print(f"inside_document")
            if document:

                site_filter = {
                    '_id': document['driver_id'],
                    'company_info.company_name': vehicleSite
                }
                
                driver_filter = {}

                for key, value in site_filter.items():
                    if value:  # This checks if the value is non-empty
                        driver_filter[key] = value

                driver_fields = {
                    "company_info.company_name": 1
                }

                driver_query = m_drivers.find_one(driver_filter, driver_fields)
                if driver_query:

                    print(f"document = {document}")
                    print(f"driver_query = {driver_query}")
                    
                    vehicle_id = document['vehicle_id']
                    driver_id = document['driver_id']
                    reference = document['reference']
                    vehicle_year = document['registration_year']
                    vehicle_make = document['vehicle_make']
                    vehicle_model = document['vehicle_model']
                    vehicle_colour = document['body_colour']
                    vehicle_registration = document['registration_plate']
                    vehicle_plate = document['plate']
                    vehicle_plate_expiry = document['plate_expiry']
                    vehicle_insurance_expiry = document['insurance_expiry']
                    vehicle_status = document['vehicle_status']

                    row_data = {
                        'vehicle_id': vehicle_id,
                        'driver_id': driver_id,
                        'reference': reference,
                        'vehicle_year': vehicle_year,
                        'vehicle_make': vehicle_make,
                        'vehicle_model': vehicle_model,
                        'vehicle_colour': vehicle_colour,
                        'vehicle_registration': vehicle_registration,
                        'vehicle_plate': vehicle_plate,
                        'vehicle_plate_expiry': vehicle_plate_expiry,
                        'vehicle_insurance_expiry': vehicle_insurance_expiry,
                        'vehicle_status': vehicle_status
                    }

                    data.append(row_data)

                    
                    context['vehicle_data'] = data

                else:
                    print(f"driver does not meet site criteria")

        if context['vehicle_data']:
            if vehicleSortF:
                if vehicleSort == 'reference':
                    vehicleSort = 'reference'
                elif vehicleSort == 'year':
                    vehicleSort = 'vehicle_year'
                elif vehicleSort == 'make':
                    vehicleSort = 'vehicle_make'
                elif vehicleSort == 'model':
                    vehicleSort = 'vehicle_model'
                elif vehicleSort == 'colour':
                    vehicleSort = 'vehicle_colour'
                elif vehicleSort == 'status':
                    vehicleSort = 'vehicle_status'
                    
                print(f"I m in sorted check")
                print(f"context['vehicle_data']: {context['vehicle_data']}")
                context['vehicle_data'] = sorted(context['vehicle_data'], key=lambda x: x[vehicleSort])
            
            else:
                print(f"No Sorting")

        return JsonResponse(context)

    return JsonResponse({'error': 'Invalid request method'})


@csrf_exempt
def vehicle_detail_request(request):
    # Fetch initial data from Firestore with the default number of entries per page (e.g., 10)


    if request.method == 'GET':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_vehicle_types = m_db[md_config()['vehicle_types']]
        m_vehicles = m_db[md_config()['vehicles']]
        m_users = m_db[md_config()['users']]
        m_drivers = m_db[md_config()['drivers']]

        vehicleId = request.GET.get('vehicleId')

        print(request.GET)
        print(f"I am here!")

        vehicle_fields = {
            'reference': 1, 'vehicle_aka': 1, 'vehicle_make': 1, 'vehicle_model': 1, 'body_colour': 1, 'body_type': 1, 'number_of_seats': 1, 'vehicle_status': 1,'registration_year': 1, 'registration_plate': 1, 'plate': 1, 'plate_expiry': 1, 'vehicle_phone': 1, 'fuel_type': 1, 'primary_vehicle': 1, 'vehicle_condition': 1, 'insurance_company': 1, 'insurer_policy_number': 1, 'insurance_expiry': 1, 'mot': 1, 'mot_expiry': 1, 'road_tax_expiry': 1, 'council_compliance': 1, 'co2_emissions': 1, 'vehicle_start': 1, 'hire_expiry': 1, 'owner_driver': 1, 'vehicle_owner': 1, 'device_imei': 1, 'light_control': 1, 'status_control': 1, 'sensors': 1, 'data': 1, 'vehicle_types': 1, 'driver_id': 1
            }

        vehicle_filter = {
            'vehicle_id': vehicleId
        }


        vehicle_query = m_vehicles.find_one(vehicle_filter, vehicle_fields)
        print(f"vehicle_query: {vehicle_query}")

        reference = vehicle_query['reference']
        vehicle_aka = vehicle_query['vehicle_aka']
        vehicle_make = vehicle_query['vehicle_make']
        vehicle_model = vehicle_query['vehicle_model']
        body_colour = vehicle_query['body_colour']

        if vehicle_query.get('body_type'):
            body_type = vehicle_query['body_type']
        else:
            body_type = ''

        # number_of_seats = vehicle_query['number_of_seats']

        if vehicle_query.get('number_of_seats'):
            number_of_seats = vehicle_query['number_of_seats']
        else:
            number_of_seats = ''
        # vehicle_status = vehicle_query['vehicle_status']

        if vehicle_query.get('vehicle_status'):
            vehicle_status = vehicle_query['vehicle_status']
        else:
            vehicle_status = ''

        registration_year = vehicle_query['registration_year']
        registration_plate = vehicle_query['registration_plate']
        plate = vehicle_query['plate']
        plate_expiry = vehicle_query['plate_expiry']

        plate_expiry_date, plate_expiry_time, plate_expiry_day = convert_milliseconds_to_date(plate_expiry)

        vehicle_phone = vehicle_query['vehicle_phone']

        # fuel_type = vehicle_query['fuel_type']

        if vehicle_query.get('fuel_type'):
            fuel_type = vehicle_query['fuel_type']
        else:
            fuel_type = ''
        # primary_vehicle = vehicle_query['primary_vehicle']

        if vehicle_query.get('primary_vehicle'):
            primary_vehicle = vehicle_query['primary_vehicle']
        else:
            primary_vehicle = ''
        # vehicle_condition = vehicle_query['vehicle_condition']

        if vehicle_query.get('vehicle_condition'):
            vehicle_condition = vehicle_query['vehicle_condition']
        else:
            vehicle_condition = ''

        insurance_company = vehicle_query['insurance_company']
        insurer_policy_number = vehicle_query['insurer_policy_number']
        insurance_expiry = vehicle_query['insurance_expiry']

        insurance_expiry_date, insurance_expiry_time, insurance_expiry_day = convert_milliseconds_to_date(insurance_expiry)

        # mot = vehicle_query['mot']

        if vehicle_query.get('mot'):
            mot = vehicle_query['mot']
        else:
            mot = ''
        # mot_expiry = vehicle_query['mot_expiry']

        if vehicle_query.get('mot_expiry'):
            mot_expiry = vehicle_query['mot_expiry']
        else:
            mot_expiry = 0

        # mot = ''
        # mot_expiry = 0

        mot_expiry_date, mot_expiry_time, mot_expiry_day = convert_milliseconds_to_date(mot_expiry)

        road_tax_expiry = vehicle_query['road_tax_expiry']

        road_tax_expiry_date, road_tax_expiry_time, road_tax_expiry_day = convert_milliseconds_to_date(road_tax_expiry)

        council_compliance = vehicle_query['council_compliance']

        council_compliance_date, council_compliance_time, council_compliance_day = convert_milliseconds_to_date(council_compliance)

        co2_emissions = vehicle_query['co2_emissions']
        vehicle_start = vehicle_query['vehicle_start']

        vehicle_start_date, vehicle_start_time, vehicle_start_day = convert_milliseconds_to_date(vehicle_start)

        hire_expiry = vehicle_query['hire_expiry']

        hire_expiry_date, hire_expiry_time, hire_expiry_day = convert_milliseconds_to_date(hire_expiry)

        # owner_driver = vehicle_query['owner_driver']

        if vehicle_query.get('owner_driver'):
            owner_driver = vehicle_query['owner_driver']
        else:
            owner_driver = ''
        # owner_driver = ''

        # vehicle_owner = vehicle_query['vehicle_owner']

        if vehicle_query.get('vehicle_owner'):
            vehicle_owner = vehicle_query['vehicle_owner']
        else:
            vehicle_owner = ''
        # vehicle_owner = ''

        device_imei = vehicle_query['device_imei']
        light_control = vehicle_query['light_control']
        status_control = vehicle_query['status_control']
        sensors = vehicle_query['sensors']

        # data_input = vehicle_query['data']

        if vehicle_query.get('data_input'):
            data_input = vehicle_query['data_input']
        else:
            data_input = ''
        # data_input = ''


        row_data = {
            'reference': reference,
            'vehicle_aka': vehicle_aka,
            'vehicle_make': vehicle_make,
            'vehicle_model': vehicle_model,
            'body_colour': body_colour,
            'body_type': body_type,
            'number_of_seats': number_of_seats,
            'vehicle_status': vehicle_status,
            'registration_year': registration_year,
            'registration_plate': registration_plate,
            'plate': plate,

            'plate_expiry_date': plate_expiry_date,
            'plate_expiry_day': plate_expiry_day,
            'plate_expiry_time': plate_expiry_time,

            'vehicle_phone': vehicle_phone,
            'fuel_type': fuel_type,
            'primary_vehicle': primary_vehicle,
            'vehicle_condition': vehicle_condition,
            'insurance_company': insurance_company,
            'insurer_policy_number': insurer_policy_number,

            'insurance_expiry_date': insurance_expiry_date,
            'insurance_expiry_day': insurance_expiry_day,
            'insurance_expiry_time': insurance_expiry_time,

            'mot': mot,

            'mot_expiry_date': mot_expiry_date,
            'mot_expiry_day': mot_expiry_day,
            'mot_expiry_time': mot_expiry_time,

            'road_tax_expiry_date': road_tax_expiry_date,
            'road_tax_expiry_day': road_tax_expiry_day,
            'road_tax_expiry_time': road_tax_expiry_time,

            'council_compliance_date': council_compliance_date,
            'council_compliance_day': council_compliance_day,
            'council_compliance_time': council_compliance_time,

            'co2_emissions': co2_emissions,

            'vehicle_start_date': vehicle_start_date,
            'vehicle_start_day': vehicle_start_day,
            'vehicle_start_time': vehicle_start_time,

            'hire_expiry_date': hire_expiry_date,
            'hire_expiry_day': hire_expiry_day,
            'hire_expiry_time': hire_expiry_time,

            'owner_driver': owner_driver,
            'vehicle_owner': vehicle_owner,
            'device_imei': device_imei,
            'light_control': light_control,
            'status_control': status_control,
            'sensors': sensors,
            'data_input': data_input
        }
      

        vehicle_types_fields = {
            "vehicle_name": 1
        }
        
        attributes = m_vehicle_types.find({}, vehicle_types_fields)

        attribute_data = {}

        for attribute in attributes:
            print(f"attribute: {attribute['vehicle_name']}")
            # field.append(attribute['vehicle_name'])
            if attribute['vehicle_name'] in vehicle_query['vehicle_types']:
                print(f"{attribute['vehicle_name']}: 'yes")
                attribute_data[attribute['vehicle_name']] = 'yes'
            else:
                attribute_data[attribute['vehicle_name']] =  'no'


        # driver_id = vehicle_query['driver_id']
        driver_filter = {
            'vehicle_id': vehicleId
        }

        driver_fields = {
            'driver_id': 1, 'reference': 1
        }

        vehicle_query_for_drivers = m_vehicles.find(driver_filter, driver_fields)

        user_fields = {
            'first_name': 1
        }

        driver_collection_fields = {
            'company_info.company_name': 1, 'primary_vehicle.vehicle_id': 1, 'primary_vehicle.vehicle_status': 1
        }

        driver_data = []
        for vehicle in vehicle_query_for_drivers:
            # driver_id = vehicle.get('driver_id', '')

            driver_id = vehicle.get('driver_id', '') if vehicle is not None else ''

            print(f"driver_id: {driver_id}")
            # reference = vehicle.get('reference', '')

            reference = vehicle.get('reference', '') if vehicle is not None else ''
            
            user_query_for_drivers = m_users.find_one({'_id': driver_id}, user_fields)
            print(f"user_query_for_drivers: {user_query_for_drivers}")
            # first_name = user_query_for_drivers.get('first_name', '')

            first_name = user_query_for_drivers.get('first_name', '') if user_query_for_drivers is not None else ''

            driver_query_for_drivers = m_drivers.find_one({'_id': driver_id}, driver_collection_fields)
            print(f"driver_query_for_drivers: {driver_query_for_drivers}")
            # company_name = driver_query_for_drivers.get('company_info', {}).get('company_name', '')

            company_name = driver_query_for_drivers.get('company_info', {}).get('company_name', '') if driver_query_for_drivers is not None else ''

            # assigned_vehicle_status = driver_query_for_drivers.get('primary_vehicle', {}).get('vehicle_status', '')

            assigned_vehicle_status = driver_query_for_drivers.get('primary_vehicle', {}).get('vehicle_status', '') if driver_query_for_drivers is not None else ''

            assigned_driver = reference + ' - ' + first_name + ' ' + company_name

            driver_data.append({
                'assigned_driver': assigned_driver,
                'assigned_vehicle_status': assigned_vehicle_status,
                "driver_link": "#"
            })

            print(f"vehicle: {vehicle}")

        context = {
            'vehicle_data': row_data,
            'attribute_data': attribute_data,
            'driver_data': driver_data
        }  

        print(f"context: {context}")

        return JsonResponse(context)

    return JsonResponse({'error': 'Invalid request method'})


@csrf_exempt
def update_vehicle_details(request):
    if request.method == 'POST':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_vehicles = m_db[md_config()['vehicles']]

        print(request.POST)

        json_data = json.loads(request.body.decode('utf-8'))

        vehicleId = json_data.get('vehicleId')
        vehicle_ref = json_data.get('vehicle_id')
        vehicle_aka = json_data.get('vehicle_aka')
        vehicle_make = json_data.get('vehicle_make')
        vehicle_model = json_data.get('vehicle_model')
        body_colour = json_data.get('body_colour')
        body_type = json_data.get('body_type')
        number_of_seats = json_data.get('number_of_seats')
        vehicle_status = json_data.get('vehicle_status')
        registration_year = json_data.get('registration_year')
        registration_plate = json_data.get('registration_plate')
        
        plate = json_data.get('plate')
        plate_expiry_date = json_data.get('plate_expiry_date')
        plate_expiry_time = json_data.get('plate_expiry_time')

        plate_expiry = int((datetime.strptime(f"{plate_expiry_date} {plate_expiry_time}", "%Y-%m-%d %H:%M")).timestamp() * 1000)

        vehicle_phone = json_data.get('vehicle_phone')
        fuel_type = json_data.get('fuel_type')
        primary_vehicle = json_data.get('primary_vehicle')
        vehicle_condition = json_data.get('vehicle_condition')

        insurer = json_data.get('insurer')
        policy_number = json_data.get('policy_number')
        ins_expiry_date = json_data.get('ins_expiry_date')
        ins_expiry_time = json_data.get('ins_expiry_time')

        ins_expiry = int((datetime.strptime(f"{ins_expiry_date} {ins_expiry_time}", "%Y-%m-%d %H:%M")).timestamp() * 1000)

        mot = json_data.get('mot')
        mot_expiry_date = json_data.get('mot_expiry_date')
        mot_expiry_time = json_data.get('mot_expiry_time')

        mot_expiry = int((datetime.strptime(f"{mot_expiry_date} {mot_expiry_time}", "%Y-%m-%d %H:%M")).timestamp() * 1000)

        road_tax_expiry_date = json_data.get('road_tax_expiry_date')
        road_tax_expiry_time = json_data.get('road_tax_expiry_time')

        road_tax_expiry = int((datetime.strptime(f"{road_tax_expiry_date} {road_tax_expiry_time}", "%Y-%m-%d %H:%M")).timestamp() * 1000)

        council_compliance_date = json_data.get('council_compliance_date')
        council_compliance_time = json_data.get('council_compliance_time')

        council_compliance = int((datetime.strptime(f"{council_compliance_date} {council_compliance_time}", "%Y-%m-%d %H:%M")).timestamp() * 1000)

        co2_emissions = json_data.get('co2_emissions')
        vehicle_start_date = json_data.get('vehicle_start_date')
        vehicle_start_time = json_data.get('vehicle_start_time')

        vehicle_start = int((datetime.strptime(f"{vehicle_start_date} {vehicle_start_time}", "%Y-%m-%d %H:%M")).timestamp() * 1000)

        hire_expiry_date = json_data.get('hire_expiry_date')
        hire_expiry_time = json_data.get('hire_expiry_time')

        hire_expiry = int((datetime.strptime(f"{hire_expiry_date} {hire_expiry_time}", "%Y-%m-%d %H:%M")).timestamp() * 1000)

        owner_driver = json_data.get('owner_driver')
        vehicle_owner = json_data.get('vehicle_owner')
        device_imei = json_data.get('device_imei')
        light_control = json_data.get('light_control')
        status_control = json_data.get('status_control')
        sensors = json_data.get('sensors')
        data = json_data.get('data')
    
        static_fields = {
            'reference': vehicle_ref,
            'vehicle_aka': vehicle_aka,
            'vehicle_make': vehicle_make,
            'vehicle_model': vehicle_model,
            'body_colour': body_colour,
            'body_type': body_type,
            'number_of_seats': number_of_seats,
            'vehicle_status': vehicle_status,
            'registration_year': registration_year,
            'registration_plate': registration_plate,
            'plate': plate,
            'plate_expiry': plate_expiry,
            'vehicle_phone': vehicle_phone,
            'fuel_type': fuel_type,
            'primary_vehicle': primary_vehicle,
            'vehicle_condition': vehicle_condition,
            'insurance_company': insurer,
            'insurance_policy_number': policy_number,
            'insurance_expiry': ins_expiry,
            'mot': mot,
            'mot_expiry': mot_expiry,
            'road_tax_expiry': road_tax_expiry,
            'council_compliance': council_compliance,
            'co2_emissions': co2_emissions,
            'vehicle_start': vehicle_start,
            'hire_expiry': hire_expiry,
            'owner_driver': owner_driver,
            'vehicle_owner': vehicle_owner,
            'device_imei': device_imei,
            'light_control': light_control,
            'status_control': status_control,
            'sensors': sensors,
            'data': data,
        }

        attributes_fields = [
            'tryme', 'shared', 'tryme_l', 'assist', 'access', 'estate', 'executive'
        ]

        # Create a mapping for key transformation
        key_map = {
            'tryme': 'TryME',
            'shared': 'Shared',
            'tryme_l': 'TryME.L',
            'assist': 'Assist',
            'access': 'Access',
            'estate': 'Estate',
            'executive': 'Executive'
        }

        # Extract relevant items from json_data
        dynamic_attributes = {k: v for k, v in json_data.items() if k in attributes_fields}

        # Construct vehicle_types list based on the above logic
        vehicle_types = [key_map[k] for k, v in dynamic_attributes.items() if v == 'yes']
        vehicle_types_list = {
            'vehicle_types': vehicle_types
        }

        update_feilds = {}

        update_feilds.update(static_fields)
        update_feilds.update(vehicle_types_list)

        print(f"updated_attributes: {update_feilds}")

        result = m_vehicles.update_one(
            {'vehicle_id': vehicleId},
            {'$set': update_feilds}
        )

        # Check if update was successful
        if result.modified_count:
            print(f"Successfully updated vehicle with ID: {vehicleId}")
        else:
            print(f"No vehicles updated for ID: {vehicleId}")
        
        return JsonResponse({"success": True})
       
    return JsonResponse({"success": False})


@csrf_exempt
def vehicle_document_request(request):
    if request.method == 'GET':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_vehicles = m_db[md_config()['vehicles']]

        vehicleId = request.GET.get('vehicleId')

        vehicle_fields = {
            'documents': 1
        }

        vehicle_filter = {
            'vehicle_id': vehicleId
        }

        vehicle_query = m_vehicles.find_one(vehicle_filter, vehicle_fields)

        # Define headings
        headings = [
            "Logbook V5C", 
            "Logbook Supporting Document", 
            "Private Hire Vehicle License", 
            "MOT Test Certificate", 
            "Registered Operator Contract"
        ]

        # Create an empty dictionary to store our final data structure
        vehicle_document_data = {}

        for idx, document in enumerate(vehicle_query['documents']):
            if idx < len(headings):  # Making sure we don't exceed the list length
                # Extract information for each document
                expiry_date_milliseconds = document['expiry_date']
                doc_title = headings[idx]
                doc_status = document['doc_status']
                expiry_date = convert_milliseconds_to_date(expiry_date_milliseconds)[0]
                doc_file = document['doc_file']
                file_type = document['file_type']
                modified_by = document['modified_by']

                # Store this document's data in our final data structure
                vehicle_document_data[doc_title] = {
                    'logbook': doc_title,
                    'doc_status': doc_status,
                    'expiry_date': expiry_date,
                    'doc_file': doc_file,
                    'file_type': file_type,
                    'modified_by': modified_by
                }

        context = {
            'vehicle_document_data': vehicle_document_data,
        }

        print(f"context: {context}")
        return JsonResponse(context)

    return JsonResponse({'error': 'Invalid request method'})

csrf_exempt
def update_vehicle_document(request):
    if request.method == 'POST':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_vehicles = m_db[md_config()['vehicles']]
        m_users = m_db[md_config()['users']]

        logged_in_user_email = request.session.get('additional_data', {}).get('email', None)

        my_filter = {
            'email': logged_in_user_email
        }
        print(f"my_filter: {my_filter}")

        driver_fields = {"_id": 1}

        user_details = m_users.find_one(my_filter, driver_fields)
        
        # Retrieve vehicleId from POST data
        vehicle_id = request.POST.get('vehicleId')

        print(f"request.POST: {request.POST}")

        action_type = request.POST.get('actionType')
        form_heading = request.POST.get('formHeading')

        print(f"action_type: {action_type}")
        print(f"form_heading: {form_heading}")



        print(f"request.FILES: {request.FILES}")



        if action_type == 'update':

            if form_heading == 'Logbook V5C':

                if form_heading == 'Logbook V5C':
                    document_location_in_array = 0
                elif form_heading == 'Logbook Supporting Document':
                    document_location_in_array = 1
                elif form_heading == 'Private Hire Vehicle License':
                    document_location_in_array = 2
                elif form_heading == 'MOT Test Certificate':
                    document_location_in_array = 3
                elif form_heading == 'Registered Operator Contract':
                    document_location_in_array = 4

                logbook = request.POST.get('logbook')



                expiry_date_string = request.POST.get('expiry_date')
                expiry_date = convert_date_to_milliseconds(expiry_date_string)
                doc_status = 'pending'
                modified_by = "staff"
                modifield_by_id = user_details['_id']

                # Accessing the uploaded file
                uploaded_file = request.FILES.get('file_upload')
                if uploaded_file:
                    # Optionally, save the file
                    file_name = default_storage.save(uploaded_file.name, uploaded_file)
                    file_url = default_storage.url(file_name)

                    try:
                        uploaded_file.seek(0)
                        file_content = uploaded_file.read()

                        magic_detector = magic.Magic()
                        file_type_output = magic_detector.from_buffer(file_content)
                        print(file_type_output)
                        
                        
                        file_type = get_standard_file_type(file_type_output)

                    except Exception as e:
                        print(f"Error detecting file type: {e}")

                    unique_blob_name = generate_unique_blob_name(file_name, folder="driverDocs")

                    # destination = f"driverDocs/{file_name}"


                    # Save the uploaded file temporarily
                    temp_file_path = default_storage.save(f"temp_{uploaded_file.name}", uploaded_file)
                    
                    # # # Save the uploaded file temporarily
                    # temp_file_path = f"/tmp/{file_name}"
                    # with open(temp_file_path, 'wb+') as temp_file:
                    #     for chunk in uploaded_file.chunks():
                    #         temp_file.write(chunk)

                    # Upload the file to Firebase Storage
                    file_url = upload_to_firebase(temp_file_path, unique_blob_name)

                    # Optionally, remove the temporary file if you want
                    os.remove(temp_file_path)


                context = {
                    'documents': [{
                        'doc_title': logbook,
                        'doc_status': doc_status,
                        'expiry_date': expiry_date,
                        'doc_file': file_url,
                        'file_type': file_type,
                        'modified_by': modified_by,
                        'modified_by_id': modifield_by_id
                    }],
                    # 'doc_file': doc_file
                }

                update_doc = context['documents'][0]
                
                print(f"context: {context}")

                print(f"document_location_in_array: {document_location_in_array}")
                print(f"vehicle_id: {vehicle_id}")

                result = m_vehicles.update_one(
                    {'vehicle_id': vehicle_id},
                    {
                        '$set':
                        {
                            f"documents.{document_location_in_array}.doc_title": update_doc['doc_title'],
                            f"documents.{document_location_in_array}.doc_status": update_doc['doc_status'],
                            f"documents.{document_location_in_array}.expiry_date": update_doc['expiry_date'],
                            f"documents.{document_location_in_array}.doc_file": update_doc['doc_file'],
                            f"documents.{document_location_in_array}.file_type": update_doc['file_type'],
                            f"documents.{document_location_in_array}.modified_by": update_doc['modified_by'],
                            f"documents.{document_location_in_array}.modified_by_id": update_doc['modified_by_id']
                        }
                    }
                )

                # Check if update was successful
                if result.modified_count:
                    print(f"Successfully updated vehicle with ID: {vehicle_id}")
                else:
                    print(f"No vehicles updated for ID: {vehicle_id}")

        elif action_type == 'verify':
            if form_heading == 'Logbook V5C':
                document_location_in_array = 0
            elif form_heading == 'Logbook Supporting Document':
                document_location_in_array = 1
            elif form_heading == 'Private Hire Vehicle License':
                document_location_in_array = 2
            elif form_heading == 'MOT Test Certificate':
                document_location_in_array = 3
            elif form_heading == 'Registered Operator Contract':
                document_location_in_array = 4

            print('verified button is pressed')
            doc_status = 'verified'

            context = {
                'documents': [{
                    'doc_status': doc_status
                }],
                # 'doc_file': doc_file
            }

            update_doc = context['documents'][0]
            
            print(f"context: {context}")

            result = m_vehicles.update_one(
                {'vehicle_id': vehicle_id},
                {
                    '$set':
                    {
                        f"documents.{document_location_in_array}.doc_status": update_doc['doc_status']
                    }
                }
            )

            # Check if update was successful
            if result.modified_count:
                print(f"Successfully updated vehicle with ID: {vehicle_id}")
            else:
                print(f"No vehicles updated for ID: {vehicle_id}")

        return JsonResponse({'success': True})

    # If something goes wrong
    return JsonResponse({'success': False})


@csrf_exempt
def get_vehicle_status(request):
    if request.method == 'GET':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_vehicles = m_db[md_config()['vehicles']]
        m_drivers = m_db[md_config()['drivers']]

        # booking_id = int(request.POST.get('booking_id'))
        print(request.GET)
        vehicleId = request.GET.get('vehicleId')
        print(f"vehicle_id: {vehicleId} --> get vehicle status")

        
        vehicle_filter = {
            'vehicle_id': vehicleId
        }

        vehicle_fields = {
            'driver_id': 1
        }

        vehicle_query_for_drivers = m_vehicles.find_one(vehicle_filter, vehicle_fields)
        driver_id = vehicle_query_for_drivers.get('driver_id', '')

        driver_filter = {
            'driver_id': driver_id
        }

        driver_fields = {
            'vehicle_id': 1, 'driver_id': 1, 'reference': 1, 'vehicle_status': 1, 'vehicle_inspection': 1
        }

        vehicle_query_for_status = m_vehicles.find(driver_filter, driver_fields)

        print(f"vehicle_query_for_status: {vehicle_query_for_status}")

        vehicles_data = []
        for vehicle in vehicle_query_for_status:
            print
            vehicles_data.append({
                'vehicle_reference': vehicle.get('reference', ''),
                'vehicle_status': vehicle.get('vehicle_status', ''),
                'vehicle_inspection': vehicle.get('vehicle_inspection', False),
                'vehicle_id': vehicle.get('vehicle_id', ),
                'driver_id': vehicle.get('driver_id', '')
            })

        # row_data = {
        #     'vehicle_reference': vehicle_reference,
        #     'vehicle_status': vehicle_status,
        #     'vehicle_inspection': vehicle_inspection,
        #     'driver_id': driver_id,
        # }

        context = {
            'vehicle_data': vehicles_data,
        }  

        return JsonResponse(context)

    elif request.method == 'POST':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_vehicles = m_db[md_config()['vehicles']]
        m_users = m_db[md_config()['users']]
        m_drivers = m_db[md_config()['drivers']]

        print(request.POST)
        vehicleId = request.POST.get('vehicleId')

        # # Check if update was successful
        # if result.modified_count:
        #     print(f"Successfully updated vehicle with ID: {vehicleId}")
        # else:
        #     print(f"No vehicles updated for ID: {vehicleId}")
        
        return JsonResponse({"success": True})

    return JsonResponse({'error': 'Invalid request method'})

csrf_exempt
def admin_vehicle_status(request):
    if request.method == 'GET':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_vehicles = m_db[md_config()['vehicles']]
        m_drivers = m_db[md_config()['drivers']]

        # booking_id = int(request.POST.get('booking_id'))
        print(request.GET)
        vehicleId = request.GET.get('vehicleId')
        print(f"vehicle_id: {vehicleId} --> get vehicle status")

        vehicle_filter = {'vehicle_id': vehicleId}

        vehicle_fields = {'driver_id': 1, 'reference': 1, 'vehicle_status': 1, 'primary_vehicle': 1}

        vehicle_query_for_status = m_vehicles.find_one(vehicle_filter, vehicle_fields) 
        vehicle_reference = vehicle_query_for_status.get("reference", "")
        v_vehicle_status = vehicle_query_for_status.get("vehicle_status", "")
        driver_id = vehicle_query_for_status.get("driver_id", "")
        v_primary_vehicle = vehicle_query_for_status.get("primary_vehicle", "")

        driver_filter = {'driver_id': driver_id}
        driver_fields = {'primary_vehicle': 1}
        driver_query_for_status = m_vehicles.find_one(vehicle_filter, vehicle_fields) 
        print(f"driver_query_for_status: {driver_query_for_status}")
        # d_primary_vehicle = driver_query_for_status.get("primary_vehicle", )
        # print(f"d_primary_vehicle: {d_primary_vehicle}")
        d_vehicle_status = driver_query_for_status.get("vehicle_status", "")

        vehicle_status = ''  # Initialize driver_id with a default value

        print(f"v_vehicle_status: {v_vehicle_status}")
        print(f"d_vehicle_status: {d_vehicle_status}")

        # # Check conditions and update vehicle_status accordingly
        # if v_vehicle_status == d_vehicle_status:
        #     vehicle_status = v_vehicle_status
        # else:
        #     print(f"vehicle_status in both collections [vheicle and driver] are not the same")

        vehicle_status = v_vehicle_status.lower()
        # vehicle_status = ('activated').lower()


        row_data = {
            'vehicle_reference': vehicle_reference,
            'vehicle_status': vehicle_status,
            'driver_id': driver_id,
            'primary_vehicle': v_primary_vehicle,
        }

        context = {
            'vehicle_data': row_data,
        }

        print(f"context: {context}")

        return JsonResponse(context)

    elif request.method == 'POST':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_vehicles = m_db[md_config()['vehicles']]
        m_drivers = m_db[md_config()['drivers']]

        print(request.POST)
        vehicle_id = request.POST.get('vehicle_id')
        driver_id = request.POST.get('driver_id')
        primary_vehicle = request.POST.get('primary_vehicle')
        action = request.POST.get('action')

        print(f"vehicle_id: {vehicle_id}")
        print(f"driver_id: {driver_id}")
        print(f"action: {action}")
            
        # Create a MongoDB client
        client = MongoClient(md_config()['client'])
            
        vehicle_status = None  # Define a default value

        # Determine the vehicle status based on the action
        if action == 'activate':
            vehicle_status = 'activated'

            if primary_vehicle == 'yes':

                m_vehicles_update = m_vehicles.update_one(
                    {'vehicle_id': vehicle_id},
                    {
                        '$set': {
                            'vehicle_status': vehicle_status
                        }
                    }
                )
                
                # Check if update was successful
                if m_vehicles_update.modified_count:
                    print(f"Successfully updated vehicle status from vehicle's collection: {vehicle_id}")
                else:
                    print(f"No vehicles updated in vehicle's collection: {vehicle_id}")
                

                # Update the document in the m_drivers collection
                m_drivers_update = m_drivers.update_one(
                    {'driver_id': driver_id},
                    {
                        '$set': {
                            'primary_vehicle.vehicle_status': vehicle_status
                        }
                    }
                )

            
                # Check if update was successful
                if m_drivers_update.modified_count:
                    print(f"Successfully updated vehicle status from driver's collection: {vehicle_id}")
                else:
                    print(f"No vehicle's status updated in driver's collection: {vehicle_id}")

            else:

                m_vehicles_update = m_vehicles.update_one(
                    {'vehicle_id': vehicle_id},
                    {
                        '$set': {
                            'vehicle_status': vehicle_status
                        }
                    }
                )
                
                # Check if update was successful
                if m_vehicles_update.modified_count:
                    print(f"Successfully updated vehicle status from vehicle's collection: {vehicle_id}")
                else:
                    print(f"No vehicles updated in vehicle's collection: {vehicle_id}")
                


        elif action == 'deactivate':
            vehicle_status = 'deactivated'

            if primary_vehicle == 'yes':

                m_vehicles_update = m_vehicles.update_one(
                    {'vehicle_id': vehicle_id},
                    {
                        '$set': {
                            'vehicle_status': vehicle_status
                        }
                    }
                )
                
                # Check if update was successful
                if m_vehicles_update.modified_count:
                    print(f"Successfully updated vehicle status from vehicle's collection: {vehicle_id}")
                else:
                    print(f"No vehicles updated in vehicle's collection: {vehicle_id}")
                

                # Update the document in the m_drivers collection
                m_drivers_update = m_drivers.update_one(
                    {'driver_id': driver_id},
                    {
                        '$set': {
                            'primary_vehicle.vehicle_status': vehicle_status
                        }
                    }
                )

                
                # Check if update was successful
                if m_drivers_update.modified_count:
                    print(f"Successfully updated vehicle status from driver's collection: {vehicle_id}")
                else:
                    print(f"No vehicle's status updated in driver's collection: {vehicle_id}")

            else:

                m_vehicles_update = m_vehicles.update_one(
                    {'vehicle_id': vehicle_id},
                    {
                        '$set': {
                            'vehicle_status': vehicle_status
                        }
                    }
                )
                
                # Check if update was successful
                if m_vehicles_update.modified_count:
                    print(f"Successfully updated vehicle status from vehicle's collection: {vehicle_id}")
                else:
                    print(f"No vehicles updated in vehicle's collection: {vehicle_id}")

            

                # Respond with a success message
            return JsonResponse({'message': f'Successfully updated vehicle status to {vehicle_status}'})


    return JsonResponse({'error': 'Invalid request method'})

  

csrf_exempt
def fetch_document(request):
    document_url = request.GET.get('url')  # Get the document URL from the query parameters
    if document_url:
        try:
            # Fetch the document content from the original URL using requests library
            response = requests.get(document_url)
            if response.status_code == 200:
                # Return the document content in the response
                content_type = response.headers.get('content-type', 'application/octet-stream')
                return HttpResponse(response.content, content_type=content_type)
            else:
                return HttpResponse("Failed to fetch document.", status=400)
        except Exception as e:
            return HttpResponse(f"Error: {str(e)}", status=500)
    else:
        return HttpResponse("Document URL not provided.", status=400)


def get_standard_file_type(magic_output):
    if "PDF document" in magic_output:
        return "PDF"
    elif "Microsoft Word" in magic_output:
        return "DOC/DOCX"
    elif "JPEG image data" in magic_output:
        return "JPEG"
    elif "PNG image data" in magic_output:
        return "PNG"
    else:
        return "Unknown"

@csrf_exempt
def get_attributes(request):

    if request.method == 'GET':
        cluster = MongoClient(md_config()['client'])
        m_db = cluster[md_config()['cluster']]
        m_vehicle_types = m_db[md_config()['vehicle_types']]

        vehicle_types_fields = {
            "vehicle_name": 1
        }
        
        attributes = m_vehicle_types.find({}, vehicle_types_fields)

        field = []
        for attribute in attributes:
            field.append(attribute['vehicle_name'])
            # print(f"attribute: {attribute}")
            # print(f"field: {field}")


    # fields = list(Attributes.objects.values_list('field_name', flat=True))
    return JsonResponse(field, safe=False)

## firebase media url w/o token --> more secure
def upload_to_firebase(file_path, destination_blob_name):
    """
    Upload a file to Firebase Storage.

    Parameters:
    - file_path: Loc
    al path to the file.
    - destination_blob_name: Destination path in Firebase Storage.

    Returns:
    - Public URL of the uploaded file.
    """
    bucket = storage.bucket()
    blob = bucket.blob(destination_blob_name)
    
    # Generate a download token
    download_token = str(uuid.uuid4())
    
    # Set the token as metadata for the blob
    blob.metadata = {'firebaseStorageDownloadTokens': download_token}
    
    blob.upload_from_filename(file_path)
    
    # Fetch the blob's metadata
    metadata = blob.metadata

    # Construct the permanent URL with token
    if metadata and 'firebaseStorageDownloadTokens' in metadata:
        token = metadata['firebaseStorageDownloadTokens']
        return construct_permanent_url(blob.bucket.name, blob.name, token)
    else:
        # If no token exists, fall back to the public URL (or handle this case differently if you prefer)
        return blob.public_url
    

def construct_permanent_url(bucket_name, blob_name, token):
    base_url = f"https://firebasestorage.googleapis.com/v0/b/{bucket_name}/o/"
    # URL encode the blob_name
    encoded_blob_name = quote(blob_name, safe='')
    return f"{base_url}{encoded_blob_name}?alt=media&token={token}"

## firebase media url with token --> less secure --> currently using
def get_download_url(bucket_name, blob_name):
    # Initialize storage client
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)
    
    # Generate a signed URL for the blob that expires in 1 hour.
    url = blob.generate_signed_url(
        version="v4",
        # This URL will be valid for 1 hour
        expiration=timedelta(hours=1),
        # Allow GET requests using this URL.
        method="GET"
    )
    
    return url


def generate_unique_blob_name(filename, folder):
    # Extract the file extension
    extension = os.path.splitext(filename)[1]
    
    # Generate a unique name using UUID and timestamp
    unique_name = f"{uuid.uuid4()}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}{extension}"
    
    # Combine with folder to get the full blob name
    blob_name = f"{folder}/{unique_name}"
    
    return blob_name


@csrf_exempt
def get_booking_directions(request):
        if request.method == 'POST':

            # booking_id = int(request.POST.get('booking_id'))
            booking_id = request.POST.get('booking_id')

            f_db = firestore.client()
            query = f_db.collection(u'bookings').document(booking_id).get()

@csrf_exempt
def get_booking_details(request):
        if request.method == 'POST':

            # booking_id = int(request.POST.get('booking_id'))
            booking_id = request.POST.get('booking_id')
            booking_id = booking_id.strip()
            # booking_id = '5GbgSU8yH1Onr4ehyCLl'

            cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
            m_db = cluster[md_config()['cluster']]
            m_drivers = m_db[md_config()['drivers']]
            m_vehicles = m_db[md_config()['vehicles']]

            f_db = firestore.client()
            query = f_db.collection(u'bookings').document(booking_id).get()

            # data = [] 
            # Iterate through the data and print it
            document = query.to_dict()

            if document.get('sent_to').get('vehicle_id') != '':
                vehicle_id = document.get('sent_to').get('vehicle_id', '')
                driver_id = document.get('sent_to').get('driver_id', '')
                driver_name = document.get('accepted_by').get('full_name', '')
                driver_contact = document.get('accepted_by').get('contact', '')
            elif document.get('accepted_by').get('vehicle_id') != '':
                vehicle_id = document.get('accepted_by').get('vehicle_id', '')
                driver_id = document.get('accepted_by').get('driver_id', '')
                driver_name = document.get('accepted_by').get('full_name', '')
                driver_contact = document.get('accepted_by').get('contact', '')
            else:
                vehicle_id = ''
                driver_id = ''
                driver_name = ''
                driver_contact = ''

            status = document.get('status', '')
            booking_id = booking_id
            operator = 'operator'
            created = document.get('booking_time', '')
            pickup = document.get('pickup_time', '')
            start = document.get('pickup_location', {}).get('address', '') # document.get('pickup_address', '')
            destination = document.get('dropOff_address', '')
            source = 'source'
            
            if document.get('total_distance', '') == 0:
                distance = document.get('estimated_distance', '')
            else:
                document.get('total_distance', '')
            
            extras = 0.00
            tip = 0.00
            cost = 0.00
            discount_cost = 0.00
            waiting_cost = 0.00
            if vehicle_id:
                vehicle = booking_veh_details(vehicle_id).get('vehicle_name', '')
            else:
                vehicle = ''
            # vehicle = booking_veh_details(vehicle_id)['vehicle_name']
            det = 'det'
            registration_plate = booking_veh_details(vehicle_id)['vehicle_reg']
            customer_phone = document.get('customer').get('full_name', '')
            seats = document.get('primary_vehicle', {}).get('number_of_seats', '')
            account = 'n/a'
            payment = 0.00
            tolls = 0.00
            waiting_mins = '5 mins'
            price = 0.00
            discount_price = 0.00
            waiting_cost_price = 0.00
            geopoints = document.get('google_poly_points', '')
            
            latlng_points = convert_geopoints_to_latlng(geopoints)
            
            booking_detail = {
                'status': status,
                'booking_id': booking_id,
                'operator': operator,
                'pickup': pickup,
                'created': created,
                'pickup': pickup,
                'start': start,
                'destination': destination,
                'source': source,
                'distance': distance,
                'extras': extras,
                'tip': tip,
                'cost': cost,
                'discount_cost': discount_cost,
                'waiting_cost': waiting_cost,
                'driver_name': driver_name,
                'driver_contact': driver_contact,
                'vehicle': vehicle,
                'det': det,
                'registration_plate': registration_plate,
                'customer_phone': customer_phone,
                'seats': seats,
                'account': account,
                'payment': payment,
                'tolls': tolls,
                'waiting_mins': waiting_mins,
                'price': price,
                'discount_price': discount_price,
                'waiting_cost_price': waiting_cost_price,
                'geopoints': latlng_points
            }
            
            # data.append(booking_detail)

                # Prepare the data to be sent back as a JSON response
            response_data = {
                'booking_detail': booking_detail
            }

            # print(response_data)
            # print(response_data)
            # Return the data as a JSON response
            return JsonResponse(response_data)

        return JsonResponse({'error': 'Invalid request method'})

@csrf_exempt
def get_log_details(request):
    if request.method == 'POST':
        print(request.POST)
        # booking_id = int(request.POST.get('booking_id'))
        booking_id = request.POST.get('booking_id')
        print(booking_id)
        booking_id = booking_id.strip()
        print(booking_id)

        # booking_id = booking_id[0].strip()
        # print(booking_id)
        # booking_id = '5GbgSU8yH1Onr4ehyCLl'

        cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
        m_db = cluster[md_config()['cluster']]
        m_drivers = m_db[md_config()['drivers']]
        m_vehicles = m_db[md_config()['vehicles']]

        f_db = firestore.client()
        query = f_db.collection('bookings').document(booking_id).get()

        # data = [] 
        # Iterate through the data and print it
        document = query.to_dict()
        # print(document)

        '''    LOGS DATA    '''
        
        booking_time = document.get('booking_time', '')
        pickup_time = document.get('pickup_time', '')
        accepted_at = document.get('accepted_at', '')
        duration = document.get('pickup_duration', '')
        eta = ''
        if duration != '':
            eta = accepted_at + timedelta(seconds=float(duration)*60)
        
        accepted_at = document.get('accepted_at', '')
        pickedup_at = document.get('pickup_time', '')
        
        time_format = "%B %d, %Y at %I:%M:%S %p %Z"
        tz = pytz.timezone("Europe/London")
        arrived_logs = [
            log for log in document.get('status_logs')
            if log["status"] == "arrived" and log["driver_id"] == document.get('accepted_by').get("driver_id", '')
        ]
        
        if arrived_logs:
            for arrived_log in arrived_logs:
                arrived_at = arrived_log.get("time", '')
        else:
            arrived_at = ''
            
        pob_logs = [
            log for log in document.get('status_logs')
            if log["status"] == "pob" and log["driver_id"] == document.get('accepted_by').get("driver_id", '')
        ]
        
        if pob_logs:
            for pob_log in pob_logs:
                pob_at = pob_log.get("time", '')
        else:
            pob_at = ''
            
        close_logs = [
            log for log in document.get('status_logs')
            if log["status"] == "complete" and log["driver_id"] == document.get('accepted_by').get("driver_id", '')
        ]
        
        if close_logs:
            for close_log in close_logs:
                close_at = close_log.get("time", '')
                close_reason = close_log.get("completion_reason", '')
        else:
            close_at = ''
            close_reason = ''
        
        cancel_logs = [
            log for log in document.get('status_logs')
            if log["status"] == "cancel" and log["driver_id"] == document.get('accepted_by').get("driver_id", '')
        ]
        
        if cancel_logs:
            for cancel_log in cancel_logs:
                cancel_at = cancel_log.get("time", '')
                cancel_reason = ''
                
        else:
            cancel_at = ''
            cancel_reason = ''
        
        my_filter = {'driver_id': document.get('accepted_by', {}).get('driver_id', '')}
        print(f'my_filter: {my_filter}')
        driver_fields = {"company_info": 1, "primary_vehicle": 1}
        vehicle_fields = {"reference": 1}
        driver_details = m_drivers.find_one(my_filter, driver_fields)
        vehicle_details = m_vehicles.find_one({'vehicle_id': document.get('accepted_by', {}).get('vehicle_id', '')}, vehicle_fields)
        
        # operator = driver_details.get('company_info', {}).get('company_name', '')
        operator = driver_details.get('company_info', {}).get('company_name', '') if driver_details else ''
        
        print(f'vehicle_details: {vehicle_details}')
        
        if vehicle_details:
            reference = vehicle_details.get('reference', '')
        else:
            reference = ''
        
        driver_full_name = document.get('accepted_by', {}).get('full_name', '')
        driver_contact_number = document.get('accepted_by', {}).get('contact', '')
        
        
        color = driver_details.get('primary_vehicle', {}).get('body_colour', '') if driver_details else ''
        # vehicle_name = driver_details.get('primary_vehicle', {}).get('vehicle_make', '') + ' ' + document.get('primary_vehicle', {}).get('vehicle_model', '')
        vehicle_name = (driver_details.get('primary_vehicle', {}).get('vehicle_make', '') + ' ' + driver_details.get('primary_vehicle', {}).get('vehicle_model', '')) if driver_details else ''

        registration_year = driver_details.get('primary_vehicle', {}).get('registration_year', '') if driver_details else ''
        registration = driver_details.get('primary_vehicle', {}).get('registration_plate', '') if driver_details else ''
        
        status = document.get('status', '')
        
        pickup_location = document.get('pickup_location', {}).get('address', '') # document.get('pickup_address', '')
        area = ''
        zone = ''
        management_instructions = ''
        driver_instructions = ''
        dropoff_location = document.get('dropOff_address', '')
        
        customer_name = document.get('customer', {}).get('full_name', '')
        customer_contact = document.get('customer', {}).get('contact', '')
        customer_account = ''
        payment = ''

        seats = driver_details.get('primary_vehicle', {}).get('number_of_seats', '') if driver_details else ''
        # vehicle_type = ', '.join(driver_details.get('primary_vehicle', {}).get('vehicle_types', ''))
        vehicle_type = ', '.join(driver_details.get('primary_vehicle', {}).get('vehicle_types', [])) if driver_details and driver_details.get('primary_vehicle') else ''

        
        source = document.get('source', '')
        estimated_mileage = str(round(document.get('estimated_distance', ''), 2)) + 'mi'
        actual_mileage = str(round(document.get('total_distance', ''), 2)) + 'mi'
        
        estimated_time = document.get('estimated_time', '')
        estimated_time_td = timedelta(minutes=estimated_time)
        estimated_duration = str(datetime.strptime(str(estimated_time_td), "%H:%M:%S").time())
        
        time_taken = document.get('time_taken', '')
        time_taken_td = timedelta(minutes=time_taken)
        total_duration = str(datetime.strptime(str(time_taken_td), "%H:%M:%S").time())
        
        try:
            average_speed = document.get('total_distance', '') / document.get('time_taken', '')
        except ZeroDivisionError:
            average_speed = 'N/A'
            
        zone_surge_cost_percent = ''
        zone_surge_price_percent = ''
        geopoints = document.get('google_poly_points', '')
            
        latlng_points = convert_geopoints_to_latlng(geopoints)
        
        booking_detail = {
            'booking_id': booking_id,
            'operator': operator,
            'status': status,
            'seats': seats,
            'booking_time': booking_time,
            'pickup_time': pickup_time,
            'duration': duration,
            'eta': eta,
            'accepted_at': accepted_at,
            'pickedup_at': pickedup_at,
            'arrived_at': arrived_at,
            'pob_at': pob_at,
            'close_at': close_at,
            'close_reason': close_reason,
            'cancel_at': cancel_at,
            'cancel_reason': cancel_reason,
            'reference': reference,
            'driver_full_name': driver_full_name,
            'driver_contact_number': driver_contact_number,
            'color': color,
            'vehicle_name': vehicle_name,
            'registration_year': registration_year,
            'registration': registration,
            'pickup_location': pickup_location,
            'area': area,
            'zone': zone,
            'management_instructions': management_instructions,
            'driver_instructions': driver_instructions,
            'dropoff_location': dropoff_location,
            'customer_name': customer_name,
            'customer_contact': customer_contact,
            'customer_account': customer_account,
            'payment': payment,
            'vehicle_type': vehicle_type,
            'source': source,
            'estimated_mileage': estimated_mileage,
            'actual_mileage': actual_mileage,
            'estimated_time': estimated_time,
            'estimated_time_td': estimated_time_td,
            'estimated_duration': estimated_duration,
            'time_taken': time_taken,
            'time_taken_td': time_taken_td,
            'total_duration': total_duration,
            'average_speed': average_speed,
            'zone_surge_cost_percent': zone_surge_cost_percent,
            'zone_surge_price_percent': zone_surge_price_percent,
            'geopoints': latlng_points
        }
        
        # data.append(booking_detail)

            # Prepare the data to be sent back as a JSON response
        response_data = {
            'booking_detail': booking_detail
        }

        print(response_data)

        # print(response_data)
        # print(response_data)
        # Return the data as a JSON response
        return JsonResponse(response_data)

    return JsonResponse({'error': 'Invalid request method'})

def convert_geopoints_to_latlng(geopoints):
    latlng_points = []
    for point in geopoints:
        latlng_points.append({'lat': point.latitude, 'lng': point.longitude})
    return latlng_points


def convert_milliseconds_to_date(milliseconds):
    # If the date is 0 milliseconds
    if milliseconds == 0:
        return ("1900-01-01", "00:00", "Wed 1st")
    
    # Convert the milliseconds to a date
    date_obj = datetime.utcfromtimestamp(milliseconds / 1000.0)  # Divide by 1000 to convert milliseconds to seconds
    
    # Extract date, time, and day from the date object
    formatted_date = date_obj.strftime('%Y-%m-%d')  # Only the date in the format yyyy-mm-dd
    formatted_time = date_obj.strftime('%H:%M')  # Only the time in the format hh:mm
    day_suffix = ["th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th"]
    day = date_obj.day
    if 10 <= day <= 20:
        suffix = "th"
    else:
        suffix = day_suffix[day % 10]
    formatted_day = f"{date_obj.strftime('%a')} {day}{suffix}"  # Day in the format e.g., "Wed 7th"
    
    return (formatted_date, formatted_time, formatted_day)


def convert_date_to_milliseconds(date_str, time_str="00:00"):
    """
    Convert a date and time to milliseconds since epoch.

    Parameters:
    - date_str: The date string in the format 'yyyy-mm-dd'
    - time_str: The time string in the format 'hh:mm'. Default is "00:00".

    Returns:
    - Milliseconds since the Unix epoch.
    """

    # Combine date and time strings
    combined_str = f"{date_str} {time_str}"

    # Convert the combined string to a datetime object
    date_obj = datetime.strptime(combined_str, '%Y-%m-%d %H:%M')

    # Convert the datetime object to milliseconds since epoch
    milliseconds = int(date_obj.timestamp() * 1000)

    return milliseconds



@csrf_exempt
def get_chat_details(request):
    if request.method == 'POST':

        # booking_id = int(request.POST.get('booking_id'))
        booking_id = request.POST.get('booking_id')
        print(f'booking_id_4rm_chat: {booking_id}')
        
        # booking_id = 'EVmYSlpJM3ibDFyhgdea'

        f_db = firestore.client()
        chat_logs = f_db.collection_group(u'driver_customer_chat').where('booking', '==', booking_id).get()

        if chat_logs is not None:

            chats = []
            for chat in chat_logs:
                chat_dict = chat.to_dict()
                
                chats.append({
                    'is_delivered': chat_dict['is_delivered'],
                    'is_read': chat_dict['is_read'],
                    'message': chat_dict['message'],
                    'message_from': chat_dict['message_from'],
                    'message_type': chat_dict['message_type'],
                    'read_time': chat_dict['read_time'],
                    'sent_time': chat_dict['sent_time']
                    })

            response_chat = {
                'chat_detail': chats
            }
            
            return JsonResponse(response_chat)
        
        else:
            response_chat = {
                'chat_detail': ''
            }

    return JsonResponse({'error': 'Invalid request method'})


def booking_veh_details(vehicle_id):

    cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
    m_db = cluster[md_config()['cluster']]
    m_vehicles = m_db[md_config()['vehicles']]
    print(f'vehicle_id: {vehicle_id}')
    if vehicle_id == '':
        result = {
                'vehicle_ref': '',
                'vehicle_reg': '',
            }
    else:

        vehicle_filter = {
                'vehicle_id': vehicle_id
            }
        
        vehicle_det = m_vehicles.find_one(vehicle_filter)

        if vehicle_det:
        
            vehicle_ref =  vehicle_det['reference']
            vehicle_reg = vehicle_det['registration_plate']
            vehicle_name = vehicle_det['vehicle_make'] + ' ' + vehicle_det['vehicle_model']

        else:
            vehicle_ref = ''
            vehicle_reg = ''
            vehicle_name = ''

        result = {
                'vehicle_ref': vehicle_ref,
                'vehicle_reg': vehicle_reg,
                'vehicle_name': vehicle_name
            }

    return result

def get_vehicle_details_from_mdb(vehicle_detail):
    cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
    m_db = cluster[md_config()['cluster']]
    m_vehicles = m_db[md_config()['vehicles']]
    # getting vehicle id from vehicle reference

    if 'vehicle_reference' in vehicle_detail:
        vehicle_fields = {"registration_plate": 1, "vehicle_id": 1}
        vehicle_filter = {
                'reference': vehicle_detail['vehicle_reference']
            }
        vehicle_det = m_vehicles.find_one(vehicle_filter, vehicle_fields)
        
        vehicle_id = ''
        vehicle_reg = ''

        if vehicle_det:
            vehicle_id = vehicle_det.get('vehicle_id', '')
            vehicle_reg = vehicle_det.get('registration_plate', '')
            
        result = {
                'vehicle_id': vehicle_id,
                'vehicle_reg': vehicle_reg,
            }

        return result
    
    # getting vehicle id from vehicle registration

    if 'vehicle_registration' in vehicle_detail:
        vehicle_fields = {"reference": 1, "vehicle_id": 1}
        vehicle_filter = {
                'registration_plate': vehicle_detail['vehicle_registration']
            }
        vehicle_det = m_vehicles.find_one(vehicle_filter, vehicle_fields)

        if vehicle_det:
            vehicle_id = vehicle_det['vehicle_id']
            vehicle_ref = vehicle_det['reference']

        else:
            vehicle_id = ''
            vehicle_ref = ''

        result = {
                'vehicle_id': vehicle_id,
                'vehicle_ref': vehicle_ref,
            }

        return result
    
    else:
        return JsonResponse({'error': 'Invalid vehicle detail'})

@csrf_exempt
def get_driver_details(request):
    if request.method == 'POST':



        # booking_id = int(request.POST.get('booking_id'))
        driver_id = request.POST.get('driver_id')
        
        # driver_id = 'mJDQKcnqDhfySxZv9ZOK9l6eGXI2'

        cluster = MongoClient(md_config()['client'])  # Replace with your MongoDB connection URL
        m_db = cluster[md_config()['cluster']]
        m_drivers = m_db[md_config()['drivers']]
        m_vehicles = m_db[md_config()['vehicles']]
        m_users = m_db[md_config()['users']]

        my_filter = {
            'driver_id': driver_id
        }
        print(f"my_filter: {my_filter}")

        driver_fields = {"driver_id": 1, "driver_status": 1, "primary_vehicle": 1}
        document = m_drivers.find_one(my_filter, driver_fields)
        print(f"document: {document}")
        user_fields = {"first_name": 1, "last_name": 1, "contact_number": 1}
        vehicle_fields = {"reference": 1}

        user_info = m_users.find_one({'_id': document['_id']}, user_fields)
        vehicle_info = m_vehicles.find_one({'vehicle_id': document.get('primary_vehicle', {}).get('vehicle_id', '')}, vehicle_fields)
        
        if user_info:
            first_name = user_info.get('first_name', '')
            last_name = user_info.get('last_name', '')
            phone = user_info.get('contact_number', '')
        else:
            first_name = ''
            last_name = ''
            phone = ''
            
        mobile = ''
        other_phone = ''
        badge = ''
        aka = ''
        
        if vehicle_info:
            reference = vehicle_info.get('reference', '')
        else:
            reference = ''
            
        color = document.get('primary_vehicle', {}).get('body_colour', '')
        vehicle_name = document.get('primary_vehicle', {}).get('vehicle_make', '') + ' ' + document.get('primary_vehicle', {}).get('vehicle_model', '')
        seats = document.get('primary_vehicle', {}).get('number_of_seats', '')
        
        vehicle = str(reference) + ' - ' + color + ' ' + vehicle_name + ' - ' + str(seats) + ' seater'
        plate = ''
        registration = document.get('primary_vehicle', {}).get('registration_plate', '')
        account_status = document.get('driver_status', {})
        booking_psv = ''

        driver_detail = {
            'driver_id': driver_id,
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'mobile': mobile,
            'other_phone': other_phone,
            'badge': badge,
            'aka': aka,
            'reference': reference,
            'vehicle': vehicle,
            'plate': plate,
            'registration': registration,
            'account_status': account_status,
            'booking_psv': booking_psv
        }

            # Prepare the data to be sent back as a JSON response
        response_data = {
            'driver_detail': driver_detail
        }

        return JsonResponse(response_data)

    return JsonResponse({'error': 'Invalid request method'})

@csrf_exempt
def geojson_view(request):

    # Find the static file
    geojson_path = finders.find('shp/bham.shp')
    
    # Load the GeoDataFrame from the GeoJSON file
    gdf = gpd.read_file(geojson_path)
    
    # Make sure it's in WGS84
    if gdf.crs != "EPSG:4326":
        gdf = gdf.to_crs("EPSG:4326")

    print(gdf)
    
    return JsonResponse(gdf.__geo_interface__)


# Create your views here.
def stockPicker(request):
    stock_picker  = tickers_nifty50()
    print(stock_picker )
    return render(request, 'mainapp/stockpicker.html', {'stockpicker': stock_picker })





def stockTracker(request):
    # taxibase_council = request.POST.get('taxi_base')
    # cluster = MongoClient("mongodb+srv://shahid_123:iRRHpdYoWApzFkWw@trymedriver.nmfto.mongodb.net/?retryWrites=true&w=majority")  # Replace with your MongoDB connection URL
    # m_db = cluster['trymeTaxiDatabase']
    # m_drivers = m_db['drivers']

    # pipeline = [
    #     {"$match": {
    #         "$and": [
    #             {"isLive": True},
    #             {"company_info.company_name": "Taxi Base A (Birmingham)"}
    #         ]
    #     }}
    # ]

    # drivers = m_drivers.aggregate(pipeline)

    # start_time = time.time()
    # data = {}

    # thread_list = []
    # que = queue.Queue()

    # for driver in drivers:
    #     thread = Thread(target = lambda q, arg1: process_driver, args=(que, driver))
    #     thread.start()
    #     thread_list.append(thread)

    # for thread in thread_list:
    #     thread.join()

    # while not que.empty():
    #     result = que.get()
    #     data.update(result)

    # end_time = time.time()
    # delta_t = end_time - start_time

    # print(delta_t)
    # print(data)












    stockpicker = request.GET.getlist('stockpicker')
    # print(stockpicker)

    available_stocks = tickers_nifty50()
    print(available_stocks)
    for i in stockpicker:
        if i in available_stocks:
            details = get_quote_data
            print(details)
            pass
        else:
            return HttpResponse('Error')

    # for i in stockpicker:
    #      result = get_quote_table(i)
    #      data.update({i: result})

    n_threads = len(stockpicker)
    start_time = time.time()
    data = {}

    thread_list = []
    que = queue.Queue()

    for i in range(n_threads):
        thread = Thread(target=lambda q, arg1: q.put({stockpicker[i]: get_quote_table(arg1)}), args = (que, stockpicker[i]))
        thread_list.append(thread)
        thread_list[i].start()

    for thread in thread_list:
        thread.join()

    while not que.empty():
        result = que.get()
        data.update(result)


    end_time = time.time()
    delta_t = end_time - start_time

    # start_time = time.time()
    # details = get_quote_table(d[0])
    # end_time = time.time()
    # delta_t = end_time - start_time
    print(delta_t)
    # print(details)
        # data.update({i: details})

    # d = ['ADANIENT.NS', 'APOLLOHOSP.NS', 'BAJAJ-AUTO.NS']
    # details = get_quote_table('ADANIENT.NS')
    print(data)
    print(websocket_urlpatterns)


    for url_pattern in websocket_urlpatterns:
        print(url_pattern.pattern)
    return render(request, 'mainapp/stocktracker.html', {'data': data, 'room_name': 'track'})


# MANAGE_SECTION ACOUNTS PAGE
def accounts(request):
    return render(request, "mainapp/accounts.html")

# MANAGE_SECTION ACOUNTS PAGE
def new_account(request):
    return render(request, "mainapp/new-account.html")

# MANAGE_SECTION AREAS PAGE
def areas(request):
    return render(request, "mainapp/areas.html")

# MANAGE_SECTION CUSTOMERS PAGE
def customers(request):

    user = get_user_details(request)
    username = user['first_name']

    context = {
        'username': username
        # ... other context variables ...
    }
    return render(request, "mainapp/customers.html", context)

# MANAGE_SECTION NEW CUSTOMER PAGE
def customer_detail(request):

    user = get_user_details(request)
    username = user['first_name']

    context = {
        'username': username
        # ... other context variables ...
    }
    return render(request, "mainapp/customer-detail.html", context)

# MANAGE_SECTION DRIVERS PAGE
def drivers(request):

    user = get_user_details(request)
    username = user['first_name']

    context = {
        'username': username
        # ... other context variables ...
    }
    return render(request, "mainapp/drivers.html", context)

# MANAGE_SECTION STAFF PAGE
def staff(request):

    user = get_user_details(request)
    username = user['first_name']

    context = {
        'username': username
        # ... other context variables ...
    }
    return render(request, "mainapp/staff.html", context)

# MANAGE_SECTION VEHICLES PAGE
def vehicles(request):

    user = get_user_details(request)
    username = user['first_name']

    context = {
        'username': username
        # ... other context variables ...
    }
    return render(request, "mainapp/vehicles.html", context)

# MANAGE_SECTION EDIT VEHICLE PAGE
def vehicle_detail(request):

    user = get_user_details(request)
    username = user['first_name']

    seat_options = list(range(2, 19))
    context = {
        'seat_options': seat_options,
        'username': username
        # ... other context variables ...
    }
    
    return render(request, "mainapp/vehicle-detail.html", context)

    # MANAGE_SECTION EDIT VEHICLE PAGE
def new_vehicle(request):

    user = get_user_details(request)
    username = user['first_name']

    context = {
        'username': username
        # ... other context variables ...
    }
    
    return render(request, "mainapp/new-vehicle.html", context)

# MANAGE_SECTION IMPORT PAGE
def imports(request):
    return render(request, "mainapp/import.html")

# MANAGE_SECTION RESTORE PAGE
def restore(request):
    return render(request, "mainapp/restore.html")

# MANAGE_SECTION DRAW PAGE
def draw(request):
    return render(request, "mainapp/draw.html")

# MANAGE_SECTION NEW DRIVER PAGE
def new_driver(request):
    return render(request, "mainapp/new-driver.html")

# MANAGE_SECTION NEW STAFF PAGE
def new_staff(request):
    return render(request, "mainapp/new-staff.html")








'''
    BACKEND UI
'''
# MANAGE_SECTION BACKEND UI PAGE
def backend_ui(request):
    return render(request, "mainapp/backend-ui.html")

@csrf_exempt
def bookings_allocation_python(request):
    # Sample data, you would fetch this from your database in a real scenario
    location = file_paths()['bookings_allocation']
    file_name = file_names()['flask_project']

    file = location + file_name
    print(f"file: {file}")
    config_data = read_config(file)

    data = {}
    # Dynamically create variables
    for key, value in config_data.items():
        data[key] = value

    return JsonResponse(data)

def flask_project_logs(request):

    if request.method == 'GET':
        location = file_paths()['bookings_allocation']
        file_name = file_names()['flask_logs']

        file = location + file_name
        print(f"file: {file}")

        print(f"request.get: {request.GET}")

        try:
            with open(file, 'r') as file:
                content = file.read()
                # Convert newlines to <br> tags for proper display in the UI
                formatted_content = content.replace('\n', '<br>')
                print(f"content: {formatted_content}")
            return JsonResponse({'log_data': formatted_content})
        except Exception as e:
            return JsonResponse({'error': 'Failed to read the log file.'}, status=500)


        # data = {}
        # # Dynamically create variables
        # for key, value in config_data.items():
        #     data[key] = value

    # return JsonResponse(config_data)
    return JsonResponse({})

def read_config(file_path):
    variables = {}
    
    with open(file_path, 'r') as file:
        lines = file.readlines()

    for line in lines:
        if '=' in line and not line.startswith('#'):
            key, value = line.split('=', 1)
            variables[key.strip()] = value.strip()

    return variables


def get_service_logs(request):
    file_name = file_names()['flask_project']
    try:
        # To get the status of the service
        status_result = subprocess.check_output(["systemctl", "status", file_name], universal_newlines=True)
        
        # To get the last 100 lines of the service logs
        log_result = subprocess.check_output(["journalctl", "-u", file_name, "-n", "100"], universal_newlines=True)
        
        return JsonResponse({
            'status': status_result,
            'logs': log_result
        })

    except subprocess.CalledProcessError as e:
        # Handle the error if the command fails
        return JsonResponse({
            'error': str(e)
        })



