import os

from channels.routing import ProtocolTypeRouter, URLRouter, get_default_application
from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tryme_dispatch.settings")

from channels.auth import AuthMiddlewareStack
from mainapp.routing import websocket_urlpatterns

application = ProtocolTypeRouter(
    {
        'http': get_asgi_application(),
        'websocket': AuthMiddlewareStack(
            URLRouter(
                websocket_urlpatterns
            )
        ),
    }
)


# from django.urls import path
# from . import consumers

# import django


# django.setup()


# application = get_default_application()

'''
application = ProtocolTypeRouter({
    "http": get_asgi_application(),
    "websocket": URLRouter([
        path('operator_page/realtime_drivers_movement/', consumers.RealtimeDriversMovementConsumer.as_asgi()),
    ]),
})
'''