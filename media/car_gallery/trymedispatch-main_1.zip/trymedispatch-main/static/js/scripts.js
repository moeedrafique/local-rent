/-------------Cookies-------/


function getCookie(name) {
  var cookieValue = null;
  if (document.cookie && document.cookie !== '') {
      var cookies = document.cookie.split(';');
      for (var i = 0; i < cookies.length; i++) {
          var cookie = jQuery.trim(cookies[i]);
          // Does this cookie string begin with the name we want?
          if (cookie.substring(0, name.length + 1) === (name + '=')) {
              cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
              break;
          }
      }
  }
  return cookieValue;
}
var csrftoken = getCookie('csrftoken');


/---------Setting up Firebase------------------/


//print()




//--------Clear Markers after 1 hour ---------//

setTimeout(function() {
  clearMarkers();
}, 3600000);









/---------Routing script-----/


let coordinates = {lat: lat, lng: lng};
var map;
let txba = tb;
var lat, lng;
var global_marker;
var data;
//var iconUrl = "{% static 'img/1.svg' %}";
var selectedBase = $("#loadTaxiBases option:selected").val();
var trafficLayer;

function initMap() {

  icon1 = {
      url: iconUrl,
      scaledSize: new google.maps.Size(60, 60), // here Google Maps API has been loaded
      origin: new google.maps.Point(0, 0),
      labelOrigin:  new google.maps.Point(26,30),
  };

  map = new google.maps.Map(document.getElementById('map'), {
    zoom: 11,
    center: coordinates, // coords, // coordinates, // {lat: 52.4862, lng: -1.8904},
    streetViewControl: false,
    mapTypeControlOptions: {
      mapTypeIds: [google.maps.MapTypeId.ROADMAP, google.maps.MapTypeId.HYBRID]
    }, // here´s the array of controls
    //disableDefaultUI: true, // a way to quickly hide all controls
    mapTypeControl: false,
    scrollwheel: true,
    scaleControl: false,
    zoomControl: true,
    zoomControlOptions: {
      style: google.maps.ZoomControlStyle.LARGE 
    },
    mapTypeId: google.maps.MapTypeId.TERRAIN,

  });

}

// Global array to keep track of the markers
var markers = [];

// Clear all markers from the map
function clearMarkers() {
  for (let i = 0; i < markers.length; i++) {
    markers[i].setMap(null);
  }
  markers = [];
}

function hideMarkers() {
  for (let i = 0; i < markers.length; i++) {
    markers[i].setVisible(false);
  }
}

function showMarkers(map, data, icon1) {

  // Clear previous markers
  hideMarkers();

  for (let x = 0; x < data.length; x++) {
    console.log(data[x]);

    const lat = parseFloat(data[x].driver_coords.lat);
    const lng = parseFloat(data[x].driver_coords.lng);

    const global_marker = new google.maps.Marker({
      position: { lat, lng },
      label: {
        text: data[x].vehicle_id,
        color: "#ffffff",
        fontSize: "10px",
        fontWeight: "light",
      },
      icon: icon1,
      visible: true,
      map: map,
    });

    google.maps.event.addListener(global_marker, 'click', function () {
      // Open the modal and set the driver information
      openDriverModal(data[x]);
    });

    console.log(`Marker set at (${lat}, ${lng})`);

    markers.push(global_marker);
  }
}


$(document).ready(function(){
  // var map;
  var zoneFeatures = [];  // a list to store the added features

  // Define your gradient colors
  const gradientColors = [
    '#b5e2fa', // Light Blue
    '#82c7f8',
    '#508ac7',
    '#285e8e',
    '#003366', // Dark Blue
    '#992600',
    '#cc0000',
    '#e53300',
    '#ff3300', // Dark Red
    '#ff6633'  // Light Red
  ];

  // Get color based on the 'multiple' value
  function getColor(multiple) {
    // Assuming multiple can vary between 1 and gradientColors.length
    // If you have a different range, you'll need to adjust the calculation
    let index = Math.min(multiple - 1, gradientColors.length - 1);
    return gradientColors[index];
  }

  // Set style after loading GeoJSON
  map.data.setStyle(function(feature) {
    return {
        fillColor: getColor(feature.getProperty('multiple')),
        strokeWeight: 1
    };
  });


  $("#map-surge").on("click", function(){  // Replace "toggle-zones" with the actual ID of your checkbox
      if (zoneFeatures.length === 0) {
          $.ajax({
              url: '/operator/geojson-view/',  // replace with your Django view's URL
              type: 'GET',
              dataType: 'json',
              success: function(data) {
                  console.log(data);
                  // Add the GeoJSON to the map and store the added features
                  map.data.addGeoJson(data).forEach(function(feature) {
                      zoneFeatures.push(feature);
                  });

                  // Set the style based on the 'multiple' value
                  map.data.setStyle(function(feature) {
                      return {
                          fillColor: getColor(feature.getProperty('multiple')),
                          strokeWeight: 0.25
                      };
                  });
              },
              error: function(error) {
                  console.log(error);
              }
          });
      } else {
          // Remove the added features
          zoneFeatures.forEach(function(feature) {
              map.data.remove(feature);
          });
          zoneFeatures = [];
      }
  });
});



function toggleTraffic() {
  console.log('toggle traffic button is pressed');
  if (trafficLayer === undefined) {
    // Create the TrafficLayer only once
    trafficLayer = new google.maps.TrafficLayer();
  }

  // Check if the traffic checkbox is checked
  if (document.getElementById("traffic").checked) {
    // If it is, add the TrafficLayer to the map
    trafficLayer.setMap(map);
  } else {
    // If it isn't, remove the TrafficLayer from the map
    trafficLayer.setMap(null);
  }
}





function openDriverModal(data) {
  // Set the driver information in the modal
  const driverInfo = document.getElementById('driverInfo');
  driverInfo.innerHTML = `
    <div class="driver_info_box" style="text-transform:uppercase;">
    <h5>Driver Info: ${data.driver_name} (${data.vehicle_id})<button class="btn btn-small btn-success float-right mb-3" style="text-transform:uppercase;">${data.job_status}</button></h5>
      <table class="table">
        <tr>
          <td>Vehicle</td>
          <td>${data.vehicle_id}</td>
          <td>Year</td>
          <td>${data.year}</td>
        </tr>
        <tr>
          <td>Device</td>
          <td><a href="tel:${data.device}" class="btn btn-outline-secondary">${data.device}</a></td>
          <td>Make</td>
          <td>${data.make}</td>
        </tr>
        <tr>
          <td>Mobile</td>
          <td><a href="tel:${data.device}" class="btn btn-outline-secondary">${data.device}</a></td>
          <td>Color</td>
          <td>${data.colour}</td>
        </tr>
        <tr>
          <td>Other</td>
          <td><a href="tel:${data.device}" class="btn btn-outline-secondary">${data.device}</a></td>
          <td>Reg</td>
          <td>${data.reg}</td>
        </tr>
        <tr>
          <td>Vehicle Phone</td>
          <td></td>
          <td>Plate</td>
          <td>${data.plate}</td>
        </tr>
        <tr>
          <td>Driver Type</td>
          <td>${data.driver_type}</td>
          <td>Badge Type</td>
          <td>${data.badge_type}</td>
        </tr>
        <tr>
          <td>Last Active</td>
          <td>${data.last_active}</td>
          <td>Last Booking</td>
          <td>${data.last_worked_time}</td>
        </tr>
        <tr>
          <td>Licence</td>
          <td>${data.license_number}</td>
          <td>Current Zone</td>
          <td></td>
        </tr>
      </table>
      
      <table  class="table"> 
        <tr>
          <td>Sites</td>
          <td>${data.sites}</td>
        </tr>
        <tr>
          <td>Allocated Vehicle Types</td>
          <td>${data.vehicle_types}</td>
        </tr>
        <tr>
          <td>Device Details</td>
          <td>${data.device_details}</td>
        </tr>
      </table>
      <div class="options clearfix bg-light p-2">
          <div class="row">
            <div class="col-sm-4 text-end">
              <button class="btn btn-secondary" style="text-transform:uppercase;">Bookings</button>
            </div>
            <div class="col-sm-4 text-center">
              <button class="btn btn-secondary" style="text-transform:uppercase;">Locations</button>
            </div>
            <div class="col-sm-4 text-start">
              <button class="btn btn-secondary float-right" style="text-transform:uppercase;">Messages</button>
            </div>
          </div>
        </div>
    </div>
  `;

  // Open the modal
  $('#driverModal').modal('show');
}


var body = document.querySelector('body');
var staticUrl = body.getAttribute('data-static-url');
var iconUrl = staticUrl + 'img/1.svg';

function available_drivers(selectedBase) {
  $.ajax({
    url: 'drivers_available/',  // URL of Django view
    method: 'POST',
    data: {
        taxi_base: selectedBase
    },
    dataType: 'json',
    beforeSend: function(xhr, settings) {
        xhr.setRequestHeader("X-CSRFToken", csrftoken );
    },

    success: function(data) {

      // var icon1 = {
      //   url: iconUrl,
      
      //   scaledSize: new google.maps.Size(60, 60),
      //   origin: new google.maps.Point(0, 0),
      //   //anchor: new google.maps.Point(18,65),
      //   labelOrigin:  new google.maps.Point(26,30),
      // };
      console.log(data);
      showMarkers(map, data, icon1);
    }
  }).done(function() {
    // selectedBase is accessible here because of JavaScript's closure mechanism.
    startInterval(selectedBase); 
  });
}

available_drivers(selectedBase);



// Call this every 30 seconds
function startInterval(selectedBase) {
  setInterval(function() {
    $.ajax({
      url: 'https://api.hyr3d.com/result',
      type: 'POST',
      headers: {
        'SECRET_KEY': 'dfdsagdgfsdfwer324225346tdfg4atgfd' // replace with your actual secret key
      },
      contentType: 'application/json',
      beforeSend: function(xhr, settings) {
        xhr.setRequestHeader("X-CSRFToken", csrftoken);
      },
      data: JSON.stringify({
        // "user_id": "Taxi Base A (Birmingham)"
        "user_id": selectedBase
      }),
      success: function(response) {
        // Assuming the response is an array of locations for each driver
        // clearMarkers(); // Clear previous markers



        // console.log(data);
        showMarkers(map, response, icon1);
        // console.log(response);
      },
      error: function(error) {
        console.log('Error:', error);
      }
    });
  }, 30000);
}



// console.log('selectedBase:', selectedBase);
  
async function tb_center(data) {
  lat = data.taxi_base_details.coordinates.lat;
  lng = data.taxi_base_details.coordinates.lng;
  // Use 'lat' and 'lng' to update your map's center location

  // Use 'lat' and 'lng' in your JavaScript code
  map = new google.maps.Map(document.getElementById('map'), {
    zoom: 11,
    center: {lat: lat, lng: lng}, // coords, // coordinates, // {lat: 52.4862, lng: -1.8904},
    streetViewControl: false,
    mapTypeControlOptions: {
      mapTypeIds: [google.maps.MapTypeId.ROADMAP, google.maps.MapTypeId.HYBRID]
    }, // here´s the array of controls
    //disableDefaultUI: true, // a way to quickly hide all controls
    mapTypeControl: false,
    scrollwheel: true,
    scaleControl: false,
    zoomControl: true,
    zoomControlOptions: {
      style: google.maps.ZoomControlStyle.LARGE 
    },
    mapTypeId: google.maps.MapTypeId.TERRAIN,

  });

}

$(function() {
  var csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

  $.ajaxSetup({
    headers: { "X-CSRFToken": csrftoken }
  });


  var lat, lng;
  var global_marker;
  var map;
  $('#loadTaxiBases').change(function() {
    var selectedBase = $(this).val();
    $.ajax({
      url: 'get_taxi_base_details/',
      method: 'POST',
      data: {
        taxi_base: selectedBase
      },
      dataType: 'json',
      beforeSend: function(xhr, settings) {
        xhr.setRequestHeader("X-CSRFToken", csrftoken);
      },
      success: function(data) {
        tb_center(data)
        console.log('selectedBase:', selectedBase);
        available_drivers(selectedBase);
      }
    });
  }); 
});   






// $(".signout").click(function() {
//   firebase.auth().signOut().then(function() {
//     // Sign-out successful.
//     window.location.href = "/"; // Redirect to homepage or login page.
//   }).catch(function(error) {
//     // An error happened.
//     console.log(error);
//   });
// });


$(document).ready(function() {
  // $('#loadBookings').click(function(e) {
  //   e.preventDefault();
    
  //   $.ajax({
  //     url: 'allbookings/',  // Replace with the correct URL
  //     type: 'POST',
  //     data: { 'results_per_page': $('#resultsPerPage').val() },
  //     success: function(response) {
  //       // Replace the content of the table body with the received HTML
  //       //$('#bookingsTable tbody').html(response);

  //       // Perform any additional operations or UI updates
  //       var data = response.data;
        

  //       // Clear the table body
  //       $('#bookingsTable tbody').empty();

  //       // Iterate through the data and append table rows
  //       for (var i = 0; i < data.length; i++) {
  //         var row = '<tr>' +
  //                     '<td>' + data[i].booking_id + '</td>' +
  //                     '<td>' + data[i].book_time + '</td>' +
  //                     '<td>' + data[i].status + '</td>' +
  //                     '<td>' + data[i].pickup + '</td>' +
  //                     '<td>' + data[i].destination + '</td>' +
  //                     '<td>' + data[i].drv + '</td>' +
  //                     '<td>' + data[i].vehicle_reg + '</td>' +
  //                     '<td>' + data[i].customer_name + '</td>' +
  //                     '<td>' + data[i].phone + '</td>' +
  //                     '<td>' + data[i].driver_declines + '</td>' +
  //                     '<td>' + data[i].account + '</td>' +
  //                     '<td>' + data[i].pay + '</td>' +
  //                     '<td>' + data[i].fare + '</td>' +
  //                     '<td>' + data[i].receipt + '</td>' +
  //                     '<td>' + ' <button booking-id= {{ row.booking_id }} class="btn btn-primary load-booking">View</button>' + '</td>' +
  //                   '</tr>';

  //         // Append the row to the table body
  //         $('#bookingsTable tbody').append(row);
  //       }

  //     },
  //     error: function(xhr, status, error) {
  //       console.log(error);
  //     }
  //   });
  // });

  // Capture the change event of the select element
  $('#resultsPerPage').change(function() {
      var resultsPerPage = $(this).val();  // Get the selected value

      // Make an AJAX request to the server
      $.ajax({
        url: 'allbookings/',  // Replace with the correct URL
        type: 'POST',
        data: { 'results_per_page': resultsPerPage },
        success: function(response) {
          
          //$('#bookingsTable tbody').html(response);
          
          // console.log(response.data.length)

          // Handle the response from the server
          var data = response.data;
          

          // Clear the table body
          $('#bookingsTable tbody').empty();

          // Iterate through the data and append table rows
          for (var i = 0; i < data.length; i++) {
            var row = '<tr>' +
                        '<td>' + data[i].booking_id + '</td>' +
                        '<td>' + data[i].book_time + '</td>' +
                        '<td>' + data[i].status + '</td>' +
                        '<td>' + data[i].pickup + '</td>' +
                        '<td>' + data[i].destination + '</td>' +
                        '<td>' + data[i].drv + '</td>' +
                        '<td>' + data[i].vehicle_reg + '</td>' +
                        '<td>' + data[i].customer_name + '</td>' +
                        '<td>' + data[i].phone + '</td>' +
                        '<td>' + data[i].driver_declines + '</td>' +
                        '<td>' + data[i].account + '</td>' +
                        '<td>' + data[i].pay + '</td>' +
                        '<td>' + data[i].fare + '</td>' +
                        '<td>' + data[i].receipt + '</td>' +
                        '<td>' + 
                          '<form class="booking-form" method="post">' +
                              '<input type="hidden" name="booking_id" value="' + data[i].booking_id + '">' + 
                              '<button type="submit" class="btn btn-primary load-booking">View</button>' +
                          '</form>' + 
                        '</td>' + 
                      '</tr>';

            // Append the row to the table body
            $('#bookingsTable tbody').append(row);
          }
        },
        error: function(xhr, status, error) {
          // Handle any error that occurs during the AJAX request
          console.log(error);
        }
      });
    });
  });




// $(document).on('click', '.load-booking', function() {
//   // Retrieve the booking ID from the button attribute
//   var bookingId = $(this).attr('booking-id');

//   // Perform an AJAX request to fetch the booking details
//   $.ajax({
//       url: 'get-booking-details/',  // Replace with the appropriate URL for retrieving booking details
//       method: 'POST',
//       data: { booking_id: bookingId },
//       success: function(response) {
//           // Update the HTML elements in the second code snippet with the retrieved booking details
//           $('#job').val(response.job);
//           $('#operator').val(response.operator);
//           // Update other fields accordingly
//       },
//       error: function() {
//           // Handle error case
//       }
//   });
// });



// function generateInfoWindowContent(data) {
//   return `
//   <div class="info-box mt-4">
//       <div class="card">
//           <div class="card-header">
//               <h3 class="clearfix">
//                   Driver Information: ${data.name} (${data.vehicle_number})
//                   <button class="btn btn-success float-end">${data.status}</button>
//               </h3>
//           </div>
//           ...
//           </div>
//       </div>
//   </div>
//   `;
// }



// async function showMarkers(map, data, icon1) {
  
//   for (let x = 0; x < data.length; x++) {
      
//       let marker = new google.maps.Marker({
//           position: {
//               lat: lat,
//               lng: lng
//           },
//           label: {
//               text: data[x].vehicle_id,
//               color: "#ffffff",
//               fontSize: "10px",
//               fontWeight: "light"
//           },
//           icon: icon1,
//           map: map
//       });

//       let infoWindow = new google.maps.InfoWindow({
//           content: generateInfoWindowContent(data[x])
//       });

//       marker.addListener("click", () => {
//           infoWindow.open({
//               anchor: marker,
//               map,
//               shouldFocus: false,
//           });
//       });

//       markers.push(marker);
//       console.log(`Marker set at (${lat}, ${lng})`);
//   }
// }





// console.log('before ws')
// var socket = new WebSocket('ws://localhost:8000/ws/mongo');

// socket.onopen = function(e) {
//   alert("[open] Connection established");
// };

// socket.onmessage = function(event) {
//   alert(`[message] Data received from server: ${event.data}`);
// };

// socket.onerror = function(error) {
//   alert(`[error] ${error.message}`);
// };

// socket.onclose = function(event) {
//   if (event.wasClean) {
//     alert(`[close] Connection closed cleanly, code=${event.code} reason=${event.reason}`);
//   } else {
//     // e.g. server process killed or network down
//     // event.code is usually 1006 in this case
//     alert('[close] Connection died');
//   }
// };


/*
      $.ajax({
        url: 'drivers_available/',  // URL of Django view
        method: 'POST',
        data: {
            taxi_base: selectedBase
        },
        dataType: 'json',
        beforeSend: function(xhr, settings) {
            xhr.setRequestHeader("X-CSRFToken", csrf_token);
        },

        success: function(data) {
          var icon1 = {
            url: iconUrl,
          
            scaledSize: new google.maps.Size(60, 60),
            origin: new google.maps.Point(0, 0),
            //anchor: new google.maps.Point(18,65),
            labelOrigin:  new google.maps.Point(26,30),
          };

          for (let x=0; x < data.length; x++){
            //await new Promise(resolve => setTimeout(resolve, 500)); // Wait for 1 second
            console.log(data[x]);

            lat = parseFloat(data[x].driver_coords.lat);
            lng = parseFloat(data[x].driver_coords.lng);

            // let position = new google.maps.LatLng(lat, lng);
            console.log(lat, lng)
            
            global_marker = new google.maps.Marker({
              position: {
                lat: lat,
                lng: lng
              }, //position,
              label: {
                text: data[x].vehicle_id,
                color: "#ffffff",
                fontSize: "10px",
                fontWeight: "light"
              },
              icon: icon1,
              visible: true,
              map: map
          });
          console.log(`Marker set at (${lat}, ${lng})`);
          }
        }
      });

*/


  


/* --changing dropdown will bring the icons for selected taxibase--*/
/*
$('#loadTaxiBases').change(function() {
  var selectedBase = $(this).val();
  console.log('selectedBase:', selectedBase);
  available_drivers(selectedBase);
});
*/


/*
const socket = new WebSocket('ws://your-domain/ws/data/');

socket.onmessage = function(event) {
    const data = JSON.parse(event.data);
    // Assuming `data` is an array of new markers to display
    data.forEach(function(markerData) {
        const marker = new google.maps.Marker({
            position: new google.maps.LatLng(markerData.lat, markerData.lng),
            map: map
        });
    });
};
*/

// var socket_2 = new WebSocket('websocat ws://localhost:8000/realtime_drivers_movement/');
// var ws_scheme = window.location.protocol == "https:" ? "wss" : "ws";
// var socket_2 = new WebSocket(ws_scheme + '://tryme_dispatch.herokuapp.com/ws/realtime_drivers_movement/');

// JavaScript code
$(document).ready(function() {
  // Close button click event
  $('.modal').on('click', '.close', function() {
    $('#driverModal').modal('hide'); // Hide the modal
  });
});


// Initialize Bootstrap modal
$(document).ready(function() {
  $('#driverModal').modal();
});
function handleMapError(event) {
  console.error("An error occurred while loading the Google Maps API: ", event);
  // Here, you can add any other code to handle the error, 
  // such as showing an error message to the user.
}
