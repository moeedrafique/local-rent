
function loadVehicleStatus() {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: '/vehicles/get-vehicle-status/',
            type: 'GET',
            data: {
                'vehicleId': vehicleId,
            },
            dataType: 'json',
            success: function(response){
                console.log('Vehicle Admin Response: ', response);

                // Get the vehicle data array
                var vehicleDataArray = response.vehicle_data;

                // Initialize an empty string to store HTML content for the table
                let tableBodyContent = '';

                // Loop through each dataset in the vehicle_data array
                for (const vehicleData of vehicleDataArray) {
                    var vehicleReference = vehicleData.vehicle_reference;
                    var vehicleStatus = vehicleData.vehicle_status;
                    var vehicleInspection = vehicleData.vehicle_inspection;
                    var driverId = vehicleData.driver_id;
                    var vehicleId = vehicleData.vehicle_id;

                    // Create a table row for the vehicle data
                    tableBodyContent += '<tr>';

                    // Add vehicle reference to the table cell
                    tableBodyContent += `<td>${vehicleReference}</td>`;

                    // Add vehicle status to the table cell
                    tableBodyContent += `<td>${vehicleStatus}</td>`;

                    // Create a checkbox for vehicle inspection
                    const checkboxHtml = vehicleInspection
                        ? '<div class="checkbox-container"><input type="checkbox" checked disabled></div>'
                        : '<div class="checkbox-container"><input type="checkbox"></div>';
                    tableBodyContent += `<td>${checkboxHtml}</td>`;

                    // Create an Authorise button with an onClick event
                    const authoriseButtonHtml = `<button class="btn btn-primary authorise-button" data-driver-id="${driverId}" disabled>Authorise</button>`;
                    tableBodyContent += `<td>${authoriseButtonHtml}</td>`;

                    // Close the table row
                    tableBodyContent += '</tr>';

                    // Update the HTML element with the concatenated content
                    $('#vehicleStatusTableBody').html(tableBodyContent);

                    // Add an event listener to each checkbox to enable/disable the corresponding button
                    $('input[type="checkbox"]').on('change', function () {
                        const $button = $(this).closest('tr').find('.authorise-button');
                        const isStatusActivated = $(this).closest('tr').find('td:eq(1)').text().toLowerCase() === 'activated';
                        const isInspectionChecked = this.checked;
                        const isButtonDisabled = isStatusActivated || !isInspectionChecked;
                        $button.prop('disabled', isButtonDisabled);
                    });

                    // Add an event listener to each "Authorise" button to handle AJAX request
                    $('.authorise-button').on('click', function (event) {
                        event.preventDefault(); // Prevent the default action (e.g., page reload)
                        const driverId = $(this).data('driver-id');

                        // Perform the AJAX request with driver_id as data
                        $.ajax({
                            url: '/vehicles/get-vehicle-status/',
                            type: 'POST', // Change to the appropriate HTTP method
                            data: {
                                'driver_id': driverId,
                                'vehicleId': vehicleId,
                            },
                            dataType: 'json',
                            success: function (response) {
                                // Handle the response if necessary
                            },
                            error: function (error) {
                                // Handle errors if necessary
                            }
                        });
                    });
                    
                }

                resolve();
            },
            error: function(error) {
                reject(error);
            }
        });
    });
}