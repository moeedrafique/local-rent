let vehicleId;


/*
CODE TO GET VEHICLE DOCUMENT DETAILS FOR VEHICLE DOCUMENTS TAB
*/

function loadVehicleDocuments() {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: '/vehicles/vehicle-document-request/',
            type: 'GET',
            data: {'vehicleId': vehicleId},
            dataType: 'json',
            success: function(response){
                console.log('Vehicle Documents Response: ', response);
                var data = response.vehicle_document_data;

                // Logbook V5C
                var v5cData = data["Logbook V5C"];
                if (v5cData) {
                    console.log("inside v5cData")
                    $('#logbookInput').val(v5cData.logbook);
                    $('#docStatusInput').val(v5cData.doc_status);
                    $('#expiryDateInput').val(v5cData.expiry_date);
                    $('#fileTypeInput').val(v5cData.file_type);
                    $('#modifiedByInput').val(v5cData.modified_by);
                    $('#v5cLogbookDocumentPath').val(v5cData.doc_file);
                }

                // Logbook Supporting Document
                var supportingDocData = data["Logbook Supporting Document"];
                if (supportingDocData) {
                    $('#supportingDocInput').val(supportingDocData.logbook); // Assuming the key in the backend response is 'logbook' for this as well
                    $('#supportingDocStatusInput').val(supportingDocData.doc_status);
                    $('#supportingDocExpiryDateInput').val(supportingDocData.expiry_date);
                    $('#supportingDocFileTypeInput').val(supportingDocData.file_type);
                    $('#supportingDocModifiedByInput').val(supportingDocData.modified_by);
                    $('#supportingDocDocumentPath').val(supportingDocData.doc_file);
                }

                // Private Hire Vehicle License Information Document
                var privateHireLicenseData = data["Private Hire Vehicle License"];
                if (privateHireLicenseData) {
                    $('#privateHireLicenseInput').val(privateHireLicenseData.logbook); // Assuming the key in the backend response is 'logbook' for this as well
                    $('#privateHireLicenseStatusInput').val(privateHireLicenseData.doc_status);
                    $('#privateHireLicenseExpiryDateInput').val(privateHireLicenseData.expiry_date);
                    $('#privateHireLicenseFileTypeInput').val(privateHireLicenseData.file_type);
                    $('#privateHireLicenseModifiedByInput').val(privateHireLicenseData.modified_by);
                    $('#privateHireLicenseDocumentPath').val(privateHireLicenseData.doc_file);
                }

                // MOT Test Certificate Information Document
                var motTestCertificateData = data["MOT Test Certificate"];
                if (motTestCertificateData) {
                    $('#motTestInput').val(motTestCertificateData.logbook); // Assuming the key in the backend response is 'logbook' for this as well
                    $('#motTestStatusInput').val(motTestCertificateData.doc_status);
                    $('#motTestExpiryDateInput').val(motTestCertificateData.expiry_date);
                    $('#motTestFileTypeInput').val(motTestCertificateData.file_type);
                    $('#motTestModifiedByInput').val(motTestCertificateData.modified_by);
                    $('#motTestDocumentPath').val(motTestCertificateData.doc_file);
                }

                // Registered Operator Contract Information Document
                var operatorContractData = data["Registered Operator Contract"];
                if (operatorContractData) {
                    $('#operatorContractInput').val(operatorContractData.logbook); // Assuming the key in the backend response is 'logbook' for this as well
                    $('#operatorContractStatusInput').val(operatorContractData.doc_status);
                    $('#operatorContractExpiryDateInput').val(operatorContractData.expiry_date);
                    $('#operatorContractFileTypeInput').val(operatorContractData.file_type);
                    $('#operatorContractModifiedByInput').val(operatorContractData.modified_by);
                    $('#operatorContractDocumentPath').val(operatorContractData.doc_file);
                }


                // Assuming the response contains a key 'doc_file' for the active section
                // We can set it to the first document as an example
                $('#documentImage').attr('src', v5cData ? v5cData.doc_file : '');

                resolve();
            },
            error: function(error) {
                reject(error);
            }
        });
    });
}



// // Call the functions to load data when the document is ready
// $(document).ready(function() {
//     loadDriversAssignedData();
//     loadStatusData();
// });


$(document).ready(function() {
    // Stage 1: Loading Spinner Logic
    $(document).ajaxStart(function() {
        $("#loadingSpinner").show();
    }).ajaxStop(function() {
        $("#loadingSpinner").hide();
    });

    // Stage 2: Global Variables and CSRF Token Setup
    let csrftoken = jQuery("[name=csrfmiddlewaretoken]").val();

    // Add the CSRF token to AJAX request
    $.ajaxSetup({
        headers: {
            'X-CSRFToken': csrftoken
        }
    });

    // Stage 3: Form and UI Logic

    // Function to collect form data
    function getVehicleFormData($form) {
        var unindexed_array = $form.serializeArray();
        console.log('Unindexed array:', unindexed_array);

        var indexed_array = {};
        $.map(unindexed_array, function (n, i) {
            indexed_array[n['name']] = n['value'];
        });

        return indexed_array;
    }

    /*
    CODE TO GET VEHICLE TYPES AS ATTRIBUTES
    */

    function loadAttributes() {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: '/get_attributes/',
                type: 'GET',
                dataType: 'json',
                success: function(data){
                    var container = $(".attributes-container");
                    data.forEach(function(field){
                        container.append(`
                            <div class="col-sm-6">
                                <label>${field}</label>
                                <select class="form-control mb-3" name="${field.replace(/ /g, "_").toLowerCase()}" id="input${field.replace(/ /g, "").replace(/\./g, "-")}">
                                    <option value="no" selected>no</option>
                                    <option value="yes">yes</option>
                                </select>
                            </div>
                        `);
                    });
                    resolve();
                },
                error: function(error) {
                    reject(error);
                }
            });
        })
    }


    // Populating Year Options for Registration Year
    let currentYear = new Date().getFullYear();
    let startYear = 1980;

    for (let i = currentYear; i >= startYear; i--) {
        $('#registrationYear').append(`<option value="${i}">${i}</option>`);
    }

    // Load attributes and fetch vehicle details
    loadAttributes().then(() => {
        vehicleId = new URLSearchParams(window.location.search).get("vehicle_id");
        console.log("vehicleId: ", vehicleId)
        if (vehicleId) {
            $.ajax({
                url: '/vehicles/vehicle-detail-request/',
                type: 'GET',
                data: {'vehicleId': vehicleId},
                dataType: 'json',
                success: function(response) {
                    // Assuming the response contains the customer data in a 'data' key
                    console.log('response: ', response);
                    var data = response.vehicle_data;
                    
                    // Populate the form fields$('#inputName').val(data.name);
                    $('#vehicle_id').val(data.reference);
                    $('#vehicleAka').val(data.vehicle_aka);
                    $('#vehicleMake').val(data.vehicle_make);
                    $('#vehicleModel').val(data.vehicle_model);
                    $('#bodyColour').val(data.body_colour);

                    $('#registrationYear').val(data.registration_year);
                    $('#registrationPlate').val(data.registration_plate);
                    $('#plate').val(data.plate);

                    $('#plateExpiryDate').val(data.plate_expiry_date);
                    $('#plateExpiryDay').val(data.plate_expiry_day);
                    $('#plateExpiryTime').val(data.plate_expiry_time);

                    $('#vehiclePhone').val(data.vehicle_phone);

                    $('#insurer').val(data.insurance_company);
                    $('#policyNumber').val(data.insurer_policy_number);

                    $('#insExpiryDate').val(data.insurance_expiry_date);
                    $('#insExpiryDay').val(data.insurance_expiry_day);
                    $('#insExpiryTime').val(data.insurance_expiry_time);

                    $('#mot').val(data.mot);

                    $('#motExpiryDate').val(data.mot_expiry_date);
                    $('#motExpiryDay').val(data.mot_expiry_day);
                    $('#motExpiryTime').val(data.mot_expiry_time);
                    $('#roadTaxExpiryDate').val(data.road_tax_expiry_date);

                    $('#roadTaxExpiryDay').val(data.road_tax_expiry_day);
                    $('#roadTaxExpiryTime').val(data.road_tax_expiry_time);
                    $('#councilComplianceDate').val(data.council_compliance_date);

                    $('#councilComplianceDay').val(data.council_compliance_day);
                    $('#councilComplianceTime').val(data.council_compliance_time);
                    $('#co2Emissionst').val(data.co2_emissions);

                    $('#vehicleStartDate').val(data.vehicle_start_date);

                    $('#vehicleStartDay').val(data.vehicle_start_day);
                    $('#vehicleStartTime').val(data.vehicle_start_time);

                    $('#hireExpiryDate').val(data.hire_expiry_date);
                    $('#hireExpiryDay').val(data.hire_expiry_day);
                    $('#hireExpiryTime').val(data.hire_expiry_time);

                    $('#ownerDriver').val(data.owner_driver);

                    $('#vehicleOwner').val(data.vehicle_owner);

                    $('#deviceImei').val(data.device_imei);
                    $('#lightControl').val(data.light_control);
                    $('#statusControl').val(data.status_control);
                    $('#sensors').val(data.sensors);


                    
                    $('#dataInput').val(data.data_input);

                    // Dynamically populate the attributes:
                    var attributesData = response.attribute_data;
                    for (var field in attributesData) {
                        var formattedField = "input" + field.replace(/ /g, "").replace(/\./g, "-");
                        $('#' + formattedField).val(attributesData[field]);
                    }

                    
                    var driversData = response.driver_data;
                    console.log('driversData: ', driversData)
      
                    // Initialize variables to store HTML content// Initialize variables to store HTML content for the table
                    let tableBodyContent = '';

                    // Iterate over the driversData array
                    for (const driverData of driversData) {
                        const assignedDriver = driverData.assigned_driver;
                        const assignedStatus = driverData.assigned_vehicle_status;
                        const driverLink = driverData.driver_link;

                        // Create a table row for each driver
                        tableBodyContent += '<tr>';

                        // Create a button with a link for each driver and apply CSS classes
                        const driverButton = `
                            <a href="${driverLink}" class="btn btn-primary driver-button">
                                ${assignedDriver}
                            </a>
                        `;

                        // Add the driver button and status to the respective table columns
                        tableBodyContent += `<td>${driverButton}</td>`;
                        tableBodyContent += `<td>${assignedStatus}</td>`;

                        // Close the table row
                        tableBodyContent += '</tr>';
                    }

                    // Update the HTML element with the concatenated content
                    $('#tableBody').html(tableBodyContent);


                    // Update the page title
                    $('#pageTitle').text(data.reference + ' - ' + data.vehicle_make + ' ' + data.vehicle_model);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error("AJAX error: " + textStatus + ' : ' + errorThrown);
                },
            });
        }
    });

    /*
    function loadVehicleStatus() {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: '/vehicles/admin-vehicle-status/',
                type: 'GET',
                data: {
                    'vehicleId': vehicleId,
                },
                dataType: 'json',
                success: function(response){
                    console.log('Vehicle Admin Response: ', response);

                    // Get the vehicle data
                    var vehicleData = response.vehicle_data;
                    var vehicleReference = vehicleData.vehicle_reference;
                    var vehicleStatus = vehicleData.vehicle_status;
                    var vehicleInspection = vehicleData.vehicle_inspection;
    
                    // Initialize variables to store HTML content for the table
                    let tableBodyContent = '';
    
                    // Create a table row for the vehicle data
                    tableBodyContent += '<tr>';
    
                    // Add vehicle reference to the table cell
                    tableBodyContent += `<td>${vehicleReference}</td>`;
    
                    // Add vehicle status to the table cell
                    tableBodyContent += `<td>${vehicleStatus}</td>`;
    
                    // Create a checkbox for vehicle inspection
                    const checkboxHtml = vehicleInspection
                        ? '<div class="checkbox-container"><input type="checkbox" checked disabled></div>'
                        : '<div class="checkbox-container"><input type="checkbox"></div>';
                    tableBodyContent += `<td>${checkboxHtml}</td>`;
    
                    // Create an Authorise button with an onClick event
                    const authoriseButtonHtml = '<button class="btn btn-primary" id="authoriseButton" disabled>Authorise</button>';
                    tableBodyContent += `<td>${authoriseButtonHtml}</td>`;
    
                    // Close the table row
                    tableBodyContent += '</tr>';
    
                    // Update the HTML element with the concatenated content
                    $('#vehicleStatusTableBody').html(tableBodyContent);
    
                    // Add an event listener to the checkbox to enable/disable the button
                    $('input[type="checkbox"]').on('change', function () {
                        const isStatusActivated = vehicleStatus.toLowerCase() === 'activated';
                        const isInspectionChecked = this.checked;
                        const isButtonDisabled = isStatusActivated || !isInspectionChecked;
                        $('#authoriseButton').prop('disabled', isButtonDisabled);
                    });
    
                    // Add an event listener to the "Authorise" button to handle AJAX request
                    $('#authoriseButton').on('click', function (event) {
                        event.preventDefault(); // Prevent the default action (e.g., page reload)
                        
                        driverId = vehicleData.driver_id; // Get the driver_id from the response
    
                        // Perform the AJAX request with driver_id as data
                        $.ajax({
                            url: '/vehicles/get-vehicle-status/',
                            type: 'POST', // Change to the appropriate HTTP method
                            data: {
                                'driver_id': driverId,
                                'vehicleId': vehicleId
                            },
                            dataType: 'json',
                            success: function (response) {
                                // Handle the response if necessary
                            },
                            error: function (error) {
                                // Handle errors if necessary
                            }
                        });
                    });
    
                    resolve();
                },
                error: function(error) {
                    reject(error);
                }
            });
        });
    }
    */

    function loadVehicleStatus() {
        url = '/vehicles/admin-vehicle-status/'
        return new Promise((resolve, reject) => {
            $.ajax({
                url: url,
                type: 'GET',
                data: {
                    'vehicleId': vehicleId,
                },
                dataType: 'json',
                success: function(response){
                    console.log('Vehicle Admin Response: ', response);
    
                    // Get the vehicle data array
                    var vehicleData = response.vehicle_data;
                    console.log('vehicleData: ', vehicleData);
    
                    // Initialize an empty string to store HTML content for the table
                    let tableBodyContent = '';
    
                    var vehicleReference = vehicleData.vehicle_reference;
                    var vehicleStatus = vehicleData.vehicle_status;
                    var driverId = vehicleData.driver_id;
                    var primaryVehicle = vehicleData.primary_vehicle;

                    console.log('vehicleReference: ', vehicleReference);
                    console.log('vehicleStatus: ', vehicleStatus);
                    console.log('driverId: ', driverId);

                    // Create a table row for the vehicle data
                    tableBodyContent += '<tr>';

                    // Add vehicle reference to the table cell
                    tableBodyContent += `<td>${vehicleReference}</td>`;

                    // Add vehicle status to the table cell
                    tableBodyContent += `<td>${vehicleStatus}</td>`;

                    // Determine the button label and disable status based on vehicle status
                    let buttonLabel = '';
                    let isButtonDisabled = false;
                    let action = '';

                    if (vehicleStatus === 'activated') {
                        buttonLabel = 'Deactivate';
                        action = 'deactivate';
                    } else if (vehicleStatus === 'deactivated') {
                        buttonLabel = 'Activate';
                        action = 'activate';
                    } else if (vehicleStatus === 'pending' || vehicleStatus === 'changevehiclename') {
                        buttonLabel = 'Deactivate';
                        isButtonDisabled = true;
                        action = 'deactivate';
                    }

                    // Create an Authorise button with an onClick event
                    const authoriseButtonHtml = `
                        <button class="btn btn-primary authorise-button" data-driver-id="${driverId}" ${isButtonDisabled ? 'disabled' : ''}>
                            ${buttonLabel}
                        </button>
                    `;
                    tableBodyContent += `<td>${authoriseButtonHtml}</td>`;

                    // Close the table row
                    tableBodyContent += '</tr>';
    
                    // Update the HTML element with the concatenated content
                    $('#vehicleStatusTableBody').html(tableBodyContent);
    
                    // Add an event listener to each "Authorise" button to handle AJAX request
                    $('.authorise-button').on('click', function (event) {
                        event.preventDefault(); // Prevent the default action (e.g., page reload)
                        const driverId = $(this).data('driver-id');    
    
                        // Perform the AJAX request with driver_id and action as data
                        $.ajax({
                            url: url, // Replace with your AJAX endpoint
                            type: 'POST', // Change to the appropriate HTTP method
                            data: {
                                'driver_id': driverId,
                                'vehicle_id': vehicleId,
                                'primary_vehicle': primaryVehicle,
                                'action': action,
                            },
                            dataType: 'json',
                            success: function (response) {
                                console.log('job successful');
                                // Check if the response contains a 'message' field
                                if (response.message) {
                                    const statusMessage = $('#status-message');
                                    
                                    // Set the message text based on the response
                                    statusMessage.text(response.message);
                            
                                    // Show the message
                                    statusMessage.show();
                            
                                    // Hide the message after 15 seconds
                                    setTimeout(function () {
                                        statusMessage.hide();
                                    }, 15000); // 15 seconds in milliseconds
                                }

                                loadVehicleStatus().then(() => {
                                    $('#vehicle-admin').show();
                                }).catch(error => {
                                    console.error('Error loading vehicle status:', error);
                                });

                            },
                            error: function (error) {
                                // Handle errors if necessary
                            }
                        });
                    });
    
                    resolve();
                },
                error: function(error) {
                    reject(error);
                }
            });
        });
    }
    

    // Save data on "Save" button click for Vehicle form
    $(document).on('click', 'input[name="update-vehicle"]', function(e) {
        e.preventDefault();
        var formData = getVehicleFormData($('.vehicle-edit-form'));
        formData['vehicleId'] = vehicleId;
        console.log('formData: ', formData)

        $.ajax({
            url: '/vehicles/update-vehicle-details/',  // change this to your actual endpoint for vehicle update
            type: 'POST',
            data: JSON.stringify(formData),
            dataType: 'json',
            headers: {
                'X-CSRFToken': csrftoken
            },
            success: function (response) {
                var statusDiv = $('#updateStatus');
                
                if (response.success) {
                    statusDiv.text('Vehicle details are updated on the database.').css('color', 'grey');
                } else {
                    statusDiv.text('Vehicle details are not updated on the database.').css('color', 'red');
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.error("AJAX error during save operation: " + textStatus + ' : ' + errorThrown);
                $('#updateStatus').text('There was an error saving the vehicle details.').css('color', 'red');
            }
        });
    });

    // Cancel button action
    document.getElementById('cancelButton').addEventListener('click', function() {
        window.location.href = "{% url 'vehicles' %}";
    });

    // Tab Navigation Logic
    $('.tab-pane').not('.active').hide();
    $('#vehicleTabs a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
        const tabId = $(e.target).attr('href').replace("#", "");
        switch (tabId) {
            case 'vehicle-details':
                $('#vehicle-details').show();
                break;
            case 'vehicle-documents':
                loadVehicleDocuments().then(() => {
                    $('#vehicle-documents').show();
                }).catch(error => {
                    console.error('Error loading vehicle documents:', error);
                });
                break;
            case 'vehicle-admin':
                loadVehicleStatus().then(() => {
                    $('#vehicle-admin').show();
                }).catch(error => {
                    console.error('Error loading vehicle status:', error);
                });
                break;
        }
    });

    // Zoom Logic for Document Image
    let zoomLevel = 1;
    const ZOOM_INCREMENT = 0.2;

    $('#zoomIn').click(function() {
        zoomLevel += ZOOM_INCREMENT;
        $('#documentImage').css('transform', `scale(${zoomLevel})`);
    });

    $('#zoomOut').click(function() {
        zoomLevel -= ZOOM_INCREMENT;
        if (zoomLevel < ZOOM_INCREMENT) zoomLevel = ZOOM_INCREMENT;
        $('#documentImage').css('transform', `scale(${zoomLevel})`);
    });

    // Optional: if you want to keep both zoom methods, uncomment the below code.
    // However, I recommend using only one for consistency.
    /*
    $(document).on('click', '#zoomIn', function() {
        var img = $('#documentImage');
        var currWidth = img.width();
        img.width(currWidth + 100);
        adjustModalSize();
    });

    $(document).on('click', '#zoomOut', function() {
        var img = $('#documentImage');
        var currWidth = img.width();
        img.width(currWidth - 100);
        adjustModalSize();
    });
    */

    function adjustModalSize() {
        var img = $('#documentImage');
        var modalDialog = $('#docViewModal .modal-dialog');
        modalDialog.css('max-width', img.width() + 40 + 'px');
    }
});

document.addEventListener("DOMContentLoaded", function() {
    // // View Document Buttons
    // function viewDocument(buttonId, inputPathId) {
    //     document.getElementById(buttonId).addEventListener('click', function() {
    //         const path = document.getElementById(inputPathId).value;
    //         if(path) {
    //             window.open(path, '_blank');
    //         } else {
    //             alert('No Document Path provided.');
    //         }
    //     });
    // }

    viewDocument('viewDocButton', 'v5cLogbookDocumentPath');
    viewDocument('viewSupportingDocButton', 'supportingDocDocumentPath');
    viewDocument('viewPrivateHireLicenseButton', 'privateHireLicenseDocumentPath');
    viewDocument('viewMOTTestButton', 'motTestDocumentPath');
    viewDocument('viewOperatorContractButton', 'operatorContractDocumentPath');

    // Generic function to view document in the modal
    function viewDocument(buttonId, inputPathId) {
        document.getElementById(buttonId).addEventListener('click', function() {
            const path = document.getElementById(inputPathId).value;
            console.log("path: ", path)
            if (path) {
                const fileExtension = path.split('.').pop().toLowerCase();
                if (fileExtension === 'pdf' || fileExtension === 'doc' || fileExtension === 'docx') {
                    // For PDF and Word documents, open in a new tab/window
                    window.open(path, '_blank');
                } else {
                    // For images, display in the modal
                    document.getElementById('documentContent').innerHTML = `<img src="${path}" alt="Document" style="max-width: 100%; height: auto;">`;
                    $('#docViewModal').modal('show'); // Show the modal
                }
            } else {
                alert('No Document Path provided.');
            }
        });
    }

    // Handle the generic document upload (you may need to implement the upload functionality)
    // This remains unchanged unless you want to make modifications.

});

// $(document).ready(function() {
//     console.log("Document is ready."); // Add this line to check if the document is ready


//     // When the modal's 'Upload' button is clicked
//     $("#confirmUpload").click(function() {
//         console.log("Upload button clicked.");
//         let fileInput = document.getElementById('v5cLogbookDocument');
//         let filePath = fileInput.value;
//         let allowedExtensions = /(\.jpg|\.jpeg|\.png|\.doc|\.docx|\.pdf)$/i;

//         if (!allowedExtensions.exec(filePath)) {
//             alert('Invalid file type! Please upload JPG, JPEG, PNG, DOC, DOCX, or PDF files only.');
//             fileInput.value = ''; 
//         } else {
//             // Show the file path in the input field
//             $("#v5cLogbookDocumentPath").val(filePath.split('\\').pop());

//             // Close the modal
//             $("#uploadModal").modal('hide');
//         }
//     });
// });


// $(document).ready(function() {
//     // Function to handle file upload
//     function handleFileUpload(inputFieldId, formHeading) {
//         console.log("next stage of upload button clicked.");
//         let fileInput = document.getElementById(inputFieldId);
//         let filePath = fileInput.value;
//         let allowedExtensions = /(\.jpg|\.jpeg|\.png|\.doc|\.docx|\.pdf)$/i;

//         if (!allowedExtensions.exec(filePath)) {
//             alert('Invalid file type! Please upload JPG, JPEG, PNG, DOC, DOCX, or PDF files only.');
//             fileInput.value = '';
//         } else {
//             // The file is valid, and you can proceed with uploading it
//             // Show the file path in the input field (if needed)
//             $("#" + inputFieldId + "Path").val(filePath.split('\\').pop());

//             // Set the form heading for later reference in the AJAX call
//             $("#formHeadingInput").val(formHeading);

//             // Close the modal or perform any other actions
//             // $("#uploadModal" + formHeading).modal('hide');
//             $("#uploadModal").modal('hide');


//             // Now, you can trigger your AJAX call here to upload the file and process it on the server
//             // Make sure to add the code for the AJAX call and handling the server response here
//         }
//     }

//     // When the 'Upload File' button is clicked
//     $("#triggerFileUpload").click(function() {
//         let formHeading = $("#formHeadingInput").val();
//         console.log('formHeading: ', formHeading)
//         handleFileUpload('fileUploadInput', formHeading);
//     });
// });


$(document).ready(function() {
    // Function to handle file upload
    function handleFileUpload(inputId) {
        let fileInput = $("#" + inputId)[0];
        let filePath = fileInput.value;
        let allowedExtensions = /(\.jpg|\.jpeg|\.png|\.doc|\.docx|\.pdf)$/i;

        if (!allowedExtensions.exec(filePath)) {
            alert('Invalid file type! Please upload JPG, JPEG, PNG, DOC, DOCX, or PDF files only.');
            fileInput.value = '';
        } else {
            // The file is valid, and you can proceed with uploading it
            // Show the file path in the input field (if needed)
            $("#" + inputId).val(filePath.split('\\').pop());

            // Close the modal or perform any other actions
            $("#uploadModal").modal('hide');

            // Now, you can trigger your AJAX call here to upload the file and process it on the server
            // Make sure to add the code for the AJAX call and handling the server response here
        }
    }

    // When a file upload button is clicked
    $(".file-upload-button").click(function() {
        let inputId = $(this).data('input-id');
        console.log('inputId: ', inputId)
        handleFileUpload(inputId);
    });
});


$(document).ready(function() {
    $('#v5cLogbookDocument').on('change', function() {
        var fileName = $(this).val().split('\\').pop();
        $(this).closest('.modal').find('.form-control').val(fileName);
    });
});

$(document).on('click', '.btn.btn-secondary, .btn.btn-success', function(e) {
    e.preventDefault();

    // Determine which button was clicked
    var actionType = $(this).hasClass('btn-secondary') ? 'update' : 'verify';

    // Get the heading for the current form block/card
    var formHeading = $(this).closest('.card').find('h6').text();

    // Collect form data
    var formData = new FormData($('.vehicle-document-form')[0]);

    // Add vehicleId, actionType, and formHeading to formData
    formData.append('vehicleId', vehicleId);
    formData.append('actionType', actionType);
    formData.append('formHeading', formHeading);

    console.log('vehicleId: ', vehicleId)

    for (var pair of formData.entries()) {
        console.log(pair[0] + ', ' + pair[1]);
    }

    // AJAX call to Django backend
    $.ajax({
        url: '/vehicles/update-vehicle-document/',
        type: 'POST',
        data: formData,
        dataType: 'json',
        processData: false,  // Important! Tell jQuery not to process the data
        contentType: false,  // Important! Tell jQuery not to set contentType
        success: function(response) {
            if (response.success) {
                console.log('Successfully updated vehicle documents.');
                loadVehicleDocuments();
            } else {
                console.log('Failed to update vehicle documents. Please try again.');
            }
        },
        error: function(error) {
            console.log(error);
            alert('Error occurred while updating vehicle documents.');
        }
    });
});

$(document).ready(function() {
    // Function to check and update button state
    function updateVerifiedButtonState() {
        var statusValue = $('#docStatusInput').val();
        if(statusValue === 'verified') {
            $('.btn-success').prop('disabled', true);
        } else {
            $('.btn-success').prop('disabled', false);
        }
    }

    // Call the function upon page load
    updateVerifiedButtonState();

    // Optionally, if the status field can be changed dynamically (e.g., dropdown change), 
    // you can also update the button state upon status change.
    $('#docStatusInput').on('change', function() {
        updateVerifiedButtonState();
    });
});

$(document).on('click', '#viewDocButton, #viewSupportingDocButton, #viewPrivateHireLicenseButton, #viewMOTTestButton, #viewOperatorContractButton', function() {
    // Show the modal
    $('#docViewModal').modal('show');
});