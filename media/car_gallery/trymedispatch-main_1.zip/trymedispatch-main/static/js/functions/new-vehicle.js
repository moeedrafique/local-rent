
    /*
    CODE TO GET VEHICLE TYPES AS ATTRIBUTES
    */

    function loadAttributes() {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: '/get_attributes/',
                type: 'GET',
                dataType: 'json',
                success: function(data){
                    var container = $(".attributes-container");
                    data.forEach(function(field){
                        container.append(`
                            <div class="col-sm-6">
                                <label>${field}</label>
                                <select class="form-control mb-3" name="${field.replace(/ /g, "_").toLowerCase()}" id="input${field.replace(/ /g, "").replace(/\./g, "-")}">
                                    <option value="no" selected>no</option>
                                    <option value="yes">yes</option>
                                </select>
                            </div>
                        `);
                    });
                    resolve();
                },
                error: function(error) {
                    reject(error);
                }
            });
        })
    }


    
    // Populating Year Options for Registration Year
    let currentYear = new Date().getFullYear();
    let startYear = 1980;

    for (let i = currentYear; i >= startYear; i--) {
        $('#registrationYear').append(`<option value="${i}">${i}</option>`);
    }


    
    // Save data on "Save" button click for Vehicle form
    $(document).on('click', 'input[name="update-vehicle"]', function(e) {
        e.preventDefault();
        var formData = getVehicleFormData($('.vehicle-edit-form'));
        formData['vehicleId'] = vehicleId;
        console.log('formData: ', formData)

        $.ajax({
            url: '/vehicles/update-vehicle-details/',  // change this to your actual endpoint for vehicle update
            type: 'POST',
            data: JSON.stringify(formData),
            dataType: 'json',
            headers: {
                'X-CSRFToken': csrftoken
            },
            success: function (response) {
                var statusDiv = $('#updateStatus');
                
                if (response.success) {
                    statusDiv.text('Vehicle details are updated on the database.').css('color', 'grey');
                } else {
                    statusDiv.text('Vehicle details are not updated on the database.').css('color', 'red');
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.error("AJAX error during save operation: " + textStatus + ' : ' + errorThrown);
                $('#updateStatus').text('There was an error saving the vehicle details.').css('color', 'red');
            }
        });
    });

    // Cancel button action
    document.getElementById('cancelButton').addEventListener('click', function() {
        window.location.href = "{% url 'vehicles' %}";
    });