let defaultInputValues = {};
let defaultInputPlaceholders = {};

$(document).ready(function() {
    const form = $('.account-edit-form');
    const inputs = form.find('input');

    inputs.each(function() {
        defaultInputValues[this.id] = this.value;
        defaultInputPlaceholders[this.id] = this.placeholder;
    });
});

$(document).on('input', '#job', function() {
    if (this.value) {
        disableAndEmptyForm();
    } else {
        enableAndRestoreForm();
    }
});

function disableAndEmptyForm() {
    const form = $('.account-edit-form');
    const inputs = form.find('input');
    const selects = form.find('select');

    inputs.each(function() {
        if (this.id !== 'job') {
            this.value = '';
            this.placeholder = '';
            this.disabled = true;
            $(this).addClass('disabled');  // For styling
        }
    });

    selects.each(function() {
        this.value = '';
        this.disabled = true;
        $(this).addClass('disabled');  // For styling
    });
}

function enableAndRestoreForm() {
    const form = $('.account-edit-form');
    const inputs = form.find('input');
    const selects = form.find('select');

    inputs.each(function() {
        this.disabled = false;
        this.value = defaultInputValues[this.id] || '';
        this.placeholder = defaultInputPlaceholders[this.id] || '';
        $(this).removeClass('disabled');  // For styling
    });

    selects.each(function() {
        this.disabled = false;
        $(this).removeClass('disabled');  // For styling
    });
}




$(document).on('click', '#info_btn', function (e) {
    e.preventDefault();
    var user_id = $(this).attr("data-user-id");

    //alert(source + id);
    $.ajax({
      type: "GET",
      url: "includes/user.php",
      data: { user_id: user_id },
      //dataType: "html",   //expect html to be returned                
      success: function (response) {


        $("#profile-data-table").empty();
        $("#profile-data-table").html(response);
        // console.log(response);
      }

    });

  });

  $(document).on('click', '#info_btn_client', function (e) {
    e.preventDefault();
    var client_id = $(this).attr("data-client-id");
    //alert(source + id);
    $.ajax({
      type: "GET",
      url: "includes/client.php",
      data: { client_id: client_id },
      //dataType: "html",   //expect html to be returned                
      success: function (response) {


        $("#client-data-table").empty();
        $("#client-data-table").html(response);
        // console.log(response);
      }

    });

  });


  $(document).on('click', '#info_btn_vendor', function (e) {
    e.preventDefault();
    var vendor_id = $(this).attr("data-vendor-id");
    //alert(source + id);
    $.ajax({
      type: "GET",
      url: "includes/vendor.php",
      data: { vendor_id: vendor_id },
      //dataType: "html",   //expect html to be returned                
      success: function (response) {


        $("#vendor-data-table").empty();
        $("#vendor-data-table").html(response);
        //console.log(response);
      }

    });

  });




  /*----Map events----*/

  $(document).on('click', '#info_btn_staff', function (e) {
    e.preventDefault();
    var staff_id = $(this).attr("data-staff-id");
    //alert(source + id);
    $.ajax({
      type: "GET",
      url: "includes/staff.php",
      data: { staff_id: staff_id },
      //dataType: "html",   //expect html to be returned                
      success: function (response) {


        $("#staff-data-table").empty();
        $("#staff-data-table").html(response);
        //console.log(response);
      }

    });

  });

  /*----Layers toggle script----*/
  $(document).ready(function () {
    //Layer toggle
    $(".layers-toggle-btn").click(function () {
      $(".toggle-layers").slideToggle(100);
    });

    // Radio toggle script
    $(".toggle-layers #terr").click(function () {
      if ($(this).prop("checked", true)) {
        $("#sat").prop("checked", false);
        map.setMapTypeId('terrain');
      }
    });

    //Fire and event when a radio button is selected
    $(".toggle-layers #sat").click(function () {
      if ($(this).prop("checked", true)) {
        $("#terr").prop("checked", false);
        map.setMapTypeId('satellite');
      }
    });

    //Fire and event when a checkbox button is selected



    if ($(this).prop("checked") == true) {
      const trafficLayer = new google.maps.TrafficLayer();
      trafficLayer.setMap(map);
    } else if ($(this).prop("checked") == false) {
      const trafficLayer = new google.maps.TrafficLayer();
      trafficLayer.setMap(null);
    }

  });