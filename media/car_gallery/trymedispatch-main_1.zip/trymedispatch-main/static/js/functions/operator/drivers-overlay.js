$(document).ready(function(){
    $("#driver-vehicle-type").on("click", function(){ // make sure this ID matches your HTML
        // console.log('Dropdown changed');
        let currentDropdown = $(this);  // reference to the dropdown that was changed
        let selectedValue = currentDropdown.val();  // store the current value before making the AJAX call

        // console.log(selectedValue);

        $.ajax({
            url: '/get_attributes/',
            type: 'GET',
            data: {},
            dataType: 'json',
            beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken );
            },
            success: function(response) {
                console.log(response);
                currentDropdown.empty();
                currentDropdown.append("<option value='all'>ALL</option>");
                for(var i = 0; i < response.length; i++){
                    currentDropdown.append("<option value='"+ response[i]+"'>"+response[i]+"</option>");
                }
            currentDropdown.val(selectedValue);  // set the dropdown's value back to the stored value
            },
            error: function(error) {
                console.log(error); // it can be useful to print the error to the console
            }
        });
    });
});


$(document).ready(function(){


    // Function to collect form data
    function getDriverFormData($form) {
        var unindexed_array = $form.serializeArray();
        console.log('Unindexed array:', unindexed_array);

        var indexed_array = {};
        $.map(unindexed_array, function (n, i) {
            indexed_array[n['name']] = n['value'];
        });

        return indexed_array;
    }




    $("#driversView, #driverSearchButton").on("click", function(){ // make sure this ID matches your HTML
        var formData = getDriverFormData($('.vehicle-search-form'));
        // formData['vehicleId'] = vehicleId;
        console.log('formData: ', formData)

        $.ajax({
            url: '/operator/render-driver-with-table/',
            type: 'POST',
             data: JSON.stringify(formData), //{
            // 'refId': refId, 'vehRef': vehRef, 'vehPlate': vehPlate, 'imei': imei,
            // 'site': site, 'drvRef': drvRef, 'drvReg': drvReg, 'addr': addr,
            // 'dest': dest, 'zoneRef': zoneRef, 'acc': acc
            // },
            dataType: 'json',
            beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken );
            },
            success: function(response) {
                // console.log('response1  = ', response);
                // console.log('response2  = ' + JSON.stringify(response));

                var tbody = '';
                for (var i = 0; i < response.driver_data.length; i++) {
                    var row = response.driver_data[i];
                    // console.log('row', i, ': ', row)
                    // console.log(row.reference)
                    tbody += '<tr class="' + (i % 2 === 0 ? 'even' : 'odd') + '">';
                    tbody += '<td id="d_id" data-driverId="' + row.driver_id + '">' + row.driver_id + '</td>';
                    tbody += '<td>' + row.reference + '</td>';
                    tbody += '<td>' + row.name + '</td>';
                    tbody += '<td>' + row.phone + '</td>';
                    tbody += '<td>' + row.last_login + '</td>';
                    tbody += '<td>' + row.last_worked + '</td>';
                    tbody += '<td>' + row.vehicle + '</td>';
                    tbody += '<td>' + row.plate + '</td>';
                    tbody += '<td>' + row.booking_psv + '</td>';
                    tbody += '<td>' + row.registration + '</td>';
                    tbody += '<td>' + row.active + '</td>';
                    tbody += '<td>' + row.device_os + '</td>';
                    tbody += '<td><form class="driver-form" method="post"><input type="hidden" name="driver_id" value="' + row.driver_id + '"><button type="button" class="btn btn-primary load-driver">View</button></form></td>';
                    tbody += '</tr>';
                }
                // console.log(tbody);

                $('#driversTableBody').html(tbody);
            },
            error: function(error) {
                console.log('error: ' + error); // it can be useful to print the error to the console
            }
        });
    });
});


$(document).ready(function() {
    // Set up CSRF token
    var csrftoken = getCookie('csrftoken');  // Assuming you have a getCookie function to fetch the CSRF token

    // Handle form submission
    $(document).on('click', '.driver-form', function(event) {
        event.preventDefault();

        var form = $(this).closest('form');
        var driver_id = $(this).find('input[name="driver_id"]').val();
        console.log('I am here');
        console.log(driver_id);

        requestDriverDetails(driver_id, csrftoken);
    });

    // // If the button inside the form is specifically needed to be targeted
    // $(document).on('click', '.driver-form button', function(event) {
    //     event.preventDefault();

    //     var form = $(this).closest('form');
    //     var driver_id = $(this).find('input[name="driver_id"]').val();
        
    //     console.log(driver_id);

    //     requestDriverDetails(driver_id, csrftoken);
    // });

    // Show driver details
    $(".load-driver").on('click', function(){
        console.log('I am up');
        $("#driversOverlay").slideUp(1500);
        // $(".single-driver").slideDown(500);
    });
});

// AJAX function to request driver details
function requestDriverDetails(driver_id, csrftoken) {
    $.ajax({
        url: 'get-driver-details/',
        type: 'POST',
        data: {
            'driver_id': driver_id
        },
        dataType: 'json',
        beforeSend: function(xhr, settings) {
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
        },
        success: function(response) {
            console.log(response);
            driverDetailModel(response);
        },
        error: function(xhr, errmsg, err) {
            console.log('error');
        }
    });
}

// Assuming you might have a getCookie function for fetching the CSRF token. If not, consider adding:
function getCookie(name) {
    var value = "; " + document.cookie;
    var parts = value.split("; " + name + "=");
    if (parts.length == 2) return parts.pop().split(";").shift();
}


let state = {
response: null
};
    
function driverDetailModel(response) {
    state.response = response;
    
    const driverDetail = document.getElementById('driver-in-detail');
    driverDetail.innerHTML = 
    `
    <div class="row">
    
        <h1><span class="btn btn-secondary p-2 flat-right mb-2" id="back-to-drivers">Back</span></h1>
    
        <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="view-tab" data-bs-toggle="tab" data-bs-target="#view"
                type="button" role="tab" aria-controls="view" aria-selected="true" onclick="viewFunction()">View</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity"
                type="button" role="tab" aria-controls="activity" aria-selected="false" onclick="activityFunction()">Activity</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="locations-tab" data-bs-toggle="tab" data-bs-target="#locations" type="button"
                role="tab" aria-controls="locations" aria-selected="false" onclick="locationsFunction()">Locations</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="penalties-tab" data-bs-toggle="tab" data-bs-target="#penalties" type="button"
                role="tab" aria-controls="penalties" aria-selected="false" onclick="penaltiesFunction()">Penalties/Availabilities</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="logs-tab" data-bs-toggle="tab" data-bs-target="#logs" type="button"
                role="tab" aria-controls="logs" aria-selected="false" onclick="logsFunction()">Logs</button>
        </li>
        </ul>

    <div class="col-sm-12">
        <h1 class="mb-2 mt-2 clearfix"> ${response.driver_detail.reference}: ${response.driver_detail.first_name}  ${response.driver_detail.last_name} </h1>

        <form class="account-edit-form edit-address-form booking-form" method="POST" action="">

            <div class="row">
            <div class="col-sm-6">
                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="">
                                <label>NAME</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.first_name}  ${response.driver_detail.last_name} " id="name">
                            </div>
                            <div class="">
                                <label>PHONE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.phone} " id="phone">
                            </div>
                            <div class="">
                                <label>MOBILE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.mobile} " id="mobile">
                            </div>
                            <div class="">
                                <label>OTHER PHONE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.other_phone} " id="other_phone">
                            </div>
                            <div class="">
                                <label>BADGE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.badge} " id="badge">
                            </div>
                            <div class="">
                                <label>LOGIN</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.status} " id="login">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="">
                                <label>AKA</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.aka} " id="aka">
                            </div>
                            <div class="">
                                <label>VEHICLE</label>--
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.vehicle} " id="vehicle">
                            </div>
                            <div class="">
                                <label>PLATE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.plate} " id="plate">
                            </div>
                            <div class="">
                                <label>REGISTRATION</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.registration} " id="registration">
                            </div>
                            <div class="">
                                <label>ACCOUNT STATUS</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.account_status} " id="account_status">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </form>
    </div>
    </div>
    `;
}


function viewFunction() {
    // code for the "Activity" tab goe
    let state = {
        response: null
    };
    
    function driverDetailModel(response) {
        state.response = response;
    
        const driverDetail = document.getElementById('driver-in-detail');
        driverDetail.innerHTML = 
        `
        <div class="row">
    
        <h1><span class="btn btn-secondary p-2 flat-right mb-2" id="back-to-drivers">Back</span></h1>
    
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="view-tab" data-bs-toggle="tab" data-bs-target="#view"
                    type="button" role="tab" aria-controls="view" aria-selected="true" onclick="viewFunction()">View</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity"
                    type="button" role="tab" aria-controls="activity" aria-selected="false" onclick="activityFunction()">Activity</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="locations-tab" data-bs-toggle="tab" data-bs-target="#locations" type="button"
                    role="tab" aria-controls="locations" aria-selected="false" onclick="locationsFunction()">Locations</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="penalties-tab" data-bs-toggle="tab" data-bs-target="#penalties" type="button"
                    role="tab" aria-controls="penalties" aria-selected="false" onclick="penaltiesFunction()">Penalties/Availabilities</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="logs-tab" data-bs-toggle="tab" data-bs-target="#logs" type="button"
                    role="tab" aria-controls="logs" aria-selected="false" onclick="logsFunction()">Logs</button>
            </li>
        </ul>

        <div class="col-sm-12">
            <h1 class="mb-2 mt-2 clearfix"> ${response.driver_detail.reference}: ${response.driver_detail.first_name}  ${response.driver_detail.last_name} </h1>

            <form class="account-edit-form edit-address-form booking-form" method="POST" action="">

            <div class="row">
                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="">
                                    <label>NAME</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.first_name}  ${response.driver_detail.last_name} " id="name">
                                </div>
                                <div class="">
                                    <label>PHONE</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.phone} " id="phone">
                                </div>
                                <div class="">
                                    <label>MOBILE</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.mobile} " id="mobile">
                                </div>
                                <div class="">
                                    <label>OTHER PHONE</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.other_phone} " id="other_phone">
                                </div>
                                <div class="">
                                    <label>BADGE</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.badge} " id="badge">
                                </div>
                                <div class="">
                                    <label>LOGIN</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.status} " id="login">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="">
                                    <label>AKA</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.aka} " id="aka">
                                </div>
                                <div class="">
                                    <label>VEHICLE</label>--
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.vehicle} " id="vehicle">
                                </div>
                                <div class="">
                                    <label>PLATE</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.plate} " id="plate">
                                </div>
                                <div class="">
                                    <label>REGISTRATION</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.registration} " id="registration">
                                </div>
                                <div class="">
                                    <label>ACCOUNT STATUS</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.account_status} " id="account_status">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
    `;
    };

    const driverDetail = document.getElementById('driver-in-detail');

    let response = state.response; // Get the response from the state

    driverDetail.innerHTML = 
    `
    <div class="row">
    
        <h1><span class="btn btn-secondary p-2 flat-right mb-2" id="back-to-drivers">Back</span></h1>
    
        <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="view-tab" data-bs-toggle="tab" data-bs-target="#view"
                type="button" role="tab" aria-controls="view" aria-selected="true" onclick="viewFunction()">View</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity"
                type="button" role="tab" aria-controls="activity" aria-selected="false" onclick="activityFunction()">Activity</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="locations-tab" data-bs-toggle="tab" data-bs-target="#locations" type="button"
                role="tab" aria-controls="locations" aria-selected="false" onclick="locationsFunction()">Locations</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="penalties-tab" data-bs-toggle="tab" data-bs-target="#penalties" type="button"
                role="tab" aria-controls="penalties" aria-selected="false" onclick="penaltiesFunction()">Penalties/Availabilities</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="logs-tab" data-bs-toggle="tab" data-bs-target="#logs" type="button"
                role="tab" aria-controls="logs" aria-selected="false" onclick="logsFunction()">Logs</button>
        </li>
        </ul>

    <div class="col-sm-12">
        <h1 class="mb-2 mt-2 clearfix"> ${response.driver_detail.reference}: ${response.driver_detail.first_name}  ${response.driver_detail.last_name} </h1>

        <form class="account-edit-form edit-address-form booking-form" method="POST" action="">

            <div class="row">
            <div class="col-sm-6">
                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="">
                                <label>NAME</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.first_name}  ${response.driver_detail.last_name} " id="name">
                            </div>
                            <div class="">
                                <label>PHONE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.phone} " id="phone">
                            </div>
                            <div class="">
                                <label>MOBILE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.mobile} " id="mobile">
                            </div>
                            <div class="">
                                <label>OTHER PHONE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.other_phone} " id="other_phone">
                            </div>
                            <div class="">
                                <label>BADGE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.badge} " id="badge">
                            </div>
                            <div class="">
                                <label>LOGIN</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.status} " id="login">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="">
                                <label>AKA</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.aka} " id="aka">
                            </div>
                            <div class="">
                                <label>VEHICLE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.vehicle} " id="vehicle">
                            </div>
                            <div class="">
                                <label>PLATE</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.plate} " id="plate">
                            </div>
                            <div class="">
                                <label>REGISTRATION</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.registration} " id="registration">
                            </div>
                            <div class="">
                                <label>ACCOUNT STATUS</label>
                                <input type="text" readonly class="form-control mb-3" placeholder=" ${response.driver_detail.account_status} " id="account_status">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </form>
    </div>
    </div>
    `;

    document.getElementById('view-tab').classList.add('active');
    document.getElementById('activity-tab').classList.remove('active');
    document.getElementById('locations-tab').classList.remove('active');
    document.getElementById('penalties-tab').classList.remove('active');
    document.getElementById('logs-tab').classList.remove('active');
}

function activityFunction() {
    // code for the "Activity" tab goes here
    console.log('Activity tab clicked');
    const driverDetail = document.getElementById('driver-in-detail');

    let response = state.response; // Get the response from the state

    driverDetail.innerHTML = `

    <div class="row">
    
        <h1><span class="btn btn-secondary p-2 flat-right mb-2" id="back-to-drivers">Back</span></h1>
    
        <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="view-tab" data-bs-toggle="tab" data-bs-target="#view"
                type="button" role="tab" aria-controls="view" aria-selected="true" onclick="viewFunction()">View</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity"
                type="button" role="tab" aria-controls="activity" aria-selected="false" onclick="activityFunction()">Activity</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="locations-tab" data-bs-toggle="tab" data-bs-target="#locations" type="button"
                role="tab" aria-controls="locations" aria-selected="false" onclick="locationsFunction()">Locations</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="penalties-tab" data-bs-toggle="tab" data-bs-target="#penalties" type="button"
                role="tab" aria-controls="penalties" aria-selected="false" onclick="penaltiesFunction()">Penalties/Availabilities</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="logs-tab" data-bs-toggle="tab" data-bs-target="#logs" type="button"
                role="tab" aria-controls="logs" aria-selected="false" onclick="logsFunction()">Logs</button>
        </li>
        </ul>

    <div class="col-sm-12">
            <h1 class="mb-2 mt-2 clearfix"> ${response.driver_detail.reference}: ${response.driver_detail.first_name}  ${response.driver_detail.last_name} </h1>

            <form class="account-edit-form edit-address-form booking-form" method="POST" action="">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="card pl-3 pr-3 bg-light mb-3">
                            <div class="row">
                                <div class="col-sm-6"> <!-- First Column -->
                                    <div class="">
                                        <label>REFERENCE</label>
                                        <input type="text" readonly class="form-control mb-3" placeholder="${response.driver_detail.reference}" id="reference">
                                    </div>
                                    <div class="">
                                        <label>FIRST NAME</label>
                                        <input type="text" readonly class="form-control mb-3" placeholder="${response.driver_detail.first_name}" id="first_name">
                                    </div>
                                    <div class="">
                                        <label>LAST NAME</label>
                                        <input type="text" readonly class="form-control mb-3" placeholder="${response.driver_detail.last_name}" id="last_name">
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                        <div class="card pl-3 pr-3 bg-light mb-3">
                            <div class="row">
                                <div class="col-sm-6"> <!-- Second Column -->
                                    <div class="">
                                        <label>VEHICLE</label>
                                        <input type="text" readonly class="form-control mb-3" placeholder="${response.driver_detail.vehicle}" id="vehicle">
                                    </div>
                                    <div class="">
                                        <label>PSV</label>
                                        <input type="text" readonly class="form-control mb-3" placeholder="${response.driver_detail.psv}" id="psv">
                                    </div>
                                    <div class="">
                                        <label>PHONE</label>
                                        <input type="text" readonly class="form-control mb-3" placeholder="${response.driver_detail.phone}" id="phone">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    `

    document.getElementById('view-tab').classList.remove('active');
    document.getElementById('activity-tab').classList.add('active');
    document.getElementById('locations-tab').classList.remove('active');
    document.getElementById('penalties-tab').classList.remove('active');
    document.getElementById('logs-tab').classList.remove('active');

    // Your code to generate the table
    let table = generateTable();

    // Append the table at the end
    driverDetail.innerHTML += table;
}

function generateTable() {
    let today = new Date();
    let table = '<div class="table-scrollable"><table class="table table-striped table-bordered">';
    table += '<thead><tr><th style="width: 50rem">WEEK START</th><th style="width: 50rem">WEEK END</th><th style="width: 50rem">ESTIMATE</th></tr></thead>';
    table += '<tbody>';
    
    let now = new Date();
    let dayOfWeek = now.getDay(); // 0-6, 0 is Sunday, 6 is Saturday
    let numDay = dayOfWeek || 7; // Convert Sunday from 0 to 7

    let startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - numDay + 1); // previous Monday or current Monday
    startOfWeek.setHours(0, 0, 0, 0); // Set time to 00:00:00

    for (let i = 0; i < 52; i++) { // Generate 52 rows for one year
        let startStr = startOfWeek.toLocaleDateString() + ' ' + startOfWeek.toLocaleTimeString();
        let endStr = "";

        if(i == 0) { // for the first row, use the current date and time
            endStr = now.toLocaleDateString() + ' ' + now.toLocaleTimeString();
        } else { // for the rest, use the end of the week
            let endOfWeek = new Date(startOfWeek);
            endOfWeek.setDate(endOfWeek.getDate() + 6); // next Sunday
            endOfWeek.setHours(23, 59, 59, 999); // Set time to 11:59:59
            endStr = endOfWeek.toLocaleDateString() + ' ' + endOfWeek.toLocaleTimeString();
        }

        table += `<tr><td>${startStr}</td><td>${endStr}</td><td>£60</td></tr>`;
        
        // Subtract 1 week from start and end
        startOfWeek.setDate(startOfWeek.getDate() - 7);
    }
    
    table += '</tbody></table></div>';

    return table;
}


function locationsFunction() {
    // code for the "Locations" tab goes here
    console.log('Locations tab clicked');
}

function penaltiesFunction() {
    // code for the "Penalties/Availabilities" tab goes here
    console.log('Penalties/Availabilities tab clicked');
}

function logsFunction() {
    // code for the "Logs" tab goes here
    console.log('Logs tab clicked');
}


$(document).on('click', '#view-tab', function() {
    viewFunction();
});

$(document).on('click', '#activity-tab', function() {
    activityFunction();
});

$(document).on('click', '#locations-tab', function() {
    locationsFunction();
});

$(document).on('click', '#penalties-tab', function() {
    penaltiesFunction();
});

$(document).on('click', '#logs-tab', function() {
    logsFunction();
});

