


// Fetch the Firebase configuration from a server-side endpoint
$(document).ready(function() {
// Fetch the Firebase configuration from a server-side endpoint
$.ajax({
    url: 'get_firebase_config/',  // Replace with your server-side endpoint URL
    type: 'GET',
    success: function(response) {
    // Use the fetched Firebase configuration in your client-side code
    var firebaseConfig = response.firebaseConfig;

    // Initialize Firebase with the fetched configuration
    firebase.initializeApp(firebaseConfig);

    // Perform sign-out on button click
    $(".signout").click(function() {
        firebase.auth().signOut().then(function() {
        // Sign-out successful.
        window.location.href = "/"; // Redirect to homepage or login page.
        }).catch(function(error) {
        // An error happened.
        console.log(error);
        });
    });

    // Now you can use Firebase authentication with the initialized app
    // and handle sign-out functionality as described above.
    },
    error: function(xhr, status, error) {
    console.log(error);
    }
});
});

$(window).on('load', function () {
    feather.replace();
});


function display_ct5() {
    var x = new Date()
    var ampm = x.getHours() >= 12 ? ' PM' : ' AM';

    var x1 = x.getMonth() + 1 + "-" + x.getDate() + "-" + x.getFullYear();
    x1 = x1 + " - " + x.getHours() + ":" + x.getMinutes() + ":" + x.getSeconds();
    document.getElementById('live-time-date').innerHTML = x1;
    display_c5();
}

function display_c5() {
var refresh = 1000; // Refresh rate in milli seconds
mytime = setTimeout('display_ct5()', refresh)
}

display_c5();
