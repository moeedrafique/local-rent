$(document).ready(function(){
    $("#source-sites, #job-sites, #driver-job-sites").on("click", function(){ // make sure this ID matches your HTML
        // console.log('Dropdown changed');
        let currentDropdown = $(this);  // reference to the dropdown that was changed
        let selectedValue = currentDropdown.val();  // store the current value before making the AJAX call

        // console.log(selectedValue);

        $.ajax({
            url: '/operator/search-bookings/',
            type: 'POST',
            data: {
                'type': 'sites',
            },
            dataType: 'json',
            beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken );
            },
            success: function(response) {
                console.log(response.sites);
                currentDropdown.empty();
                //$('#source-sites').append("<option value='"+ response.sites[0]+"'>"+response.sites[0]+"</option>");
                currentDropdown.append("<option value='all_sites'>ALL SITES (NO FILTER)</option>");
                for(var i = 0; i < response.sites.length; i++){
                    currentDropdown.append("<option value='"+ response.sites[i]+"'>"+response.sites[i]+"</option>");
                }
            currentDropdown.val(selectedValue);  // set the dropdown's value back to the stored value
            },
            error: function(error) {
                console.log(error); // it can be useful to print the error to the console
            }
        });
    });
});

$(document).ready(function(){
    $("#search-booking-operator").on("click", function(){ // make sure this ID matches your HTML
        // console.log('Dropdown changed');
        let selectedValue = $(this).val();
        // console.log(selectedValue);

        $.ajax({
            url: '/operator/search-bookings/',
            type: 'POST',
            data: {
                'type': 'operator',
            },
            dataType: 'json',
            beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken );
            },
            success: function(response) {
                console.log(response.operator);
                $('#search-booking-operator').empty();
                //$('#source-sites').append("<option value='"+ response.sites[0]+"'>"+response.sites[0]+"</option>");
                $('#search-booking-operator').append("<option value='all_staffs'>ALL OPERATORS</option>");
                for(var i = 0; i < response.operator.length; i++){
                    $('#search-booking-operator').append("<option value='"+ response.operator[i]+"'>"+response.operator[i]+"</option>");
                }
            },
            error: function(error) {
                console.log(error); // it can be useful to print the error to the console
            }
        });
    });
});
    
$(document).ready(function(){
    $("#loadBookings").on("click", function(event){
    var currentDate = new Date();
    $("#fromDate, #toDate").datepicker({
        changeMonth: true,
        dateFormat: 'dd/mm/yy'
    });
    // format date with leading zero for day and month less than 10
    var day = ("0" + currentDate.getDate()).slice(-2);
    var month = ("0" + (currentDate.getMonth() + 1)).slice(-2); 
    var today = day + "/" + month + "/" + currentDate.getFullYear();
    
    // Manually update the input field
    $('#fromDate, #toDate').val(today);

    // get the select elements
    var selectTo = $('#toTimeDropdown');
    var selectFrom = $('#fromTimeDropdown');

    // start at 0 minutes
    var time = 0;

    // increment every 15 minutes
    var increment = 15;

    // for every quarter of an hour in the day
    for(var i = 0; i < 24 * 60 / increment; i++) {
        // calculate the current time
        var hour = Math.floor(time / 60);
        var minutes = time % 60;

        // pad with '0' if needed
        hour = hour < 10 ? '0' + hour : hour;
        minutes = minutes < 10 ? '0' + minutes : minutes;

        // create an option with the current time
        var option = new Option(hour + ':' + minutes, hour + ':' + minutes);
        
        // add the option to the select elements
        selectTo.append(option);
        selectFrom.append(option.cloneNode(true)); // clone the option node for the fromTimeDropdown

        // increment the time
        time += increment;
    }

    // Set value of 'fromTimeDropdown' select to '00:00'
    selectFrom.val('00:00');

    // Get current time
    var now = new Date();
    var hours = now.getHours();
    var minutes = now.getMinutes();

    // round minutes to the nearest 15 (up or down)
    minutes = Math.round(minutes / 15) * 15;

    // pad with '0' if needed
    hours = hours < 10 ? '0' + hours : hours;
    minutes = minutes < 10 ? '0' + minutes : minutes;

    var currentTime = hours + ':' + minutes;

    // Set value of 'toTimeDropdown' select to current time
    setTimeout(function() {
        $('#toTimeDropdown').val(currentTime);
    }, 100); // Adjust this delay as needed

    $('#toTimeDropdown').val(currentTime);
    });

    $("#loadBookings, #bookingSearchButton").on("click", function(){ // make sure this ID matches your HTML
        // console.log('Dropdown changed');
        let selectedValue = $(this).val();
        // console.log(selectedValue);
        var form = $(this).closest('form');
        var fromDate = $('#fromDate').val(), fromTime = $('#fromTimeDropdown').val();
        var toDate = $('#toDate').val(), toTime = $('#toTimeDropdown').val();
        var job = $('#job').val(), jobSites = $('#job-sites').val();
        var source = $('#source').val(), sourceSites = $('#source-sites').val();
        var drvRef = $('#drv-ref').val(), drvReg = $('#drv-vehicle').val(), addr = $('#addr').val();
        var dest = $('#dest').val(), zoneRef = $('#zone-ref').val(), acc = $('#acc').val();
        var operator = $('#operator').val(), custName = $('#cust-name').val(), custPh = $('#cust-ph').val();
        var creditCardAcc = $('#credit-card-acc').val(), status = $('#status').val();

        console.log(fromDate, fromTime, toDate, toTime, job, jobSites, addr)

        $.ajax({
            url: '/operator/render-booking-with-table/',
            type: 'POST',
            data: {
            'fromDate': fromDate, 'fromTime': fromTime, 'toDate': toDate, 'toTime': toTime,
            'job': job, 'jobSites': jobSites, 'source': source, 'sourceSites': sourceSites,
            'drvRef': drvRef, 'drvReg': drvReg, 'addr': addr, 'dest': dest, 'zoneRef': zoneRef, 'acc': acc,              
            'operator': operator, 'custName': custName, 'custPh': custPh, 'creditCardAcc': creditCardAcc, 'status': status,
            },
            dataType: 'json',
            beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken );
            },
            success: function(response) {
                console.log('response: ', response)
                var tbody = '';
                for (var i = 0; i < response.booking_data.length; i++) {
                    var row = response.booking_data[i];
                    tbody += '<tr class="' + (i % 2 === 0 ? 'even' : 'odd') + '">';
                    tbody += '<td id="b_id" data-bookingId="' + row.booking_id + '">' + row.booking_id + '</td>';
                    tbody += '<td>' + row.book_time + '</td>';
                    tbody += '<td>' + row.status + '</td>';
                    tbody += '<td>' + row.pickup + '</td>'; // nothing coming
                    tbody += '<td>' + row.destination + '</td>';
                    tbody += '<td>' + row.drv + '</td>';
                    tbody += '<td>' + row.vehicle_reg + '</td>';
                    // tbody += '<td>' + row.customer_name + '</td>';
                    tbody += '<td>' + row.customer_name + '</td>';
                    tbody += '<td>' + row.phone + '</td>';
                    tbody += '<td>' + row.driver_declines + '</td>';
                    tbody += '<td>' + row.account + '</td>';
                    tbody += '<td>' + row.pay + '</td>';
                    tbody += '<td>' + row.fare + '</td>';
                    tbody += '<td>' + row.receipt + '</td>';
                    tbody += '<td><form class="log-form" method="post"><input type="hidden" name="booking_id" value=" ' + row.booking_id + ' "><button type="button" class="btn btn-primary load-booking">Logs</button></form></td>';
                    tbody += '<td><form class="booking-form" method="post"><input type="hidden" name="booking_id" value=" ' + row.booking_id + ' "><button type="button" class="btn btn-primary load-booking">View</button></form></td>';
                    tbody += '</tr>';
                }
                $('#bookingsTableBody').html(tbody);
            },
            error: function(error) {
                console.log(error); // it can be useful to print the error to the console
            }
        });
    });
});
  

console.log("jQuery version: " + $.fn.jquery);
console.log("jQuery UI version: " + $.ui.version);

  
// Inside of this function, $ will always refer to jQuery
$(document).ready(function() {

    $("#dispatchView").click(function(){
        console.log("Dispatch View clicked");
        $("#bookingsOverlay").slideUp(500);
        $("#driversOverlay").slideUp(500);
    });
});

$("#loadBookings").click(function(){
    $('#bookingsOverlay').slideDown(500);
    $('#driversOverlay').slideUp(500);

});

$("#dispatchView").click(function(e){
    e.preventDefault();
    $("#driversOverlay").slideUp(500);
    $("#bookingsOverlay").slideUp(500);
    $(".single-booking").slideUp(500);
});


$(document).on('click','#b_id', function(){
    console.log($(this).attr("data-bookingId"));
});

$(document).on('click','#d_id', function(){
    console.log($(this).attr("data-driverId"));
});

$(document).on('click', 'form.booking-form button', function(event) {
    // $('.booking-form').on('click', function(event) {
        event.preventDefault();  // Prevent the form from being submitted normally

        // Get the booking_id from the form
        var form = $(this).closest('form');
        // var booking_id = $(this).find('input[name="booking_id"]').val();
        var booking_id = form.find('input[name="booking_id"]').val();
        console.log(booking_id);

        // Perform the AJAX request
        $.ajax({
            url: 'get-booking-details/', // '{% url 'get-booking-details' %}',
            type: 'POST',
            data: {
                'booking_id': booking_id
            },
            dataType: 'json',
            beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken );
            },

            success: function(response) {
            console.log(response);
            bookingDetailModel(response);
            // initBookingMap(response);
                // Handle the response data
                // Update the DOM or perform any other actions
            },
            error: function(xhr, errmsg, err) {
            console.log('error');
                // Handle any error that occurred during the AJAX request
            }
        });

        // This allows to view the booking details by sliding the div
        console.log("Load booking clicked");
        $("#bookingsTable_wrapper").slideUp(500);
        $(".single-booking").slideDown(500);
    //});
});

$(document).on('click', 'form.log-form button', function(event) {
    // $('.booking-form').on('click', function(event) {
        event.preventDefault();  // Prevent the form from being submitted normally

        var form = $(this).closest('form');
        var booking_id = form.find('input[name="booking_id"]').val();
        console.log(booking_id);

        // Perform the AJAX request
        $.ajax({
            url: 'get-log-details/', // '{% url 'get-booking-details' %}',
            type: 'POST',
            data: {
                'booking_id': booking_id
            },
            dataType: 'json',
            beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken );
            },

            success: function(response) {
                console.log(response);
                logDetailModel(response);
                // initBookingMap(response);
                // Handle the response data
                // Update the DOM or perform any other actions
            },
            error: function(xhr, errmsg, err) {
                console.log('error');
                // Handle any error that occurred during the AJAX request
            }
        });

        // This allows to view the log details by sliding the div
        console.log("Load Log clicked");
        $("#bookingsTable_wrapper").slideUp(500);
        $(".single-booking").slideDown(500);
    //});
});
    
  
function attachShowChatDataHandler() {
    $('.show-chat-data').off('submit'); // Remove any existing handlers to avoid duplicates

    $(document).on('submit', '.show-chat-data', function(event) {
        console.log("Button clicked!");
        event.preventDefault();
        // the rest of your event handler code...
    });
}


function bookingDetailModel(response) {
    const bookingDetail = document.getElementById('booking-in-detail');
    bookingDetail.className += " scrollable-div";
    bookingDetail.innerHTML = `
    <div class="row">
        <h1><span class="btn btn-secondary p-2 flat-right mb-2" id="back-to-bookings">Back</span></h1>
        <div class="col-sm-12">
            <h1 class="mb-2 mt-2 clearfix"> ${response.booking_detail.status}</h1>

            <form class="account-edit-form edit-address-form bookings-form" method="POST" action="">

            <div class="row">
                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-3">

                                <div class=""><label>JOB#</label>
                                    <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.booking_id} " id="job">
                                </div>
                            </div>

                            <div class="col-sm-3">

                                <div class=""><label>OPERATOR</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.operator} " id="operator"></div>

                            </div>

                            <div class="col-sm-3">

                            
                                <div class=""><label>CREATED</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.created} " id="created"></div>
                            </div>

                            <div class="col-sm-3">
                                <div class=""><label>PICKUP</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.pickup} " id="pickup"></div>
                                
                            </div>
                            <div class="col-sm-2">
                                
                                <div class=""><label>STATUS</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.status} " id="status"></div>
                            </div>
                        </div>
                    </div><!--row ends here-->
                </div><!--col-sm-6 ends here-->

                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-2">
                                <div class=""><label>DRV</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.driver_name} " id="drv"></div>
                                
                            </div>
                            <div class="col-sm-3">
                                
                                <div class=""><label>DRV PH</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.driver_contact} " id="drv_ph"></div>
                                
                            </div>
                            <div class="col-sm-3">
                                
                                
                                <div class=""><label>VEH</label><input type="text" readonly class="form-control mb-3"
                                        placeholder=" ${response.booking_detail.vehicle} " id="veh"></div>
                            </div>
                            <div class="col-sm-2">
                                <div class=""><label>DET</label><input type="text" readonly class="form-control mb-3"
                                        placeholder=" ${response.booking_detail.det} " id="det"></div>
                            </div>
                            <div class="col-sm-2">
                        
                                <div class=""><label>REG</label><input type="text" readonly class="form-control mb-3"
                                        placeholder=" ${response.booking_detail.registration_plate} " id="reg"></div>
                            </div>
                        </div>
                    </div>

                </div><!--col-sm-6 ends here-->
            </div><!--row ends here-->

            <hr>
            <div class="row">
                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class=""><label>STRT#</label>
                                    <textarea type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.start} " id="strt"></textarea>
                                </div>

                            </div>
                            <div class="col-sm-5">
                                <div class=""><label>DEST</label>
                                    <textarea type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.destination} " id="dest"></textarea></div>
                            </div>
                            <div class="col-sm-2">
                                <form class="text-end mt-3" method="post">
                                
                                <input type="hidden" name="booking_id" value="${response.booking_detail.booking_id}">
                                <button type="button" id="show-live-chat" class="btn btn-primary mt-3 p-2 show-chat-data">MESSAGES</button>
                                </form>
                            </div>
                        </div><!--row ends here-->
                    </div>
                </div><!--col-sm-6 ends here-->

                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class=""><label>CUST PHONE</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.customer_phone} " id="cust_phone"></div>
                            </div>
                            <div class="col-sm-6">
                                <div class=""><label>SEATS</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.seats} " id="seats"></div>
                            </div>
                        </div>
                    </div>

                </div><!--col-sm-6 ends here-->
            </div>

            <div class="row">
                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-3">
                                <div class=""><label>SOURCE</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.source} " id="source">
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class=""><label>DIST</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.distance} " id="dist"></div>
                            </div>
                            <div class="col-sm-3">
                                <div class=""><label>EXTRAS</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.extras} " id="extras">
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class=""><label>TIP</label><input type="text" readonly class="form-control mb-3"
                                        placeholder=" ${response.booking_detail.tip} " id="tip"></div>
                            </div>
                        </div><!--row ends here-->
                    </div>
                </div><!--col-sm-6 ends here-->

                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-3">
                                <div class=""><label>ACCOUNT</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.account} " id="account"></div>
                            </div>
                            <div class="col-sm-3">
                                <div class=""><label>PAYMENT</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.payment} " id="payment"></div>
                            </div>
                            <div class="col-sm-3">
                                <div class=""><label>TOLLS</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.tolls} " id="tolls"></div>
                            </div>
                            <div class="col-sm-3">
                                <div class=""><label>WAITING MINS</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.waiting_mins} " id="waiting_mins"></div>
                            </div>
                        </div>
                    </div>

                </div><!--col-sm-6 ends here-->
            </div>

            <div class="row">
                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class=""><label>COST</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.cost} " id="cost">
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class=""><label>DISCOUNT</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.discount_cost} " id="dsicount"></div>
                            </div>
                            <div class="col-sm-4">
                                <div class=""><label>WAITING COST</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.waiting_cost} " id="waiting_cost"></div>
                            </div>
                        </div><!--row ends here-->
                    </div>
                </div><!--col-sm-6 ends here-->

                <div class="col-sm-6">
                    <div class="card pl-3 pr-3 bg-light mb-3">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class=""><label>PRICE</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.price} " id="cost">
                                </div>
                                
                            </div>
                            <div class="col-sm-4">
                                <div class=""><label>DISCOUNT</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.discount_price} " id="dsicount"></div>
                            </div>
                            <div class="col-sm-4">
                                <div class=""><label>WAITING COST</label><input type="text" readonly
                                        class="form-control mb-3" placeholder=" ${response.booking_detail.waiting_cost_price} " id="waiting_cost"></div>
                            </div>
                        </div>
                    </div>

                </div><!--col-sm-6 ends here-->
            </div>
            
            <!--<div class="row">
                <div class="col-sm-3">
                    <button type="button" name="clear" class="btn btn-secondary">Clear</button>
                </div>
                <div class="col-sm-6"></div>
                <div class="col-sm-3">
                    <button type="submit" name="add-address" class="btn btn-primary">Save</button>
                </div>

            </div>row ends here-->
            </form>

            <!-- Google Map will appear here -->
            <!-- <div id="booking-map"></div> -->
        </div>
    </div>
    `;

    bookingDetail.innerHTML += '<div id="booking-map" style="height: 1000px;"></div>';
    bookingDetail.innerHTML += '<button class="btn btn-primary">LOGS</button>';

    initBookingMap(response)
}

function initBookingMap(response) {

    
    if (!response.booking_detail || !Array.isArray(response.booking_detail.geopoints)) {
        console.error('Invalid response:', response);
        return;
    }

    let geopoints = response.booking_detail.geopoints;
    console.log(geopoints);

    var polylineCoordinates = geopoints;
    

    // Replace this with the coordinates of your first and last point
    var startLatLng = new google.maps.LatLng(polylineCoordinates[0]);
    var endLatLng = new google.maps.LatLng(polylineCoordinates[polylineCoordinates.length - 1]);
    var map = new google.maps.Map(document.getElementById('booking-map'), {
      zoom: 11,
      center: startLatLng,
      streetViewControl: false,
      mapTypeControlOptions: {
        mapTypeIds: [google.maps.MapTypeId.ROADMAP, google.maps.MapTypeId.HYBRID]
      },
      mapTypeControl: false,
      scrollwheel: true,
      scaleControl: false,
      zoomControl: true,
      zoomControlOptions: {
        style: google.maps.ZoomControlStyle.LARGE 
      },
      mapTypeId: google.maps.MapTypeId.TERRAIN,
    });

    var polyline = new google.maps.Polyline({
        path: polylineCoordinates,
        geodesic: true,
        strokeColor: '#FF0000',
        strokeOpacity: 1.0,
        strokeWeight: 2
    });

    polyline.setMap(map);

    // Create info windows for the start and end markers
    var startInfoWindow = new google.maps.InfoWindow({
      content: "<div style='color: black; background: white; padding: 5px; display: inline-block;'>START</div>"
    });

    var endInfoWindow = new google.maps.InfoWindow({
      content: "<div style='color: black; background: white; padding: 5px; display: inline-block;'>END</div>"
    });

    // Add the start marker
    var startMarker = new google.maps.Marker({
        position: startLatLng,
        icon: { // Set your icon here
            url: "{% static 'img/home.svg' %}",
            scaledSize: new google.maps.Size(50, 50) // sizes are in pixels
        },
        map: map
    });

    // Add the end marker
    var endMarker = new google.maps.Marker({
        position: endLatLng,
        icon: { // Set your icon here
            url: "{% static 'img/star.svg' %}",
            scaledSize: new google.maps.Size(50, 50) // sizes are in pixels
        },
        map: map
    });

    // Add a listener to open the info window when the markers are clicked
    startMarker.addListener("mouseover", function() {
      startInfoWindow.open(map, startMarker);
    });

    endMarker.addListener("mouseover", function() {
      endInfoWindow.open(map, endMarker);
    });

    // Add a listener to close the info window when the mouse leaves the markers
    startMarker.addListener("mouseout", function() {
      startInfoWindow.close();
    });

    endMarker.addListener("mouseout", function() {
      endInfoWindow.close();
    });

    // Add a small round black circle with no fill at each lat/lng on the polyline
    polylineCoordinates.forEach(function(coordinate) {
        new google.maps.Circle({
            strokeColor: '#000000',
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: '#FFFFFF',
            fillOpacity: 0,
            map,
            center: coordinate,
            radius: 20 // Adjust the size of the circle here
        });
    });

}

$(document).on('click', '#back-to-bookings', function(){
    $("#bookingsTable_wrapper").slideDown(500);
    $(".single-booking").slideUp(500);
});

$(document).on('click', '#back-to-drivers', function(){
    $("#driversOverlay").slideDown(500);
    $(".single-driver").slideUp(500);
});

function goBackToTables() {
    // Scroll back to the desired position
    console.log('Going back to tables...');
    var parentElement = document.getElementById('bookingsTable_wrapper').parentNode;
    var desiredPosition = parentElement.offsetTop;
    parentElement.scrollTop = desiredPosition;
}

function chatDetailModel(response) {
    const chatDetail = document.getElementById('chat-in-detail');
    let chatHTML = "";

    for (let chat of response.chat_detail) {
        if (chat.message_from === "driver") {
            chatHTML += `
            <div class="mb-2">
                <div class="p-2 bg-info text-white rounded float-left">
                    ${chat.message}
                </div>
                <div class="clearfix"></div>
            </div>
            `;
        } else {
            chatHTML += `
            <div class="mb-2">
                <div class="p-2 bg-success text-white rounded float-right">
                    ${chat.message}
                </div>
                <div class="clearfix"></div>
            </div>
            `;
        }
    }

    chatDetail.innerHTML = `
    <div class="row">
    
    <div class="col-sm-3">
        <h5>Driver</h5>
        <hr>
        <input type="hidden" id="drv_id">
        <ul id="driver-in-chat-info">
            
        </ul>
    </div>
    <div class="col-sm-6">
        <div class="chatbox p-3 bg-light">
            <div class="chatbox-inner clearfix">
                ${chatHTML}
            </div>
            
        </div>
    </div>
    <div class="col-sm-3">
        <h5>Consumer</h5>
        <input type="hidden" id="cust_id">
        <hr>
        <ul id="consumer-in-chat-info">
            
        </ul>
    </div>
    </div>
    <div class="type-here mt-4">
        <div class="row">
            <div class="col-sm-6 offset-sm-3">
                <div class="inner clearfix">
                    <input type="text" name="msg" class="form-control" placeholder="Type your message here">
                    <button type="button" class="btn btn-success p-2 col mt-2">SEND</button>
                </div>
            </div>
        </div>
    </div>
    <button id="back-to-form" class="btn btn-secondary">Back</button>
    `
}
  
$(document).on('click', '.show-chat-data', function(event) {
    // $('.booking-form').on('click', function(event) {
        event.preventDefault();  // Prevent the form from being submitted normally
        event.stopPropagation();
        console.log('Handler called');

        // attachShowChatDataHandler();

        // Get the booking_id from the form
        var form = $(this).closest('form');
        var booking_id = form.find('input[name="booking_id"]').val();
        // var booking_id = $(this).find('input[name="booking_id"]').val();
        console.log(booking_id);

        // Perform the AJAX request
        $.ajax({
            url: 'get-chat-details/', // '{% url 'get-booking-details' %}',
            type: 'POST',
            data: {
                'booking_id': booking_id
            },
            dataType: 'json',
            beforeSend: function(xhr, settings) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken );
            },

            success: function(response) {
                console.log(response);
                chatDetailModel(response);
                // bookingDetailModel(response);
                // Handle the response data
                // Update the DOM or perform any other actions
            },
            error: function(xhr, errmsg, err) {
                console.log('error');
                // Handle any error that occurred during the AJAX request
            }
        });
    //});
});

$(document).on('click', '#show-live-chat', function(){

    $(".live-chat").fadeToggle(200);
    $(".single-booking").slideUp(200);

});

$(document).on('click', '#back-to-form', function(){
    $(".live-chat").slideUp(200);
    $(".single-booking").slideDown(200);
});

function logDetailModel(response) {
    console.log(response);
    const logDetail = document.getElementById('booking-in-detail');
    logDetail.className += " scrollable-div";
    logDetail.innerHTML = `
    <div class="row">
        <h1><span class="btn btn-secondary p-2 flat-right mb-2" id="back-to-bookings">Back</span></h1>
        <div class="col-sm-12">
            <h1 class="mb-2 mt-2 clearfix"> ${response.booking_detail.pickup_location}</h1>

            <form class="account-edit-form edit-address-form bookings-form" method="POST" action="">
            <div class="row">
                <div class="col-sm-12">
                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>JOB#</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.booking_id} " id="job">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>OPERATOR</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.operator} " id="operator">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>CREATED</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.booking_time} " id="created">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>STATUS</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.status} " id="status">
                        </div>
                        <hr>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>PICKUP</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.pickedup_at} " id="pickup">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>DRV</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.reference} ${response.booking_detail.driver_full_name} " id="drv">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>ETA</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.eta} " id="eta">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>DRV PH</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.driver_contact_number} " id="drv-ph">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>ACCEPT</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.accepted_at} " id="accept">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>VEH</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.reference} " id="veh">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>ARRIVE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.arrived_at} " id="arrived">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>DET</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.reference} ${response.booking_detail.driver_full_name} " id="det">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>POB</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.pob_at} " id="pob">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>REG</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.registration} " id="reg">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>CLOSE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.close_at} " id="close">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>CLOSE REASON</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.close_reason} " id="close-reason">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>CANCEL</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.cancel_at} " id="cancel">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>CANCEL REASON</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.cancel_reason} " id="cancel-reason">
                        </div>
                    </div>
                    </div>
                <div>

                <hr>

                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>STRT</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.pickup_location} " id="strt">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>CUST</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.customer_name} " id="cust">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>AREA</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.area} " id="area">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>CUST PHONE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.customer_contact} " id="cust-phone">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>ZONE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.zone} " id="zone">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>ACCOUNT</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.customer_account} " id="cust-account">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>DEST</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.dropoff_location} " id="dest">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>PAYMENT</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.payment} " id="payment">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>DRV INSTR</label>
                        <textarea type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.driver_instructions} " id="drv-instr"></textarea>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>MGT INSTR</label>
                        <textarea type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.management_instructions} " id="mgt-instr"></textarea>
                        </div>
                        <hr>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>SEATS</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.seats} " id="payment">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>VEHICLE TYPE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.vehicle_type} " id="payment">
                        </div>
                    </div>
                    </div>

                </div>

                <hr>

                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>SOURCE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.source} " id="source">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>EST. DURATION</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.estimated_duration} " id="est-duration">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>EST. MILEAGE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.estimated_mileage} " id="est-mileage">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>DURATION</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.estimated_duration} " id="mileage">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>ACT. MILEAGE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.actual_mileage} " id="strt">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>SPEED</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.average_speed} " id="cust">
                        </div>
                    </div>
                    </div>
                </div>

                <hr>

                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>EXTRAS</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.extras} " id="extras">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>TOLLS</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.tolls} " id="est-tolls">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>TIP</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.tip} " id="extras">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>WAITING MINS</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.waiting_mins} " id="waiting-mins">
                        </div>
                    </div>
                    </div>
                </div>

                <hr>

                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>COST</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.cost} " id="extras">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>PRICE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.price} " id="est-tolls">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>DISCOUNT</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.discount_cost} " id="extras">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>DISCOUNT</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.discount_price} " id="waiting-mins">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>ZONE SURGE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.zone_surge} " id="extras">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>ZONE SURGE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.zone_surge} " id="est-tolls">
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>WAITING COST</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.waiting_cost} " id="extras">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>WAITING PRICE</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.waiting_cost_price} " id="waiting-mins">
                        </div>
                    </div>
                    </div>
                </div>

                <hr>

                <div class="card pl-3 pr-3 bg-light mb-3">
                    <div class="row">
                    <div class="col-sm-6">
                        <div class=""><label>DRIVER COMMENT</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.cost} " id="extras">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class=""><label>BOOKING NOTES</label>
                        <input type="text" readonly class="form-control mb-3" placeholder=" ${response.booking_detail.price} " id="est-tolls">
                        </div>
                    </div>
                    </div>
                </div>
                <div>
            <div>

            </form>

            <!-- Google Map will appear here -->
            <div id="booking-map"></div>
        </div>
    </div>
    `;

    logDetail.innerHTML += '<div id="booking-map" style="height: 1000px;"></div>';
    logDetail.innerHTML += '<button class="btn btn-primary">LOGS</button>';

    initBookingMap(response)
}