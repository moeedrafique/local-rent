$(window).on('load', function(){


	$(".tab button").click(function(){
		//alert("click");
		$(this).parent().addClass("active").siblings().removeClass("active");

	});

	$(".show-booking-form").click(function(){
		$(".search-form").slideUp(1);
		$(".book-jobs").slideDown(1);
	});
	$(".show-search-form").click(function(){
		$(".book-jobs").slideUp(1);
		$(".search-form").slideDown(1);
	});

	$(".toggle-btn-hide").click(function(){
		$(this).hide();
		$(".toggle-btn-show.toggle-btn").css("display","inline-block");
		$(".toggle-sidebar").animate({
			left:'-640px',
		}, 500);
		$(".expanding").animate({
			width:'100%'
		}, 700);
	});

	$(".toggle-btn-show").click(function(){
		$(this).hide();
		$(".toggle-btn-hide.toggle-btn").css("display","inline-block");
		$(".toggle-sidebar").animate({
			left:'0'
		}, 700);
		$(".expanding").animate({
			width:'66.6666666667%'
		},500);
	});

	$(".sidebar-open").on('click',function(){
		$(".toggle-btn-hide").hide();
		$(this).hide();
		$(".sidebar-lock").show();
		

	});

	$(".sidebar-lock").on('click',function(){
		$(".toggle-btn-hide").show();
		$(".sidebar-open").hide();
		$(this).hide();
	});

	$(".open-message-box").click(function(){
		$(".messages-holder").fadeToggle(100);
	});

	$(document).on('click','.menu-toggle-btn', function(){
		$('.menu-toggleable').toggleClass('opened');
		$(this).toggleClass("clicked");
	});

	$("#side-menu ul li a").click(function(){
		$(this).css("background","rgba(0, 0, 0, 0.5)").parent().siblings().find("a").css("background","none");
	});
	$(document).on('click','#loadBookings', function(){
		$('#bookingsOverlay').slideToggle(800);
		$('#driversOverlay').slideUp(800);

	});
	$(document).on('click','#driversView', function(){
		$('#driversOverlay').slideToggle(800);
		$('#bookingsOverlay').slideUp(800);
	});


	$(".load-booking").click(function(){
		$("#bookingsTable_wrapper").slideUp(500);
		$(".single-booking").slideDown(500);
	});
	$("#back-to-bookings").click(function(){
		$("#bookingsTable_wrapper").slideDown(500);
		$(".single-booking").slideUp(500);
	});

	$(".load-driver").click(function(){
		$("#driversTable_wrapper").slideUp(500);
		$(".single-driver").slideDown(500);
	});
	$("#back-to-drivers").click(function(){
		$("#driversTable_wrapper").slideDown(500);
		$(".single-booking").slideUp(500);
	});

	$("#show-live-chat").click(function(){

		$(".live-chat").fadeToggle(200);
		$(".single-booking").slideUp(200);

	});

	$("#back-to-form").click(function(){
		$(".live-chat").slideUp(200);
		$(".single-booking").slideDown(200);
	});


	var driverMsg_height = $(".driverMsg").height();

	$(".driverMsg").css("margin-bottom",(driverMsg_height * 0.01) + 2);

	$(".dataTables_empty").text("NO AVAILABLE DATA");

});