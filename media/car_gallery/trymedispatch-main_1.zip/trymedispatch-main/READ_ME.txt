===============================================================================
                           PROJECT TITLE --> Hir3d Dispatch System
===============================================================================

Description:
-------------------------------------------------------------------------------
This product is developed for Hir3d and its sub-contractors such as taxibases
and is developed and provided by TryME.Taxi Limited. This is sole property of
TryME.Taxi Limited.

Table of Contents:
-------------------------------------------------------------------------------
1. Installation
2. Usage
3. Configuration
4. Dependencies
5. Known Issues
6. Contributing
7. Credits
8. License

Installation:
-------------------------------------------------------------------------------
Provide step-by-step instructions about how to set up the development environment
and how to install all dependencies.

Usage:
-------------------------------------------------------------------------------
Explain how to use the project or software after the installation is complete.

Configuration:
-------------------------------------------------------------------------------
If your project requires configuration, describe what files need to be edited
and what the different options are.

Dependencies:
-------------------------------------------------------------------------------
List all the software and libraries that the project depends on.

Known Issues:
-------------------------------------------------------------------------------
List any known issues and potential fixes if applicable.

Contributing:
-------------------------------------------------------------------------------
Describe how others can contribute to your project.

Credits:
-------------------------------------------------------------------------------
List everyone who has contributed to the development of this project.

License:
-------------------------------------------------------------------------------
Include the full license here or explain where to find it in the repository.
This product is sole property of TryME.Taxi Limited and is provided to Hir3d
taxibases and its subcontractors.

Additional Notes:
-------------------------------------------------------------------------------
1. Driver Statuses
    pending
    job_given
    cancel
    completed
    bidding
    arrived
    pob
    not-available
    available
